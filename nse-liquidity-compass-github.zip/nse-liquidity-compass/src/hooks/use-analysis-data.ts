import { useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { fetchLiveCandles } from "@/lib/live.functions";
import { analyze, DEFAULT_SETTINGS, PAIR_COMPARISONS, type PairOptions, type Settings, type Candle } from "@/lib/engine";

export function useAnalysisData(symbol: string, settings: Settings = DEFAULT_SETTINGS, pair?: PairOptions) {
  const fetchCandles = useServerFn(fetchLiveCandles);
  const [source, setSource] = useState<"demo" | "live">("demo");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [warning, setWarning] = useState("");
  const [snapshot, setSnapshot] = useState<{ symbol: string; peer: string | undefined; candles: Candle[]; peerCandles: Candle[]; fetchedAt: number } | null>(null);
  const request = useRef(0);
  const peer = pair?.symbol ?? PAIR_COMPARISONS[symbol]?.[0]?.symbol;
  const live = snapshot?.symbol === symbol && snapshot.peer === peer ? snapshot : null;
  const refresh = async (target?: { symbol: string; pair?: PairOptions | undefined }) => {
    if (busy) return;
    const requestedSymbol = target?.symbol ?? symbol;
    const requestedPair = target ? target.pair : pair;
    const requestedPeer = requestedPair?.symbol ?? PAIR_COMPARISONS[requestedSymbol]?.[0]?.symbol;
    const id = ++request.current;
    setBusy(true); setError(""); setWarning(""); setSnapshot(null);
    try {
      const result = await fetchCandles({ data: { symbol: requestedSymbol, peer: requestedPeer } });
      if (id !== request.current) return;
      if (!result.ok) { setError(result.error); return; }
      analyze(requestedSymbol, settings, result.candles, requestedPair, result.peerCandles, "TWELVE_DATA");
      setSnapshot({ symbol: requestedSymbol, peer: requestedPeer, ...result });
      const last = result.candles.at(-1);
      const stale = !last || result.fetchedAt - (last.t + 60000) > 5 * 60000;
      setWarning([result.warning, stale ? "Latest candles are more than five minutes old; market may be closed or the feed delayed. Check the report timestamp." : ""].filter(Boolean).join(" "));
    } catch { setError("Not enough usable candle history for analysis, or the connection failed. Try refreshing."); }
    finally { if (id === request.current) setBusy(false); }
  };
  const report = source === "demo" ? analyze(symbol, settings, undefined, pair) : live ? analyze(symbol, settings, live.candles, pair, live.peerCandles, "TWELVE_DATA") : null;
  return { source, setSource, refresh, busy, error, warning, report, fetchedAt: live?.fetchedAt };
}