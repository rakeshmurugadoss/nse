// Pure helpers for Zerodha Kite Connect historical candles (data-only; no order code).
export const KITE_BASE = "https://api.kite.trade";

/** App symbols whose NSE trading symbol changed (Tata Motors demerger → TMPV). */
export const KITE_SYMBOL_ALIASES: Record<string, string[]> = { TATAMOTORS: ["TATAMOTORS", "TMPV"] };

/** Find an NSE equity instrument token in Kite's instruments CSV, trying known renamed symbols. */
export function findInstrumentToken(instrumentsCsv: string, symbol: string): number | null {
  for (const s of KITE_SYMBOL_ALIASES[symbol] ?? [symbol]) {
    const t = findExact(instrumentsCsv, s);
    if (t) return t;
  }
  return null;
}

function findExact(instrumentsCsv: string, symbol: string): number | null {
  const lines = instrumentsCsv.split(/\r?\n/);
  const head = lines.shift()?.split(",") ?? [];
  const iTok = head.indexOf("instrument_token"), iSym = head.indexOf("tradingsymbol"), iSeg = head.indexOf("segment");
  if (iTok < 0 || iSym < 0) return null;
  for (const line of lines) {
    const c = line.split(",");
    if (c[iSym] === symbol && (iSeg < 0 || c[iSeg] === "NSE")) return Number(c[iTok]);
  }
  return null;
}

type KiteCandle = [string, number, number, number, number, number];

/** Convert Kite candles into the research CSV format; drops the still-forming bar. */
export function kiteCandlesToCsv(candles: KiteCandle[], now = Date.now()): string {
  const rows = candles
    .map(([ts, o, h, l, c, v]) => ({ ts: ts.replace(/([+-]\d{2})(\d{2})$/, "$1:$2"), o, h, l, c, v }))
    .filter((r) => Date.parse(r.ts) + 60_000 <= now)
    .map((r) => `${r.ts},${r.o},${r.h},${r.l},${r.c},${Math.max(0, Math.round(r.v))}`);
  return ["timestamp,open,high,low,close,volume", ...rows].join("\n");
}

const pad = (n: number) => String(n).padStart(2, "0");
/** Kite expects IST "yyyy-mm-dd hh:mm:ss". */
export function istStamp(ms: number) {
  const d = new Date(ms + 19_800_000);
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:00`;
}

/** Kite login checksum: SHA-256 hex of api_key + request_token + api_secret. */
export async function kiteChecksum(key: string, requestToken: string, secret: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(key + requestToken + secret));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

/** Kite access tokens expire at 06:00 IST each day; seconds from `now` until the next expiry. */
export function secondsUntilKiteExpiry(now: number): number {
  const ist = now + 19_800_000, day = 86_400_000;
  let next = Math.floor(ist / day) * day + 6 * 3_600_000;
  if (next <= ist) next += day;
  return Math.max(60, Math.floor((next - ist) / 1000));
}

const hex = (b: ArrayBuffer) => [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, "0")).join("");
async function hmac(secret: string, msg: string) {
  const k = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return hex(await crypto.subtle.sign("HMAC", k, new TextEncoder().encode(msg)));
}

/** Self-verifying login state (no cookie needed, works when Zerodha opens in another browser/tab). */
export async function signKiteState(secret: string, now = Date.now()) {
  const body = `${now}.${crypto.randomUUID().replace(/-/g, "")}`;
  return `${body}.${await hmac(secret, body)}`;
}

/** Valid when signed with our secret and no older than 15 minutes. */
export async function verifyKiteState(secret: string, state: string, now = Date.now()) {
  const m = /^(\d{10,16})\.([a-f0-9]{32})\.([a-f0-9]{64})$/.exec(state);
  if (!m) return false;
  const age = now - Number(m[1]);
  if (age < -60_000 || age > 15 * 60_000) return false;
  return (await hmac(secret, `${m[1]}.${m[2]}`)) === m[3];
}

async function aesKey(secret: string) {
  const raw = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`kite-token:${secret}`));
  return crypto.subtle.importKey("raw", raw, "AES-GCM", false, ["encrypt", "decrypt"]);
}
const b64 = (u: Uint8Array) => btoa(String.fromCharCode(...u));
const unb64 = (s: string) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

/** Encrypt the daily access token before storing it in the database. */
export async function encryptKiteToken(secret: string, token: string) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await aesKey(secret), new TextEncoder().encode(token)));
  return `${b64(iv)}.${b64(ct)}`;
}

export async function decryptKiteToken(secret: string, stored: string) {
  const [iv, ct] = stored.split(".");
  const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv: unb64(iv) }, await aesKey(secret), unb64(ct));
  return new TextDecoder().decode(pt);
}
