import { z } from "zod";
import { analyze, atr, ema, rsi, advancedStructures, orderBlockProtection, TFS, DEFAULT_SETTINGS, type Candle, type Report } from "./engine";
import { isIndianResearchSymbol } from "./indian-stocks";

export const FEATURE_VERSION = "causal-nse-1";
export const RULE_VERSION = "liquidity-research-2";
export const researchRequest = z.object({ symbol: z.string().refine(isIndianResearchSymbol), timeframe: z.enum(["1m", "5m", "15m", "1h"]), horizon: z.union([z.literal(5), z.literal(15)]), csv: z.string().max(6_000_000), timezone: z.enum(["offset", "Asia/Kolkata"]), filename: z.string().max(120) });
export type ResearchRequest = z.infer<typeof researchRequest>;
export function parseResearchCsv(csv: string, timezone: ResearchRequest["timezone"], now = Date.now()) {
  const rows = csv.replace(/^\uFEFF/, "").trim().split(/\r?\n/);
  if (rows.shift()?.trim().toLowerCase() !== "timestamp,open,high,low,close,volume") throw new Error("CSV columns must be timestamp,open,high,low,close,volume.");
  if (rows.length < 30 || rows.length > 50000) throw new Error("Upload 30–50,000 one-minute candles.");
  const candles: Candle[] = [];
  let gaps = 0;
  rows.forEach((row, i) => {
    const cells = row.split(",").map((x) => x.trim());
    if (cells.length !== 6 || cells.some((x) => !x)) throw new Error(`Missing fields on row ${i + 2}.`);
    let ts = cells[0].replace(" ", "T");
    if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?(?:Z|[+-]\d{2}:\d{2})?$/.test(ts)) throw new Error(`Invalid ISO timestamp on row ${i + 2}.`);
    const [year, month, date] = ts.slice(0, 10).split("-").map(Number);
    if (new Date(Date.UTC(year, month - 1, date)).toISOString().slice(0, 10) !== ts.slice(0, 10)) throw new Error(`Invalid calendar date on row ${i + 2}.`);
    if (!/(Z|[+-]\d{2}:\d{2})$/.test(ts)) {
      if (timezone !== "Asia/Kolkata") throw new Error(`Row ${i + 2} needs an explicit timezone offset.`);
      ts += "+05:30";
    }
    if (cells.slice(1).some((x) => !/^\d+(?:\.\d+)?$/.test(x))) throw new Error(`Invalid OHLCV number on row ${i + 2}.`);
    const c = { t: Date.parse(ts), o: Number(cells[1]), h: Number(cells[2]), l: Number(cells[3]), c: Number(cells[4]), v: Number(cells[5]) };
    if (![c.t, c.o, c.h, c.l, c.c, c.v].every(Number.isFinite) || c.t % 60000 || Math.min(c.o, c.h, c.l, c.c) <= 0 || c.v < 0 || c.h < Math.max(c.o, c.c) || c.l > Math.min(c.o, c.c) || c.h < c.l) throw new Error(`Invalid timestamp or OHLCV on row ${i + 2}.`);
    const local = new Date(c.t + 19800000), minute = local.getUTCHours() * 60 + local.getUTCMinutes();
    if ([0, 6].includes(local.getUTCDay()) || minute < 555 || minute >= 930) throw new Error(`Row ${i + 2} is outside the regular NSE session.`);
    const prev = candles.at(-1);
    if (prev && c.t <= prev.t) throw new Error(`Duplicate or unordered timestamp on row ${i + 2}.`);
    if (prev && local.toISOString().slice(0, 10) === new Date(prev.t + 19800000).toISOString().slice(0, 10) && c.t - prev.t !== 60000) gaps++;
    candles.push(c);
  });
  const closed = candles.filter((c) => c.t + 60000 <= now);
  if (closed.length < 30) throw new Error("Not enough closed historical candles.");
  return { candles: closed, gaps, removed: candles.length - closed.length };
}
const mean = (v: number[]) => v.length ? v.reduce((a, b) => a + b, 0) / v.length : 0;
export function researchStatistics(c: Candle[]) {
  const closes = c.map((x) => x.c), last = c.at(-1);
  if (!last || c.length < 30) throw new Error("Insufficient statistical history.");
  const av = atr(c), a = av.at(-1) ?? 0;
  const e20 = ema(closes, 20), e50 = ema(closes, 50), e12 = ema(closes, 12), e26 = ema(closes, 26), macd = e12.map((x, i) => x - e26[i]), signal = ema(macd, 9);
  const path = c.slice(-21), travelled = path.slice(1).reduce((n, x, i) => n + Math.abs(x.c - path[i].c), 0);
  const efficiency = travelled ? Math.abs(last.c - path[0].c) / travelled : 0;
  let plus = 0, minus = 0; const dx: number[] = [];
  for (let i = 1; i < c.length; i++) {
    const up = c[i].h - c[i - 1].h, down = c[i - 1].l - c[i].l;
    plus = plus * 13 / 14 + (up > down && up > 0 ? up : 0); minus = minus * 13 / 14 + (down > up && down > 0 ? down : 0);
    dx.push(plus + minus ? 100 * Math.abs(plus - minus) / (plus + minus) : 0);
  }
  const adx = ema(dx, 27).at(-1) ?? 0, slope = (e20.at(-1) ?? last.c) - e20[e20.length - 6];
  const atrPercentile = 100 * av.slice(-100).filter((x) => x <= a).length / Math.min(av.length, 100);
  const direction = slope >= 0 ? "bullish" : "bearish";
  const trend = efficiency < 0.25 || adx < 20 ? "Sideways / consolidation" : `${adx >= 30 ? "Strong" : "Weak"} ${direction} trend`;
  const avgVol = mean(c.slice(-21, -1).map((x) => x.v)), relativeVolume = avgVol > 0 ? last.v / avgVol : null;
  const widths = closes.map((_, i) => { const sample = closes.slice(Math.max(0, i - 19), i + 1), avg = mean(sample); return avg ? 4 * Math.sqrt(mean(sample.map((x) => (x - avg) ** 2))) / avg : 0; });
  const width = widths.at(-1) ?? 0, widthRank = widths.slice(-100).filter((x) => x <= width).length / Math.min(100, widths.length);
  const changes = c.slice(-21).slice(1).map((x, i) => x.c - c[c.length - 21 + i].c);
  const persistence = changes.filter((x) => slope >= 0 ? x > 0 : x < 0).length / Math.max(changes.length, 1);
  const prior = c.slice(-21, -1), breakUp = last.c > Math.max(...prior.map((x) => x.h)), breakDown = last.c < Math.min(...prior.map((x) => x.l));
  const environment = breakUp || breakDown ? "Breakout environment" : efficiency < 0.25 ? "Possible reversal / range environment" : "Trend continuation environment";
  return { trend, volatility: atrPercentile >= 80 ? "High volatility" : atrPercentile <= 20 ? "Low volatility" : "Normal volatility", environment, persistence, squeeze: widthRank <= 0.2, expansion: width > (widths.at(-6) ?? width) * 1.25, momentumAcceleration: mean(changes.slice(-3)) - mean(changes.slice(-6, -3)), volumeAnomaly: relativeVolume !== null && relativeVolume >= 2, adx, atr: a, atrPercentile, efficiency, emaSlope: slope, bandWidth: width, macd: macd.at(-1) ?? 0, macdSignal: signal.at(-1) ?? 0, rsi: rsi(c).at(-1) ?? 50, relativeVolume, expectedLow: last.c - a, expectedHigh: last.c + a, emaAligned: (e20.at(-1) ?? 0) > (e50.at(-1) ?? 0) ? "bullish" : "bearish" };
}
export function actionableResearch(r: Report, stats: ReturnType<typeof researchStatistics>, gaps: number, sessionCandles?: Candle[]) {
  const reasons = r.decision === "WAIT" ? [...r.reasons] : [];
  const trigger = r.tfs["1m"].events.at(-1), last = r.tfs["1m"].candles.at(-1);
  const desired = r.plan?.dir === "BUY" ? "bull" : "bear";
  const triggerBar = r.tfs["1m"].candles.find((c) => c.t === trigger?.t);
  if (!trigger || !last || !triggerBar || trigger.kind !== "CHoCH" || trigger.dir !== desired || (trigger.availableAt ?? Infinity) > r.dataAsOf || last.t - trigger.t > 2 * 60000 || !r.plan || triggerBar.l > r.plan.entryHigh || triggerBar.h < r.plan.entryLow) reasons.push("No recent confirmed 1M CHoCH trigger inside the entry zone.");
  const priorVolume = r.tfs["1m"].candles.filter((c) => trigger && c.t < trigger.t).slice(-20);
  if (priorVolume.length < 20 || !priorVolume.some((c) => c.v > 0) || !triggerBar || triggerBar.v <= mean(priorVolume.map((c) => c.v))) reasons.push("Trigger volume does not confirm above the prior 20-bar average.");
  if (stats.trend === "Sideways / consolidation") reasons.push("Trend entry rejected in consolidation.");
  if (gaps) reasons.push("Missing intraday bars; entry evidence is incomplete.");
  const today = (sessionCandles ?? r.tfs["1m"].candles).filter((x) => Math.floor((x.t + 19800000) / 86400000) === Math.floor((r.dataAsOf - 60000 + 19800000) / 86400000));
  const first = today[0], minute = first ? new Date(first.t + 19800000).getUTCHours() * 60 + new Date(first.t + 19800000).getUTCMinutes() : 0;
  if (minute !== 555 || today.length < 15 || today.slice(0, 15).some((c, i) => c.t !== first.t + i * 60000)) reasons.push("Complete session opening range is unavailable.");
  if (r.tfs["5m"].candles.at(-1) && r.dataAsOf - ((r.tfs["5m"].candles.at(-1)?.t ?? 0) + 5 * 60000) >= 5 * 60000) reasons.push("5M confirmation bars are stale at the research timestamp.");
  return { ...r, decision: reasons.length ? "WAIT" as const : r.decision, plan: reasons.length ? null : r.plan, reasons: reasons.length ? reasons : r.reasons };
}
export function buildResearch(input: ResearchRequest, now = Date.now()) {
  const parsed = parseResearchCsv(input.csv, input.timezone, now), asOf = (parsed.candles.at(-1)?.t ?? 0) + 60000;
  const r = analyze(input.symbol, DEFAULT_SETTINGS, parsed.candles, undefined, undefined, "SUPPLIED", { asOf, completeOnly: true });
  const statistics = researchStatistics(r.tfs["5m"].candles), report = actionableResearch(r, statistics, parsed.gaps, parsed.candles);
  const lastDay = Math.floor((asOf - 60000 + 19800000) / 86400000), older = parsed.candles.filter((c) => Math.floor((c.t + 19800000) / 86400000) < lastDay), previousDay = Math.floor(((older.at(-1)?.t ?? 0) + 19800000) / 86400000), previous = older.filter((c) => Math.floor((c.t + 19800000) / 86400000) === previousDay);
  const detections = advancedStructures(report.tfs[input.timeframe], report.tfs["1h"], previous).filter((d) => d.availableAt <= asOf);
  const protection = orderBlockProtection(report.tfs[input.timeframe], asOf);
  const directional = TFS.filter((tf) => report.tfs[tf].trend !== "range"), bull = directional.filter((tf) => report.tfs[tf].trend === "bull").length;
  return { report, statistics, detections, protection, candles: parsed.candles, gaps: parsed.gaps, asOf, agreement: directional.length ? Math.round(100 * Math.max(bull, directional.length - bull) / 4) : 0, model: { status: "Not trained", validated: false, score: null }, source: "HISTORICAL CSV", freshness: "Historical snapshot · not live", featureVersion: FEATURE_VERSION, ruleVersion: RULE_VERSION, timeframe: input.timeframe, horizon: input.horizon };
}
export type ResearchOutput = ReturnType<typeof buildResearch>;
export function evaluateOutcome(output: ResearchOutput, candles: Candle[]) {
  const start = output.asOf, end = start + output.horizon * 60000;
  const future = candles.filter((c) => c.t >= start && c.t < end);
  if (future.length !== output.horizon || future.some((c, i) => c.t !== start + i * 60000)) throw new Error("Outcome pending: append complete one-minute candles through the prediction horizon.");
  const plan = output.report.plan; let barrier = "no_setup";
  if (plan) {
    barrier = "neither";
    for (const c of future) {
      const target = plan.targets[0]?.price;
      if (target === undefined) break;
      const hitTarget = plan.dir === "BUY" ? c.h >= target : c.l <= target, hitStop = plan.dir === "BUY" ? c.l <= plan.sl : c.h >= plan.sl;
      if (hitTarget || hitStop) { barrier = hitTarget && hitStop ? "ambiguous" : hitTarget ? "target_first" : "stop_first"; break; }
    }
  }
  const change = future[future.length - 1].c - output.report.price;
  return { evaluatedThrough: end, barrier, change, correct: output.report.decision === "WAIT" ? null : output.report.decision === "BUY" ? change > 0 : change < 0, basis: "Historical appended candles; target/stop evaluation assumes entry at the recorded prediction price, not an executed fill." };
}