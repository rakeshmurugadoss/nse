import Papa from "papaparse";

export type IndianExchange = "NSE" | "BSE";
export type IndianStock = { symbol: string; name: string; exchange: IndianExchange; token: number };
export const researchStockSymbol = (s: Pick<IndianStock, "exchange" | "symbol">) => s.exchange === "BSE" ? `BSE:${s.symbol}` : s.symbol;
export const isIndianResearchSymbol = (s: string) => /^(?:(?:NSE|BSE):)?[A-Z0-9][A-Z0-9&._-]{0,49}$/.test(s) && !["EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD", "USDCHF", "NZDUSD", "XAUUSD"].includes(s);

/** Preserve quoted company names and exclude derivatives and index instruments. */
export function parseIndianStocks(csv: string): IndianStock[] {
  const rows = Papa.parse<Record<string, string>>(csv, { header: true, skipEmptyLines: true }).data;
  return rows.flatMap((r) => {
    const exchange = r["exchange"] || r["segment"];
    const token = Number(r["instrument_token"]);
    if ((exchange !== "NSE" && exchange !== "BSE") || r["segment"] !== exchange || r["instrument_type"] !== "EQ" || !Number.isSafeInteger(token) || token <= 0 || !isIndianResearchSymbol(r["tradingsymbol"] ?? "")) return [];
    return [{ symbol: r["tradingsymbol"], name: r["name"] || r["tradingsymbol"], exchange, token }];
  });
}

export function searchIndianStocks(stocks: IndianStock[], query: string, exchange: IndianExchange | "ALL") {
  const q = query.trim().toUpperCase();
  return stocks.filter((s) => (exchange === "ALL" || s.exchange === exchange) && `${s.symbol} ${s.name}`.toUpperCase().includes(q))
    .sort((a, b) => Number(b.symbol === q) - Number(a.symbol === q) || Number(b.symbol.startsWith(q)) - Number(a.symbol.startsWith(q)) || a.symbol.localeCompare(b.symbol) || a.exchange.localeCompare(b.exchange));
}