import { createServerFn } from "@tanstack/react-start";
import { PAIR_COMPARISONS } from "@/lib/engine";
import { liveRequest, parseLiveCandles } from "@/lib/live-data";

export const fetchLiveCandles = createServerFn({ method: "POST" })
  .inputValidator((data) => liveRequest.parse(data))
  .handler(async ({ data }) => {
    if (data.peer && !PAIR_COMPARISONS[data.symbol]?.some((p) => p.symbol === data.peer)) throw new Error("Unsupported comparison pair.");
    const key = process.env["UDC_TWELVE_DATA_API_KEY"];
    const gatewayKey = process.env["LOVABLE_API_KEY"];
    if (!key || !gatewayKey) return { ok: false as const, error: "Twelve Data is not connected." };
    const now = Date.now();
    const read = async (symbol: string) => {
      const query = new URLSearchParams({ symbol: `${symbol.slice(0, 3)}/${symbol.slice(3)}`, interval: "1min", outputsize: "5000", timezone: "UTC" });
      const response = await fetch(`https://connector-gateway.lovable.dev/udc_twelve_data/time_series?${query}`, { headers: { Authorization: `Bearer ${gatewayKey}`, "X-Connection-Api-Key": key }, signal: AbortSignal.timeout(30000) });
      const payload: unknown = await response.json();
      if (!response.ok || (typeof payload === "object" && payload !== null && "status" in payload && payload.status === "error")) {
        // Do not forward provider text: it may echo credential-bearing request details.
        throw new Error(response.status === 429 ? "Twelve Data usage limit reached. Try later." : "Twelve Data could not supply these candles. Check your plan and available credits.");
      }
      return parseLiveCandles(payload, now);
    };
    try {
      const candles = await read(data.symbol);
      let peerCandles: Awaited<ReturnType<typeof read>> = [];
      let warning = "";
      if (data.peer) {
        try { peerCandles = await read(data.peer); }
        catch { warning = "Comparison candles unavailable; divergence is unconfirmed."; }
      }
      return { ok: true as const, candles, peerCandles, fetchedAt: now, warning };
    } catch (error) {
      const message = error instanceof Error && error.message.startsWith("Twelve Data") ? error.message : "Invalid candle response or connection timeout. Please try again.";
      return { ok: false as const, error: message };
    }
  });