import { KITE_BASE } from "./kite";
import { parseIndianStocks, type IndianStock } from "./indian-stocks";

let cache: { stocks: IndianStock[]; until: number } | undefined;
let pending: Promise<IndianStock[]> | undefined;

/** Cache only the public instrument directory, never credentials or candle/account data. */
export async function loadKiteDirectory(headers: Record<string, string>) {
  if (cache && cache.until > Date.now()) return cache.stocks;
  if (pending) return pending;
  pending = (async () => {
    const response = await fetch(`${KITE_BASE}/instruments`, { headers, signal: AbortSignal.timeout(25_000) });
    if (!response.ok) throw new Error("The stock directory is unavailable. Please reconnect Kite and try again.");
    const stocks = parseIndianStocks(await response.text());
    if (!stocks.length) throw new Error("Kite returned an empty stock directory. Please try again.");
    cache = { stocks, until: Date.now() + 3_600_000 };
    return stocks;
  })();
  try { return await pending; } finally { pending = undefined; }
}