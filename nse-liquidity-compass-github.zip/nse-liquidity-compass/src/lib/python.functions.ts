import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
export const pythonModels = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const url = process.env["PYTHON_RESEARCH_URL"];
  if (!url) return { connected: false, models: [], status: "Python service not connected" };
  // Validate ownership locally; model rows are never fetched with an administrative key.
  const { data, error } = await context.supabase.from("model_registry").select("version,task,status,metadata").eq("user_id", context.userId);
  if (error) throw new Error("Model records unavailable.");
  return { connected: true, models: data, status: data.length ? "Recorded models" : "Not trained" };
});
export const enrichWithPython = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((x) => z.object({ id: z.string().uuid() }).parse(x)).handler(async ({ data, context }) => {
  const { data: row, error } = await context.supabase.from("predictions").select("id").eq("id", data.id).eq("user_id", context.userId).single();
  if (error || !row) throw new Error("Prediction unavailable.");
  const url = process.env["PYTHON_RESEARCH_URL"];
  if (!url) return { connected: false, status: "Python service not connected" };
  const { getRequest } = await import("@tanstack/react-start/server");
  const bearer = getRequest().headers.get("authorization");
  if (!bearer) throw new Error("Authentication required.");
  if (!url.startsWith("https://")) throw new Error("Python service requires HTTPS.");
  const response = await fetch(`${url.replace(/\/+$/, "")}/api/v1/predictions/analyze`, { method: "POST", redirect: "error", headers: { Authorization: bearer, "Content-Type": "application/json" }, body: JSON.stringify({ prediction_id: data.id }), signal: AbortSignal.timeout(30000) });
  if (!response.ok) throw new Error("Python research unavailable; stored candle analysis is unchanged.");
  const payload: unknown = await response.json();
  const valid = z.object({ feature_count: z.number().int().nonnegative(), model: z.object({ status: z.string(), score: z.number().nullable(), validated: z.boolean() }) }).parse(payload);
  return { connected: true, status: "Evidence enriched", result: valid };
});