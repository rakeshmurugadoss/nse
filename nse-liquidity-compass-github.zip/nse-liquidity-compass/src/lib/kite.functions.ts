import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { KITE_BASE, KITE_SYMBOL_ALIASES, kiteCandlesToCsv, istStamp } from "@/lib/kite";
import { isIndianResearchSymbol } from "@/lib/indian-stocks";

/** Fetch closed one-minute NSE candles from Kite Connect and return research CSV. */
export const fetchKiteCandles = createServerFn({ method: "POST" })
  .inputValidator((x) => z.object({ symbol: z.string().refine(isIndianResearchSymbol), days: z.number().int().min(1).max(30) }).parse(x))
  .handler(async ({ data }) => {
    const key = process.env["KITE_API_KEY"];
    const { loadKiteToken } = await import("@/lib/kite-session.server");
    const token = (await loadKiteToken()) ?? process.env["KITE_ACCESS_TOKEN"];
    if (!key || !token) return { ok: false as const, error: "Zerodha Kite is not connected yet. Tap Connect Zerodha Kite and log in first." };
    const headers = { "X-Kite-Version": "3", Authorization: `token ${key}:${token}` };
    try {
      const { loadKiteDirectory } = await import("@/lib/kite-directory.server");
      const stocks = await loadKiteDirectory(headers);
      const [exchange, symbol] = data.symbol.includes(":") ? data.symbol.split(":") : ["NSE", data.symbol];
      const aliases = KITE_SYMBOL_ALIASES[symbol] ?? [symbol];
      const stock = aliases.map((s) => stocks.find((x) => x.exchange === exchange && x.symbol === s)).find(Boolean);
      if (!stock) return { ok: false as const, error: `${symbol} not found on ${exchange} in Kite.` };
      const id = stock.token;
      const now = Date.now();
      const url = `${KITE_BASE}/instruments/historical/${id}/minute?from=${encodeURIComponent(istStamp(now - data.days * 86_400_000))}&to=${encodeURIComponent(istStamp(now))}`;
      const res = await fetch(url, { headers });
      const body = (await res.json()) as { status?: string; message?: string; data?: { candles?: [string, number, number, number, number, number][] } };
      if (!res.ok || body.status !== "success") return { ok: false as const, error: res.status === 403 ? "Kite access token expired or historical-data permission missing." : body.message ?? `Kite error ${res.status}.` };
      const csv = kiteCandlesToCsv(body.data?.candles ?? [], now);
      const count = csv.split("\n").length - 1;
      if (count < 30) return { ok: false as const, error: "Kite returned too few closed candles (market may be closed for this range)." };
      return { ok: true as const, csv, count, filename: `KITE ${stock.exchange}:${stock.symbol} 1m · ${data.days}d` };
    } catch (e) {
      console.error("kite fetch failed", e);
      return { ok: false as const, error: "Could not reach Zerodha Kite." };
    }
  });

export const kiteStockDirectory = createServerFn({ method: "GET" }).handler(async () => {
  const key = process.env["KITE_API_KEY"];
  if (!key) return { stocks: [], error: "Connect Zerodha Kite to search the stock directory." };
  try {
    const { loadKiteDirectory } = await import("@/lib/kite-directory.server");
    return { stocks: await loadKiteDirectory({ "X-Kite-Version": "3" }), error: null };
  } catch (e) {
    return { stocks: [], error: e instanceof Error ? e.message : "Could not load the stock directory." };
  }
});

/** Whether Kite is configured and today's login cookie is present (never returns the token). */
export const kiteStatus = createServerFn({ method: "GET" }).handler(async () => {
  const { loadKiteToken } = await import("@/lib/kite-session.server");
  return {
    configured: Boolean(process.env["KITE_API_KEY"] && process.env["KITE_API_SECRET"]),
    connected: Boolean((await loadKiteToken()) || process.env["KITE_ACCESS_TOKEN"]),
  };
});
