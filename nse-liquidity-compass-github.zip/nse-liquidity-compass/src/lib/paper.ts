// Simulated (paper) trades only. No broker connection exists.
export type PaperTrade = {
  id: string; symbol: string; dir: "BUY" | "SELL"; qty: number; entry: number; sl: number; target: number;
  openedAt: number; exit?: number; closedAt?: number; reason?: string; strategy: string; aiDecision: string; note?: string;
  targets?: number[]; brokeragePerOrder?: number; slippagePerSide?: number; otherCharges?: number; costAsOf?: string; mae?: number; mfe?: number;
};
const KEY = "liquidity-ai-paper";
export const BROKERAGE = 20; // ₹ per executed order (estimate)
export const SLIPPAGE = 0.0005; // 0.05% per side (estimate)

export const loadTrades = (): PaperTrade[] => { try { return JSON.parse(localStorage.getItem(KEY) ?? "[]"); } catch { return []; } };
export const saveTrades = (t: PaperTrade[]) => localStorage.setItem(KEY, JSON.stringify(t));

export function netPnl(t: PaperTrade) {
  if (t.exit == null) return 0;
  const sign = t.dir === "BUY" ? 1 : -1;
  const gross = sign * (t.exit - t.entry) * t.qty;
  const costs = 2 * (t.brokeragePerOrder ?? BROKERAGE) + (t.slippagePerSide ?? SLIPPAGE) * (t.entry + t.exit) * t.qty + (t.otherCharges ?? 0);
  return gross - costs;
}

export function stats(trades: PaperTrade[]) {
  const closed = trades.filter((t) => t.exit != null).sort((a, b) => (a.closedAt ?? 0) - (b.closedAt ?? 0));
  const pnls = closed.map(netPnl);
  const wins = pnls.filter((p) => p > 0), losses = pnls.filter((p) => p <= 0);
  let eq = 0, peak = 0, dd = 0;
  for (const p of pnls) { eq += p; peak = Math.max(peak, eq); dd = Math.max(dd, peak - eq); }
  const rr = closed.map((t) => Math.abs(t.target - t.entry) / Math.max(1e-9, Math.abs(t.entry - t.sl)));
  const grossLoss = Math.abs(losses.reduce((a, b) => a + b, 0));
  return {
    count: closed.length, net: eq, winRate: closed.length ? (wins.length / closed.length) * 100 : 0,
    profitFactor: grossLoss ? wins.reduce((a, b) => a + b, 0) / grossLoss : wins.length ? Infinity : 0,
    maxDD: dd, avgRR: rr.length ? rr.reduce((a, b) => a + b, 0) / rr.length : 0,
  };
}
