import type { Candle, TFAnalysis, TF, ZoneStatus } from "./engine";

export type AdvancedDetection = { type: string; direction: "bull" | "bear" | "neutral"; bottom: number; top: number; formedAt: number; confirmedAt: number; availableAt: number; status: ZoneStatus; strength: number; reason: string; tf: TF };
/** Research definitions, not assertions about actual institutional orders. All inputs are closed bars. */
export function advancedStructures(a: TFAnalysis, external: TFAnalysis, previous: Candle[]): AdvancedDetection[] {
  const minutes = { "1m": 1, "5m": 5, "15m": 15, "1h": 60 }[a.tf];
  const close = (t: number) => t + minutes * 60000;
  const results: AdvancedDetection[] = [];
  const add = (type: string, direction: AdvancedDetection["direction"], bottom: number, top: number, formedAt: number, availableAt: number, status: ZoneStatus, strength: number, reason: string) => results.push({ type, direction, bottom, top, formedAt, confirmedAt: availableAt, availableAt, status, strength, reason, tf: a.tf });
  for (const e of a.events.slice(-8)) {
    add("Internal structure " + e.kind, e.dir, e.price, e.price, e.t, e.availableAt ?? close(e.t), "Untouched", e.strength ?? 60, "Close through a confirmed internal swing.");
    const index = a.candles.findIndex((c) => c.t === e.t), c = a.candles[index], prior = a.candles.slice(Math.max(0, index - 14), index);
    const tr = prior.length ? prior.reduce((n, p, i) => n + Math.max(p.h - p.l, i ? Math.abs(p.h - prior[i - 1].c) : 0, i ? Math.abs(p.l - prior[i - 1].c) : 0), 0) / prior.length : 0;
    if (e.kind === "CHoCH" && c && tr > 0 && Math.abs(c.c - c.o) >= tr) add("MSS", e.dir, e.price, e.price, e.t, close(e.t), "Untouched", Math.min(100, 60 + 10 * Math.abs(c.c - c.o) / tr), "Change of character confirmed by a breaking candle body at least one prior 14-bar mean true range.");
  }
  for (const e of external.events.slice(-4)) results.push({ type: "External structure " + e.kind, direction: e.dir, bottom: e.price, top: e.price, formedAt: e.t, confirmedAt: e.availableAt ?? e.t + 3600000, availableAt: e.availableAt ?? e.t + 3600000, status: "Untouched", strength: e.strength ?? 60, reason: "Close through the confirmed 1H structural swing.", tf: external.tf });
  for (const z of a.zones.filter((z) => z.kind.includes("FVG"))) {
    const bull = z.kind.startsWith("Bull"), available = z.availableAt;
    if (available === undefined) continue;
    const bars = a.candles.filter((c) => close(c.t) > available);
    const inversion = bars.find((c) => bull ? c.c < z.bottom : c.c > z.top);
    if (!inversion) continue;
    let status: ZoneStatus = "Untouched";
    for (const c of bars.filter((c) => c.t > inversion.t)) {
      if (bull ? c.c > z.top : c.c < z.bottom) { status = "Invalidated"; break; }
      if (c.h >= z.bottom && c.l <= z.top) status = "Mitigated";
    }
    add(bull ? "Bear inverse FVG" : "Bull inverse FVG", bull ? "bear" : "bull", z.bottom, z.top, z.formedAt ?? z.t, close(inversion.t), status, 60, "Original confirmed FVG failed on a close through its far boundary; flipped zone is tracked separately.");
  }
  const sweeps: { c: Candle; direction: "bull" | "bear"; level: number; swingAt: number }[] = [];
  for (const sw of a.swings.slice(-14)) {
    if (sw.availableAt === undefined) continue;
    const availableAt = sw.availableAt;
    const sweep = a.candles.find((c) => c.t >= availableAt && (sw.type === "low" ? c.l < sw.price && c.c > sw.price : c.h > sw.price && c.c < sw.price));
    if (sweep) { const direction = sw.type === "low" ? "bull" : "bear"; sweeps.push({ c: sweep, direction, level: sw.price, swingAt: sw.t }); add("Liquidity sweep & rejection", direction, sw.price, sw.price, sw.t, close(sweep.t), "Reclaimed", 70, "Confirmed swing liquidity pierced and reclaimed on the same closed candle."); }
  }
  for (const sw of sweeps.slice(-6)) {
    const confirmation = a.events.find((e) => e.t > sw.c.t && e.dir === sw.direction);
    if (!confirmation) continue;
    add("Inducement candidate", sw.direction, sw.level, sw.level, sw.swingAt, confirmation.availableAt ?? close(confirmation.t), "Reclaimed", 55, "A confirmed internal swing sweep was followed by a same-direction structural break; inducement is an inferred candidate.");
    const candle = a.candles.filter((c) => c.t < sw.c.t && c.t >= sw.c.t - minutes * 60000 * 8 && (sw.direction === "bull" ? c.c < c.o : c.c > c.o)).at(-1);
    if (!candle) continue;
    const failures = a.candles.some((c) => c.t > confirmation.t && (sw.direction === "bull" ? c.c < candle.l : c.c > candle.h));
    add("Mitigation-block candidate", sw.direction, candle.l, candle.h, candle.t, confirmation.availableAt ?? close(confirmation.t), failures ? "Invalidated" : "Untouched", 55, "Last opposite candle before a reclaimed-liquidity structural reversal; candidate definition requires a sweep and later confirmed break.");
  }
  const last = a.candles.at(-1);
  if (last) {
    const day = Math.floor((last.t + 19800000) / 86400000), today = a.candles.filter((c) => Math.floor((c.t + 19800000) / 86400000) === day);
    const first = today[0];
    if (first) {
      add("Session high", "neutral", Math.max(...today.map((c) => c.h)), Math.max(...today.map((c) => c.h)), first.t, close(last.t), "Untouched", 50, "Current closed-bar session high; updates only as new bars become available.");
      add("Session low", "neutral", Math.min(...today.map((c) => c.l)), Math.min(...today.map((c) => c.l)), first.t, close(last.t), "Untouched", 50, "Current closed-bar session low.");
      if (previous.length) { const high = Math.max(...previous.map((c) => c.h)), low = Math.min(...previous.map((c) => c.l)); add("Previous session high", "neutral", high, high, previous[0].t, first.t, "Untouched", 60, "Previous supplied regular NSE session high, known at today's opening."); add("Previous session low", "neutral", low, low, previous[0].t, first.t, "Untouched", 60, "Previous supplied regular NSE session low, known at today's opening."); }
    }
  }
  return results.sort((p, q) => p.availableAt - q.availableAt);
}