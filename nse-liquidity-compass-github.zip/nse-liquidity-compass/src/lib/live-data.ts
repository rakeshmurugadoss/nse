import { FOREX_SYMBOLS, type Candle } from "@/lib/engine";
import { z } from "zod";

export const liveRequest = z.object({ symbol: z.enum(FOREX_SYMBOLS as [string, ...string[]]), peer: z.enum(FOREX_SYMBOLS as [string, ...string[]]).optional() });
export function parseLiveCandles(payload: unknown, now: number): Candle[] {
  const parsed = z.object({ status: z.literal("ok"), values: z.array(z.object({ datetime: z.string(), open: z.string(), high: z.string(), low: z.string(), close: z.string(), volume: z.string().optional() })) }).parse(payload);
  const candles = parsed.values.map((x) => ({ t: Date.parse(x.datetime.replace(" ", "T") + "Z"), o: Number(x.open), h: Number(x.high), l: Number(x.low), c: Number(x.close), v: x.volume === undefined ? 0 : Number(x.volume) })).sort((a, b) => a.t - b.t);
  if (candles.some((x, i) => ![x.t, x.o, x.h, x.l, x.c, x.v].every(Number.isFinite) || x.l <= 0 || x.h < Math.max(x.o, x.c) || x.l > Math.min(x.o, x.c) || x.v < 0 || x.t % 60000 !== 0 || (i > 0 && candles[i - 1].t === x.t))) throw new Error("Invalid or duplicate candles from the data provider.");
  return candles.filter((c) => c.t + 60000 <= now);
}