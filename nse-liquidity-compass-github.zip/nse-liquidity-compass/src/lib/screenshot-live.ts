import { liveRequest } from "./live-data";

export function screenshotLiveSymbol(symbol: string | null): string | null {
  if (!symbol) return null;
  const normalized = symbol.trim().toUpperCase().replace(/^(FX|OANDA|FOREXCOM):/, "").replace(/[\s/]/g, "");
  const parsed = liveRequest.shape.symbol.safeParse(normalized);
  return parsed.success ? parsed.data : null;
}