import type { Candle, TFAnalysis } from "./engine";

export const OB_PROTECTION_VERSION = "shared-ob-protection-1";
export type OBLifecycle = "fresh" | "touched" | "partially_mitigated" | "fully_mitigated" | "invalidated" | "expired";
export type OBProtectionOptions = {
  atrPeriod: number; displacementAtrMin: number; bodyRatioMin: number; relativeVolumeMin: number;
  searchBars: number; zoneMode: "full" | "body"; maxAgeBars: number; fullMitigationFraction: number;
};
export const DEFAULT_OB_PROTECTION: OBProtectionOptions = {
  atrPeriod: 14, displacementAtrMin: 1.25, bodyRatioMin: 0.55, relativeVolumeMin: 1,
  searchBars: 12, zoneMode: "full", maxAgeBars: 80, fullMitigationFraction: 0.95,
};
export type ProtectedOrderBlock = {
  id: string; direction: "bull" | "bear"; top: number; bottom: number;
  formedAt: number; confirmedAt: number; availableAt: number; statusAt: number;
  structureEvent: "BOS" | "CHoCH"; structureLevel: number;
  displacementAtr: number; bodyRatio: number; relativeVolume: number | null;
  qualityScore: number; qualityPassed: boolean; lifecycle: OBLifecycle;
  firstTouchAt: number | null; mitigationFraction: number;
  invalidatedAt: number | null; expiredAt: number | null;
};
export function isProtectedOrderBlock(b: ProtectedOrderBlock) {
  return b.qualityPassed && ["fresh", "touched", "partially_mitigated"].includes(b.lifecycle);
}
function validateOptions(p: OBProtectionOptions) {
  if (![p.atrPeriod, p.searchBars, p.maxAgeBars].every((n) => Number.isInteger(n) && n >= 1)
    || ![p.displacementAtrMin, p.bodyRatioMin, p.relativeVolumeMin, p.fullMitigationFraction].every(Number.isFinite)
    || p.displacementAtrMin < 0 || p.relativeVolumeMin < 0 || p.bodyRatioMin < 0 || p.bodyRatioMin > 1
    || p.fullMitigationFraction <= 0 || p.fullMitigationFraction > 1 || !["full", "body"].includes(p.zoneMode)) throw new Error("Invalid order-block protection parameters.");
}
/** Additive protection evidence using the SAME confirmed structural events as the shared engine.
 * Never replaces existing zones, judge scores or entry plans. Candle timestamps are opens.
 */
export function orderBlockProtection(a: TFAnalysis, asOf: number, options: Partial<OBProtectionOptions> = {}) {
  const parameters = { ...DEFAULT_OB_PROTECTION, ...options }; validateOptions(parameters);
  if (!Number.isFinite(asOf)) throw new Error("Invalid protection snapshot timestamp.");
  const ms = { "1m": 1, "5m": 5, "15m": 15, "1h": 60 }[a.tf] * 60000;
  if (a.candles.some((c, i) => ![c.t, c.o, c.h, c.l, c.c, c.v].every(Number.isFinite)
    || c.t % 60000 !== 0 || Math.min(c.o, c.h, c.l, c.c) <= 0 || c.v < 0
    || c.h < Math.max(c.o, c.c, c.l) || c.l > Math.min(c.o, c.c, c.h)
    || (i > 0 && c.t <= a.candles[i - 1].t))) throw new Error("Invalid, duplicate or unordered protection candles.");
  const candles = a.candles.filter((c) => c.t + ms <= asOf);
  const closeAt = (c: Candle) => c.t + ms;
  const orderBlocks: ProtectedOrderBlock[] = [];
  // Wilder ATR from prior candles only: breaking candle cannot inflate its own baseline.
  const atrs: number[] = []; let atr = 0;
  candles.forEach((c, i) => {
    const prev = candles[i - 1];
    const tr = Math.max(c.h - c.l, prev ? Math.abs(c.h - prev.c) : 0, prev ? Math.abs(c.l - prev.c) : 0);
    atr = i ? (atr * (parameters.atrPeriod - 1) + tr) / parameters.atrPeriod : tr; atrs.push(atr);
  });
  for (const e of a.events) {
    const i = candles.findIndex((c) => c.t === e.t), c = candles[i];
    const availableAt = e.availableAt;
    if (!c || availableAt === undefined || availableAt < closeAt(c) || availableAt > asOf || i < parameters.atrPeriod) continue;
    if (!(e.dir === "bull" ? c.c > e.price : c.c < e.price)) continue;
    const baseline = atrs[i - 1];
    if (!(baseline > 0)) continue;
    const displacementAtr = Math.abs(c.c - c.o) / baseline;
    const bodyRatio = Math.abs(c.c - c.o) / Math.max(c.h - c.l, Number.EPSILON);
    const volumes = candles.slice(Math.max(0, i - 20), i);
    const average = volumes.reduce((s, x) => s + x.v, 0) / volumes.length;
    const relativeVolume = volumes.length === 20 && average > 0 ? c.v / average : null;
    const qualityPassed = displacementAtr >= parameters.displacementAtrMin && bodyRatio >= parameters.bodyRatioMin
      && (parameters.relativeVolumeMin === 0 || (relativeVolume !== null && relativeVolume >= parameters.relativeVolumeMin));
    const source = candles.slice(Math.max(0, i - parameters.searchBars), i).reverse().find((x) => e.dir === "bull" ? x.c < x.o : x.c > x.o);
    if (!source) continue;
    const top = parameters.zoneMode === "full" ? source.h : Math.max(source.o, source.c);
    const bottom = parameters.zoneMode === "full" ? source.l : Math.min(source.o, source.c);
    if (top <= bottom) continue;
    const b: ProtectedOrderBlock = {
      id: `${OB_PROTECTION_VERSION}:${a.tf}:${source.t}:${e.t}:${e.dir}`, direction: e.dir, top, bottom,
      formedAt: source.t, confirmedAt: availableAt, availableAt, statusAt: asOf,
      structureEvent: e.kind, structureLevel: e.price, displacementAtr, bodyRatio, relativeVolume,
      qualityScore: Math.min(100, 30 + Math.min(displacementAtr, 3) * 12 + Math.min(bodyRatio, 1) * 20 + (relativeVolume === null ? 0 : Math.min(relativeVolume, 3) * 8)),
      qualityPassed, lifecycle: "fresh", firstTouchAt: null, mitigationFraction: 0, invalidatedAt: null, expiredAt: null,
    };
    let age = 0;
    for (const next of candles.slice(i + 1)) {
      if (next.t < availableAt) continue;
      age++;
      // A gap beyond a zone invalidates it even with no overlap. Track failures after consumption too.
      if (b.direction === "bull" ? next.c < bottom : next.c > top) { b.lifecycle = "invalidated"; b.invalidatedAt = closeAt(next); break; }
      if (age > parameters.maxAgeBars) { b.lifecycle = "expired"; b.expiredAt = closeAt(next); break; }
      if (b.lifecycle === "fully_mitigated" || next.l > top || next.h < bottom) continue;
      b.firstTouchAt ??= closeAt(next);
      const penetration = b.direction === "bull" ? (top - Math.max(next.l, bottom)) / (top - bottom) : (Math.min(next.h, top) - bottom) / (top - bottom);
      b.mitigationFraction = Math.max(b.mitigationFraction, Math.min(1, Math.max(0, penetration)));
      b.lifecycle = b.mitigationFraction >= parameters.fullMitigationFraction ? "fully_mitigated" : b.mitigationFraction > 0 ? "partially_mitigated" : "touched";
    }
    orderBlocks.push(b);
  }
  return {
    engineVersion: OB_PROTECTION_VERSION, snapshotAt: asOf, timeframe: a.tf, parameters,
    confirmedPivots: a.swings.filter((s) => s.availableAt !== undefined && s.availableAt <= asOf),
    structureEvents: a.events.filter((e) => e.availableAt !== undefined && e.availableAt <= asOf),
    orderBlocks, protectedActiveOrderBlocks: orderBlocks.filter(isProtectedOrderBlock),
    warnings: ["Quality scores are heuristics, not probabilities or standalone entries.", "Protection is supplemental research evidence; existing trade plans are unchanged.", "Lifecycle applies only at this snapshot. Rerun truncated history for earlier decisions.", "Uses the shared engine's bounded candle history and confirmed swing settings; 95% penetration is treated as consumed."],
  };
}