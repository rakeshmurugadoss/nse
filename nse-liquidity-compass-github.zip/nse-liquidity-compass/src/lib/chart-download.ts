// Export the original annotated SVG, not the transformed/zoomed viewport.
export async function chartImage(svg: SVGSVGElement, title: string, asOf: string, source = "DEMO"): Promise<Blob> {
  await document.fonts.ready;
  const clone = svg.cloneNode(true) as SVGSVGElement;
  const originals = [svg, ...svg.querySelectorAll("*")];
  const copies = [clone, ...clone.querySelectorAll("*")];
  originals.forEach((el, i) => {
    const copy = copies[i];
    if (!copy) return;
    const css = getComputedStyle(el);
    for (const key of ["fill", "stroke", "color", "font-size", "font-weight", "opacity", "fill-opacity", "stroke-opacity", "stroke-width", "stroke-dasharray"]) copy.setAttribute(key, css.getPropertyValue(key));
    if (el.tagName.toLowerCase() === "text") copy.setAttribute("font-family", "monospace");
    copy.removeAttribute("class");
  });
  const ns = "http://www.w3.org/2000/svg";
  const view = svg.viewBox.baseVal;
  const output = document.createElementNS(ns, "svg");
  const header = 70;
  output.setAttribute("xmlns", ns);
  output.setAttribute("viewBox", `0 0 ${view.width} ${view.height + header}`);
  output.setAttribute("width", "2400");
  output.setAttribute("height", String(Math.round(2400 * (view.height + header) / view.width)));
  const rootCss = getComputedStyle(svg);
  const bg = document.createElementNS(ns, "rect");
  bg.setAttribute("width", "100%"); bg.setAttribute("height", "100%"); bg.setAttribute("fill", rootCss.backgroundColor);
  output.append(bg);
  for (const [text, y, size] of [[title, 28, 20], [`${source} CANDLES · last bar starts ${asOf} IST · Research only · ${source === "DEMO" ? "Not live prices" : "Snapshot, not streaming"}`, 51, 12]] as const) {
    const label = document.createElementNS(ns, "text"); label.textContent = text;
    label.setAttribute("x", "15"); label.setAttribute("y", String(y)); label.setAttribute("font-size", String(size)); label.setAttribute("fill", rootCss.color); label.setAttribute("font-family", "monospace"); output.append(label);
  }
  clone.setAttribute("y", String(header)); clone.setAttribute("width", String(view.width)); clone.setAttribute("height", String(view.height));
  output.append(clone);
  const url = URL.createObjectURL(new Blob([new XMLSerializer().serializeToString(output)], { type: "image/svg+xml" }));
  try {
    const image = new Image(); image.src = url; await image.decode();
    const canvas = document.createElement("canvas"); canvas.width = 2400; canvas.height = Number(output.getAttribute("height"));
    const ctx = canvas.getContext("2d"); if (!ctx) throw new Error("Image export unavailable.");
    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
    return await new Promise<Blob>((resolve, reject) => canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error("Image export failed.")), "image/png"));
  } finally { URL.revokeObjectURL(url); }
}

export async function saveChartImage(blob: Blob, filename: string) {
  const file = new File([blob], filename, { type: "image/png" });
  if (matchMedia("(pointer: coarse)").matches && navigator.canShare?.({ files: [file] })) {
    try { await navigator.share({ files: [file], title: filename }); return; }
    catch (error) { if (error instanceof DOMException && error.name === "AbortError") return; }
  }
  const url = URL.createObjectURL(blob), link = document.createElement("a");
  link.href = url; link.download = filename; document.body.append(link); link.click(); link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}