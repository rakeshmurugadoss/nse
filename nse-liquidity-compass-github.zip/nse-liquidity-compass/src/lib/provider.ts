import type { Candle } from "./engine";
export interface NseMarketProvider { source: string; fetchClosedMinutes(request: { symbol: string; from: number; to: number }): Promise<Candle[]>; }
export const disconnectedNseProvider: NseMarketProvider = { source: "Not connected", async fetchClosedMinutes() { throw new Error("Market data not connected"); } };