import { z } from "zod";

export const MAX_SCREENSHOT_BYTES = 8 * 1024 * 1024;
export const SCREENSHOT_TYPES = ["image/png", "image/jpeg", "image/webp"];
export function validateScreenshot(file: { type: string; size: number }) {
  if (!SCREENSHOT_TYPES.includes(file.type)) return "Please upload a PNG, JPG or WEBP picture.";
  if (file.size > MAX_SCREENSHOT_BYTES) return "Picture is too big (max 8 MB).";
  if (file.size === 0) return "This picture is empty. Choose another file.";
  return "";
}
export const screenshotInput = z.object({
  image: z.string().max(Math.ceil(MAX_SCREENSHOT_BYTES / 3) * 4 + 40).regex(/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/),
  language: z.enum(["en", "ta"]),
});
export const SCREENSHOT_TOPICS = ["structure", "liquidity", "smc", "levels", "volume", "context"] as const;
export const SCREENSHOT_MARKS = ["bull_fvg", "bear_fvg", "bull_ob", "bear_ob", "support", "resistance", "liquidity", "bos", "choch"] as const;
export const screenshotSection = z.object({
  visibility: z.enum(["visible", "partial", "not_visible"]),
  reading: z.string().min(1).max(1800),
  evidence: z.array(z.string().min(1).max(700)).max(3),
});
const planLevel = z.object({ price: z.string().max(60).nullable(), y: z.number().min(0).max(1).nullable(), note: z.string().max(300) });
export const screenshotResult = z.object({
  isChart: z.boolean(),
  readable: z.boolean(),
  symbol: z.string().max(100).nullable(),
  timeframe: z.string().max(100).nullable(),
  trend: z.enum(["bull", "bear", "range", "unclear"]),
  summary: z.string().max(2000),
  observations: z.array(z.string().max(1000)).max(6),
  limitations: z.array(z.string().max(1000)).max(6),
  sections: z.object({
    structure: screenshotSection, liquidity: screenshotSection, smc: screenshotSection,
    levels: screenshotSection, volume: screenshotSection, context: screenshotSection,
  }),
  keyLevels: z.array(z.object({
    kind: z.enum(["support", "resistance", "liquidity", "zone"]),
    priceLabel: z.string().max(100).nullable(),
    location: z.string().min(1).max(500),
    significance: z.string().min(1).max(700),
  })).max(4),
  annotations: z.array(z.object({
    kind: z.enum(SCREENSHOT_MARKS),
    label: z.string().min(1).max(60),
    x: z.number().min(0).max(1), y: z.number().min(0).max(1),
    w: z.number().min(0).max(1), h: z.number().min(0).max(1),
  })).max(14),
  judge: z.object({
    bullPoints: z.array(z.string().min(1).max(300)).max(5),
    bearPoints: z.array(z.string().min(1).max(300)).max(5),
    lean: z.enum(["bull", "bear", "neutral"]),
    strength: z.enum(["low", "medium", "high"]),
    verdict: z.string().min(1).max(600),
  }),
  plan: z.object({
    available: z.boolean(),
    direction: z.enum(["long", "short", "none"]),
    entry: planLevel, stop: planLevel, target1: planLevel, target2: planLevel,
    rationale: z.string().min(1).max(1200),
  }),
  scenarios: z.object({
    bullish: z.string().min(1).max(1000),
    bearish: z.string().min(1).max(1000),
    wait: z.string().min(1).max(1000),
  }),
});
export type ScreenshotResult = z.infer<typeof screenshotResult>;

// The gateway may omit status on a successful synchronous response.
// Explicit failures, incomplete output and refusals must never become a report.
export function parseScreenshotResponse(response: {
  status?: string;
  error?: unknown;
  incomplete_details?: unknown;
  output: { type: string; content?: { type: string; text?: string }[] }[];
}): ScreenshotResult {
  if ((response.status !== undefined && response.status !== "completed") || response.error || response.incomplete_details) {
    throw new Error("Screenshot response did not complete.");
  }
  const content = response.output.flatMap((item) => item.type === "message" ? item.content ?? [] : []);
  if (content.some((item) => item.type === "refusal")) throw new Error("Screenshot reading was declined.");
  const text = content.filter((item) => item.type === "output_text").map((item) => item.text ?? "").join("");
  return screenshotResult.parse(JSON.parse(text));
}