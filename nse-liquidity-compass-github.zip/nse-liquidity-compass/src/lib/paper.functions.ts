import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Json } from "@/integrations/supabase/types";
const paper = z.object({ id: z.string().max(100), symbol: z.string().max(30), dir: z.enum(["BUY","SELL"]), qty: z.number().int().positive(), entry: z.number().positive(), sl: z.number().positive(), target: z.number().positive(), exit: z.number().positive().optional(), openedAt: z.number(), closedAt: z.number().optional(), strategy: z.string().max(200), aiDecision: z.string().max(20), otherCharges: z.number().min(0).optional(), brokeragePerOrder: z.number().min(0).optional(), slippagePerSide: z.number().min(0).max(.05).optional(), costAsOf: z.string().optional(), targets: z.array(z.number().positive()).max(3).optional() });
export const transferPaperTrades = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((x) => z.array(paper).max(1000).parse(x)).handler(async ({ data, context }) => {
  if (!data.length) return 0;
  const { error } = await context.supabase.from("research_paper_trades").insert(data.map((trade) => ({ user_id: context.userId, trade: JSON.parse(JSON.stringify(trade)) as Json })));
  if (error) throw new Error("Paper journal could not be copied.");
  return data.length;
});