import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { buildResearch, evaluateOutcome, parseResearchCsv, researchRequest, type ResearchOutput } from "./predictions";
import type { Json } from "@/integrations/supabase/types";
const json = (value: unknown): Json => JSON.parse(JSON.stringify(value)) as Json;
export const savePrediction = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((x) => researchRequest.parse(x)).handler(async ({ data, context }) => {
  const output = buildResearch(data);
  const snapshot = JSON.stringify(output.candles);
  const hash = [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(snapshot)))].map((x) => x.toString(16).padStart(2, "0")).join("");
  const { data: record, error } = await context.supabase.from("predictions").insert({ user_id: context.userId, prediction_timestamp: new Date(output.asOf).toISOString(), symbol: data.symbol, timeframe: data.timeframe, horizon_minutes: data.horizon, data_source: output.source, snapshot: json({ csv: data.csv, timezone: data.timezone, filename: data.filename, candles: output.candles }), snapshot_hash: hash, feature_version: output.featureVersion, rule_engine_version: output.ruleVersion, output: json(output) }).select("id").single();
  if (error || !record) throw new Error("Prediction could not be saved.");
  return { id: record.id, output };
});
export const predictionHistory = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const { data, error } = await context.supabase.from("predictions").select("id,symbol,timeframe,created_at,prediction_timestamp,output,prediction_outcomes(outcome)").eq("user_id", context.userId).order("created_at", { ascending: false }).limit(100);
  if (error) throw new Error("Prediction history unavailable.");
  return data;
});
export const recordOutcome = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((x) => z.object({ id: z.string().uuid(), csv: z.string().max(6_000_000), timezone: z.enum(["offset", "Asia/Kolkata"]) }).parse(x)).handler(async ({ data, context }) => {
  const { data: prediction, error } = await context.supabase.from("predictions").select("output,snapshot").eq("id", data.id).eq("user_id", context.userId).single();
  if (error || !prediction) throw new Error("Prediction unavailable.");
  const output = prediction.output as unknown as ResearchOutput;
  const parsed = parseResearchCsv(data.csv, data.timezone);
  const original = new Map(output.candles.map((c) => [c.t, c]));
  for (const c of parsed.candles.filter((c) => c.t < output.asOf)) if (JSON.stringify(original.get(c.t)) !== JSON.stringify(c)) throw new Error("Earlier candle history must match the saved snapshot.");
  const outcome = evaluateOutcome(output, parsed.candles);
  const { error: writeError } = await context.supabase.from("prediction_outcomes").insert({ user_id: context.userId, prediction_id: data.id, evaluated_through: new Date(outcome.evaluatedThrough).toISOString(), outcome: json(outcome) });
  if (writeError) throw new Error("Outcome could not be saved; it may already be recorded.");
  return outcome;
});