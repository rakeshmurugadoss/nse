import { decryptKiteToken, encryptKiteToken, secondsUntilKiteExpiry } from "@/lib/kite";

const ROW = "owner";

/** Store today's Kite access token (encrypted) so preview, published app and any browser can use it. */
export async function saveKiteToken(token: string) {
  const secret = process.env["KITE_API_SECRET"];
  if (!secret) throw new Error("KITE_API_SECRET missing");
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const expires = new Date(Date.now() + secondsUntilKiteExpiry(Date.now()) * 1000).toISOString();
  const { error } = await supabaseAdmin.from("kite_sessions").upsert({ id: ROW, token_ciphertext: await encryptKiteToken(secret, token), expires_at: expires, updated_at: new Date().toISOString() });
  if (error) throw error;
}

/** Today's token, or null when missing/expired. Never send this to the browser. */
export async function loadKiteToken(): Promise<string | null> {
  const secret = process.env["KITE_API_SECRET"];
  if (!secret) return null;
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin.from("kite_sessions").select("token_ciphertext, expires_at").eq("id", ROW).maybeSingle();
  if (error) { console.error("kite session read failed", error.message); return null; }
  if (!data || Date.parse(data.expires_at) <= Date.now()) return null;
  try { return await decryptKiteToken(secret, data.token_ciphertext); } catch { return null; }
}

export async function clearKiteToken() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  await supabaseAdmin.from("kite_sessions").delete().eq("id", ROW);
}
