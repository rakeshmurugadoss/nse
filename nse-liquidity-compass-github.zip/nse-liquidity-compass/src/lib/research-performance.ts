import type { ResearchOutput } from "./predictions";
export function researchPerformance(rows: { symbol: string; timeframe: string; output: ResearchOutput; outcome: { correct: boolean | null; change: number; barrier: string } | null }[]) {
  const evaluated = rows.filter((r) => r.outcome), directional = evaluated.filter((r) => r.outcome?.correct !== null && r.output.report.decision !== "WAIT");
  const correct = directional.filter((r) => r.outcome?.correct === true).length;
  const by = (field: "symbol" | "timeframe" | "regime") => {
    const groups: Record<string, { evaluated: number; directional: number; correct: number }> = {};
    for (const row of evaluated) { const key = field === "regime" ? row.output.statistics.trend : row[field]; const g = groups[key] ?? { evaluated: 0, directional: 0, correct: 0 }; g.evaluated++; if (row.output.report.decision !== "WAIT") { g.directional++; if (row.outcome?.correct) g.correct++; } groups[key] = g; }
    return groups;
  };
  return { total: rows.length, pending: rows.length - evaluated.length, evaluated: evaluated.length, correct, incorrect: directional.length - correct, accuracy: directional.length ? 100 * correct / directional.length : null, bySymbol: by("symbol"), byTimeframe: by("timeframe"), byRegime: by("regime"), brier: null, calibration: null, netExpectancy: null, reason: "No calibrated probabilities or verified fills; profitability is not inferred from directional accuracy." };
}