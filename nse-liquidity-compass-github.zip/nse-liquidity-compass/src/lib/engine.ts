// Liquidity AI — shared deterministic analysis engine.
// Every zone comes from fixed OHLCV rules, never from visual guessing.
export { advancedStructures, type AdvancedDetection } from "./advanced-structures";
export { orderBlockProtection, isProtectedOrderBlock, OB_PROTECTION_VERSION, type ProtectedOrderBlock } from "./order-block-protection";

export type Candle = { t: number; o: number; h: number; l: number; c: number; v: number };
export type TF = "1h" | "15m" | "5m" | "1m";
export const TFS: TF[] = ["1h", "15m", "5m", "1m"];
const TF_MIN: Record<TF, number> = { "1h": 60, "15m": 15, "5m": 5, "1m": 1 };

export const SYMBOLS: Record<string, number> = {
  RELIANCE: 2900, TCS: 4100, HDFCBANK: 1650, INFY: 1850, ICICIBANK: 1250,
  SBIN: 820, TATAMOTORS: 980, ITC: 470, BHARTIARTL: 1550, LT: 3600,
  EURUSD: 1.085, GBPUSD: 1.295, USDJPY: 153, AUDUSD: 0.66, USDCAD: 1.39, USDCHF: 0.875, NZDUSD: 0.60, XAUUSD: 2700,
};

export type Market = "nse" | "forex";
export const FOREX_SYMBOLS = ["EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD", "USDCHF", "NZDUSD", "XAUUSD"];
export const marketOf = (symbol: string): Market => FOREX_SYMBOLS.includes(symbol) ? "forex" : "nse";
export const symbolsFor = (market: Market) => Object.keys(SYMBOLS).filter((symbol) => marketOf(symbol) === market);
export const priceDigits = (symbol: string) => marketOf(symbol) === "nse" || symbol === "XAUUSD" ? 2 : symbol === "USDJPY" ? 3 : 5;
export const fmtPrice = (symbol: string, price: number) => price.toFixed(priceDigits(symbol));
export const symbolLabel = (symbol: string) => marketOf(symbol) === "forex" ? `${symbol.slice(0, 3)}/${symbol.slice(3)}${symbol === "XAUUSD" ? " · Gold" : ""}` : symbol;

// Candidate relationships are checked against measured returns, never assumed.
export const PAIR_COMPARISONS: Record<string, { symbol: string; inverse: boolean }[]> = {
  EURUSD: [{ symbol: "GBPUSD", inverse: false }, { symbol: "USDCHF", inverse: true }],
  GBPUSD: [{ symbol: "EURUSD", inverse: false }],
  AUDUSD: [{ symbol: "NZDUSD", inverse: false }],
  NZDUSD: [{ symbol: "AUDUSD", inverse: false }],
  USDCHF: [{ symbol: "EURUSD", inverse: true }, { symbol: "USDJPY", inverse: false }],
  USDJPY: [{ symbol: "USDCHF", inverse: false }],
  USDCAD: [{ symbol: "AUDUSD", inverse: true }],
};
export type PairOptions = { symbol: string; tf: TF };
export type PairDivergence = {
  symbol: string; peer: string; tf: TF; inverse: boolean;
  status: "Bullish divergence" | "Bearish divergence" | "No divergence" | "Unconfirmed";
  correlation: number | null; samples: number; asOf: number | null; reason: string;
  reference: { high: number; low: number; peerHigh: number; peerLow: number } | null;
  primary: Candle | null; comparison: Candle | null;
};

// Closed-bar liquidity-sweep SMT variant: prior 20-bar extremes, not fractal pivots.
export function pairDivergence(symbol: string, peer: string, tf: TF, primary: Candle[], comparison: Candle[], asOf: number): PairDivergence {
  const relationship = PAIR_COMPARISONS[symbol]?.find((x) => x.symbol === peer);
  const result: PairDivergence = { symbol, peer, tf, inverse: relationship?.inverse ?? false, status: "Unconfirmed", correlation: null, samples: 0, asOf: null, reason: "This pair relationship is not supported.", reference: null, primary: null, comparison: null };
  if (!relationship) return result;
  const valid = (c: Candle) => [c.t, c.o, c.h, c.l, c.c].every(Number.isFinite) && c.l > 0 && c.h >= Math.max(c.o, c.c) && c.l <= Math.min(c.o, c.c);
  const ms = TF_MIN[tf] * 60000;
  const a = primary.filter((c) => c.t + ms <= asOf).slice(-62), b = comparison.filter((c) => c.t + ms <= asOf).slice(-62);
  if (!Number.isFinite(asOf) || !a.every(valid) || !b.every(valid)) return { ...result, reason: "Invalid price data; comparison unavailable." };
  const last = a.at(-1), peerLast = b.at(-1);
  if (!last || !peerLast || last.t !== peerLast.t || asOf - (last.t + ms) >= ms) return { ...result, reason: "The latest closed candles are missing, stale or out of sync." };
  result.asOf = last.t + ms; result.primary = last; result.comparison = peerLast;
  if (a.length < 62 || b.length < 62) return { ...result, reason: "Need 62 matching closed candles for correlation and liquidity checks." };
  if (a.some((c, i) => c.t !== b[i].t || (i > 0 && c.t - a[i - 1].t !== ms))) return { ...result, reason: "Missing, duplicate or misaligned candles in the comparison window." };
  // 60 pre-event log returns: the sweep cannot manufacture its own correlation.
  const x = a.slice(1, -1).map((c, i) => Math.log(c.c / a[i].c));
  const y = b.slice(1, -1).map((c, i) => Math.log(c.c / b[i].c));
  const mean = (v: number[]) => v.reduce((s, n) => s + n, 0) / v.length;
  const mx = mean(x), my = mean(y);
  let cov = 0, vx = 0, vy = 0;
  x.forEach((n, i) => { cov += (n - mx) * (y[i] - my); vx += (n - mx) ** 2; vy += (y[i] - my) ** 2; });
  result.samples = x.length;
  if (vx <= 1e-20 || vy <= 1e-20) return { ...result, reason: "Flat prices; meaningful correlation is unavailable." };
  result.correlation = Math.max(-1, Math.min(1, cov / Math.sqrt(vx * vy)));
  if ((relationship.inverse ? -result.correlation : result.correlation) < 0.7) return { ...result, reason: "The measured relationship is weak or reversed; no divergence confirmation." };
  const ref = a.slice(-21, -1), peerRef = b.slice(-21, -1);
  result.reference = { high: Math.max(...ref.map((c) => c.h)), low: Math.min(...ref.map((c) => c.l)), peerHigh: Math.max(...peerRef.map((c) => c.h)), peerLow: Math.min(...peerRef.map((c) => c.l)) };
  const r = result.reference;
  const tol = (atr(a.slice(0, -1)).at(-1) ?? 0) * 0.05;
  const peerTol = (atr(b.slice(0, -1)).at(-1) ?? 0) * 0.05;
  const lowSweep = last.l < r.low - tol && last.c > r.low;
  const highSweep = last.h > r.high + tol && last.c < r.high;
  const lowNotConfirmed = relationship.inverse ? peerLast.h < r.peerHigh - peerTol : peerLast.l > r.peerLow + peerTol;
  const highNotConfirmed = relationship.inverse ? peerLast.l > r.peerLow + peerTol : peerLast.h < r.peerHigh - peerTol;
  if (lowSweep && highSweep) return { ...result, reason: "Both sides swept on one candle; direction is ambiguous." };
  if (lowSweep && lowNotConfirmed) return { ...result, status: "Bullish divergence", reason: "Primary pair swept and reclaimed the prior 20-bar low; the comparison pair did not confirm the equivalent extreme. Potential upward reversal, not an entry by itself." };
  if (highSweep && highNotConfirmed) return { ...result, status: "Bearish divergence", reason: "Primary pair swept and reclaimed the prior 20-bar high; the comparison pair did not confirm the equivalent extreme. Potential downward reversal, not an entry by itself." };
  return { ...result, status: "No divergence", reason: "No one-sided sweep and reclaim on the latest closed candle. Both pairs agree, or no valid sweep exists." };
}

function closedForexBars(c1: Candle[], tf: TF): Candle[] {
  const minutes = TF_MIN[tf];
  const buckets = new Map<number, Candle[]>();
  for (const c of c1) {
    const start = Math.floor(c.t / (minutes * 60000)) * minutes * 60000;
    const bars = buckets.get(start) ?? []; bars.push(c); buckets.set(start, bars);
  }
  const out: Candle[] = [];
  for (const [start, bars] of buckets) {
    if (bars.length !== minutes || bars.some((c, i) => c.t !== start + i * 60000)) continue;
    out.push({ t: start, o: bars[0].o, h: Math.max(...bars.map((c) => c.h)), l: Math.min(...bars.map((c) => c.l)), c: bars[bars.length - 1].c, v: bars.reduce((sum, c) => sum + c.v, 0) });
  }
  return out;
}

/** Complete exchange-aligned buckets only; never merge across sessions or fill gaps. */
export function closedSessionBars(c1: Candle[], tf: TF, market: Market, asOf: number): Candle[] {
  const minutes = TF_MIN[tf], ms = minutes * 60000;
  const buckets = new Map<number, Candle[]>();
  for (const c of c1) {
    if (c.t + 60000 > asOf) continue;
    const day = Math.floor((c.t + 19800000) / 86400000) * 86400000 - 19800000;
    const open = day + 555 * 60000;
    if (market === "nse" && (c.t < open || c.t >= open + 375 * 60000)) continue;
    const start = market === "nse" ? open + Math.floor((c.t - open) / ms) * ms : Math.floor(c.t / ms) * ms;
    const group = buckets.get(start) ?? []; group.push(c); buckets.set(start, group);
  }
  return [...buckets].filter(([start, group]) => start + ms <= asOf && group.length === minutes && group.every((c, i) => c.t === start + i * 60000))
    .map(([start, group]) => ({ t: start, o: group[0].o, h: Math.max(...group.map((c) => c.h)), l: Math.min(...group.map((c) => c.l)), c: group[group.length - 1].c, v: group.reduce((n, c) => n + c.v, 0) }));
}

export function forexSessions(t: number): string[] {
  const hour = (zone: string) => Number(new Intl.DateTimeFormat("en-GB", { timeZone: zone, hour: "2-digit", hourCycle: "h23" }).format(t));
  const sessions: string[] = [];
  if (hour("Asia/Tokyo") >= 9 && hour("Asia/Tokyo") < 18) sessions.push("Tokyo");
  if (hour("Europe/London") >= 8 && hour("Europe/London") < 17) sessions.push("London");
  if (hour("America/New_York") >= 8 && hour("America/New_York") < 17) sessions.push("New York");
  return sessions;
}

export type VolumeProfile = {
  bins: { low: number; high: number; volume: number }[];
  poc: number; vah: number; val: number; total: number; valueAreaVolume: number;
  hvn: number[]; lvn: number[]; start: number; end: number;
};
// OHLCV cannot reveal actual volume at each price: distribute each bar's volume
// uniformly across its range. This is a candle estimate, not exchange/order-flow data.
export function volumeProfile(candles: Candle[], count = 32): VolumeProfile | null {
  const c = candles.filter((x) => [x.h, x.l, x.c, x.v].every(Number.isFinite) && x.h >= x.l && x.v > 0);
  if (!c.length) return null;
  const low = Math.min(...c.map((x) => x.l)), high = Math.max(...c.map((x) => x.h));
  const n = Math.max(1, Math.min(100, Math.floor(count) || 32));
  const step = high > low ? (high - low) / n : Math.max(Math.abs(low) * 0.000001, 0.000001);
  const bins = Array.from({ length: n }, (_, i) => ({ low: low + i * step, high: low + (i + 1) * step, volume: 0 }));
  for (const x of c) {
    if (x.h === x.l) { bins[Math.min(n - 1, Math.max(0, Math.floor((x.c - low) / step)))].volume += x.v; continue; }
    for (const b of bins) b.volume += x.v * Math.max(0, Math.min(b.high, x.h) - Math.max(b.low, x.l)) / (x.h - x.l);
  }
  const total = bins.reduce((sum, b) => sum + b.volume, 0);
  const peak = bins.reduce((best, b, i) => b.volume > bins[best].volume ? i : best, 0);
  let left = peak, right = peak, valueAreaVolume = bins[peak].volume;
  while (valueAreaVolume < total * 0.7 && (left > 0 || right < n - 1)) {
    if (left > 0 && (right === n - 1 || bins[left - 1].volume >= bins[right + 1].volume)) valueAreaVolume += bins[--left].volume;
    else valueAreaVolume += bins[++right].volume;
  }
  const mid = (i: number) => (bins[i].low + bins[i].high) / 2;
  const hvn: number[] = [], lvn: number[] = [];
  for (let i = 1; i < n - 1; i++) {
    const v = bins[i].volume;
    if (v >= bins[i - 1].volume && v > bins[i + 1].volume && v >= total / n) hvn.push(mid(i));
    if (v > 0 && v <= bins[i - 1].volume && v < bins[i + 1].volume && v < total / n) lvn.push(mid(i));
  }
  return { bins, poc: mid(peak), vah: bins[right].high, val: bins[left].low, total, valueAreaVolume, hvn, lvn, start: c[0].t, end: c[c.length - 1].t };
}

export type Settings = {
  fractal: number; // bars each side for a confirmed swing
  eqTolAtr: number; // equal highs/lows tolerance in ATR
  dispAtr: number; // displacement body size in ATR
  minRR: number;
  capital: number;
  riskPct: number;
  weights: Record<Category, number>;
};
export type Category = "structure" | "liquidity" | "obfvg" | "mtf" | "momentum" | "volume" | "indicators";
export const DEFAULT_SETTINGS: Settings = {
  fractal: 2, eqTolAtr: 0.15, dispAtr: 1.5, minRR: 2, capital: 100000, riskPct: 1,
  weights: { structure: 15, liquidity: 25, obfvg: 20, mtf: 15, momentum: 10, volume: 10, indicators: 5 },
};

/* ---------------- DEMO DATA (clearly labelled, not live) ---------------- */
const OPEN_MS = (3 * 60 + 45) * 60000; // 09:15 IST = 03:45 UTC
const NSE_HOLIDAYS = ["2026-10-20", "2026-11-10"]; // sample subset of NSE calendar

function rng(seed: number) {
  let s = seed >>> 0;
  return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
}
function tradingDays(endUtc: number, n: number, market: Market) {
  const out: number[] = [];
  let d = Math.floor(endUtc / 86400000) * 86400000;
  while (out.length < n) {
    const day = new Date(d).getUTCDay();
    const iso = new Date(d).toISOString().slice(0, 10);
    if (day !== 0 && day !== 6 && (market === "forex" || !NSE_HOLIDAYS.includes(iso))) out.unshift(d);
    d -= 86400000;
  }
  return out;
}
export function demoSeries(symbol: string, days = 6): Candle[] {
  const base = SYMBOLS[symbol] ?? 1000;
  const market = marketOf(symbol);
  let seed = 0;
  for (const ch of symbol) seed = seed * 31 + ch.charCodeAt(0);
  const r = rng(seed);
  const out: Candle[] = [];
  let p = base;
  for (const day of tradingDays(Date.UTC(2026, 10, 5), days, market)) {
    p *= 1 + (r() - 0.5) * (market === "forex" ? 0.001 : 0.02); // overnight gap
    let drift = (r() - 0.5) * 0.0004;
    for (let m = 0; m < (market === "forex" ? 1440 : 375); m++) {
      if (m % 45 === 0) drift = (r() - 0.5) * 0.0005;
      const vol = base * (market === "forex" ? 0.00012 : 0.0009) * (m < 30 || m > 345 ? 1.8 : 1);
      const o = p;
      const c = o + drift * base * (market === "forex" ? 0.15 : 1) + (r() - 0.5) * vol * 2;
      const h = Math.max(o, c) + r() * vol;
      const l = Math.min(o, c) - r() * vol;
      const v = Math.round((m < 30 ? 3 : m > 345 ? 2 : 1) * (5000 + r() * 15000));
      out.push({ t: day + (market === "forex" ? 0 : OPEN_MS) + m * 60000, o, h, l, c, v });
      p = c;
    }
  }
  return out;
}
export function aggregate(c1: Candle[], tf: TF, market: Market = "nse"): Candle[] {
  const ms = TF_MIN[tf] * 60000;
  const map = new Map<number, Candle>();
  for (const c of c1) {
    const k = Math.floor((c.t - (market === "forex" ? 0 : OPEN_MS)) / ms);
    const b = map.get(k);
    if (!b) map.set(k, { ...c });
    else { b.h = Math.max(b.h, c.h); b.l = Math.min(b.l, c.l); b.c = c.c; b.v += c.v; }
  }
  return [...map.values()];
}

/* ---------------- INDICATORS ---------------- */
export function ema(v: number[], n: number) {
  const k = 2 / (n + 1); const o: number[] = [];
  v.forEach((x, i) => o.push(i ? x * k + o[i - 1] * (1 - k) : x));
  return o;
}
export function rsi(c: Candle[], n = 14) {
  let g = 0, l = 0; const o: number[] = [50];
  for (let i = 1; i < c.length; i++) {
    const d = c[i].c - c[i - 1].c;
    g = (g * (n - 1) + Math.max(d, 0)) / n; l = (l * (n - 1) + Math.max(-d, 0)) / n;
    o.push(l === 0 ? 100 : 100 - 100 / (1 + g / l));
  }
  return o;
}
export function atr(c: Candle[], n = 14) {
  const o: number[] = [];
  c.forEach((x, i) => {
    const tr = i ? Math.max(x.h - x.l, Math.abs(x.h - c[i - 1].c), Math.abs(x.l - c[i - 1].c)) : x.h - x.l;
    o.push(i ? (o[i - 1] * (n - 1) + tr) / n : tr);
  });
  return o;
}
export function vwap(c: Candle[]) {
  let pv = 0, vv = 0, day = -1; const o: number[] = [];
  for (const x of c) {
    const d = Math.floor(x.t / 86400000);
    if (d !== day) { pv = 0; vv = 0; day = d; }
    pv += ((x.h + x.l + x.c) / 3) * x.v; vv += x.v; o.push(vv > 0 ? pv / vv : Number.NaN);
  }
  return o;
}

/* ---------------- SMC ---------------- */
export type ZoneStatus = "Untouched" | "Swept" | "Reclaimed" | "Invalidated" | "Mitigated";
export type DetectionTiming = { formedAt?: number; confirmedAt?: number; availableAt?: number; strength?: number; statusAt?: number };
export type Liquidity = DetectionTiming & { kind: "BSL" | "SSL" | "EQH" | "EQL" | "PDH" | "PDL"; price: number; tf: TF; t: number; status: ZoneStatus; distPct: number; note: string };
export type Zone = DetectionTiming & { kind: "Bull OB" | "Bear OB" | "Bull FVG" | "Bear FVG" | "Bull Breaker" | "Bear Breaker"; top: number; bottom: number; tf: TF; t: number; status: ZoneStatus; fill: number; note: string };
export type StructEvent = DetectionTiming & { kind: "BOS" | "CHoCH"; dir: "bull" | "bear"; price: number; t: number; tf: TF };
export type Swing = DetectionTiming & { type: "high" | "low"; price: number; t: number; i: number; label?: string };

export type TFAnalysis = {
  symbol: string; tf: TF; candles: Candle[]; trend: "bull" | "bear" | "range";
  swings: Swing[]; events: StructEvent[]; liquidity: Liquidity[]; zones: Zone[];
  range: { high: number; low: number; eq: number } | null; zone: "Premium" | "Discount" | "Equilibrium";
  atr: number; rsi: number; ema9: number; ema20: number; ema50: number; vwap: number; relVol: number;
  displacement: "bull" | "bear" | null; lastSweep: Liquidity | null;
  ote: OTE | null;
};
/** ICT Optimal Trade Entry: 62%–79% retracement of the latest structure-breaking leg (70.5% sweet spot). */
export type OTE = { dir: "bull" | "bear"; legLow: number; legHigh: number; top: number; bottom: number; sweet: number; status: "Not reached" | "In OTE" | "Passed" | "Invalidated"; t: number };
export type Killzone = { name: string; kind: "Killzone" | "Silver Bullet"; start: string; end: string; active: boolean };
const KILLZONES: [string, Killzone["kind"], number, number][] = [
  ["Asian", "Killzone", 20, 24], ["London Open", "Killzone", 2, 5], ["New York AM", "Killzone", 7, 10], ["London Close", "Killzone", 10, 12],
  ["London Silver Bullet", "Silver Bullet", 3, 4], ["AM Silver Bullet", "Silver Bullet", 10, 11], ["PM Silver Bullet", "Silver Bullet", 14, 15],
];
/** ICT killzones and Silver Bullet windows, defined in New York time (DST-aware). */
export function ictKillzones(t: number): Killzone[] {
  const parts = new Intl.DateTimeFormat("en-GB", { timeZone: "America/New_York", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(t);
  const h = Number(parts.find((x) => x.type === "hour")?.value) + Number(parts.find((x) => x.type === "minute")?.value) / 60;
  const hh = (n: number) => `${String(n % 24).padStart(2, "0")}:00`;
  return KILLZONES.map(([name, kind, a, b]) => ({ name, kind, start: hh(a), end: hh(b), active: h >= a && h < b }));
}

function analyzeTF(c: Candle[], tf: TF, s: Settings, symbol: string, pd?: { h: number; l: number }): TFAnalysis {
  if (!c.length) throw new Error(`No complete ${tf} candles available.`);
  const n = s.fractal; const A = atr(c); const a = A[A.length - 1]; const last = c[c.length - 1];
  const closeAt = (i: number) => c[i].t + TF_MIN[tf] * 60000;
  const swings: Swing[] = [];
  for (let i = n; i < c.length - n; i++) { // only confirmed swings -> no repainting
    let hi = true, lo = true;
    for (let j = i - n; j <= i + n; j++) { if (j === i) continue; if (c[j].h >= c[i].h) hi = false; if (c[j].l <= c[i].l) lo = false; }
    const timing = { formedAt: c[i].t, confirmedAt: closeAt(i + n), availableAt: closeAt(i + n), strength: Math.min(100, 50 + n * 5) };
    if (hi) swings.push({ type: "high", price: c[i].h, t: c[i].t, i, ...timing });
    if (lo) swings.push({ type: "low", price: c[i].l, t: c[i].t, i, ...timing });
  }
  let ph: Swing | undefined, pl: Swing | undefined;
  for (const sw of swings) {
    if (sw.type === "high") { sw.label = ph ? (sw.price > ph.price ? "HH" : "LH") : "SH"; ph = sw; }
    else { sw.label = pl ? (sw.price > pl.price ? "HL" : "LL") : "SL"; pl = sw; }
  }
  // Structure: close beyond last confirmed swing
  const events: StructEvent[] = []; let trend: "bull" | "bear" | "range" = "range";
  let lh: Swing | undefined, ll: Swing | undefined; let si = 0;
  const legs: { dir: "bull" | "bear"; from: number; to: number }[] = [];
  for (let i = 0; i < c.length; i++) {
    while (si < swings.length && swings[si].i + n <= i) { const sw = swings[si++]; if (sw.type === "high") lh = sw; else ll = sw; }
    if (lh && c[i].c > lh.price) { events.push({ kind: trend === "bear" ? "CHoCH" : "BOS", dir: "bull", price: lh.price, t: c[i].t, tf }); legs.push({ dir: "bull", from: ll?.i ?? lh.i, to: i }); trend = "bull"; lh = undefined; }
    else if (ll && c[i].c < ll.price) { events.push({ kind: trend === "bull" ? "CHoCH" : "BOS", dir: "bear", price: ll.price, t: c[i].t, tf }); legs.push({ dir: "bear", from: lh?.i ?? ll.i, to: i }); trend = "bear"; ll = undefined; }
  }
  const dist = (p: number) => ((p - last.c) / last.c) * 100;
  const statusOf = (lvl: number, i0: number, up: boolean): ZoneStatus => {
    let st: ZoneStatus = "Untouched";
    for (let i = i0 + n + 1; i < c.length; i++) {
      const pierced = up ? c[i].h > lvl : c[i].l < lvl;
      if (!pierced) { if (st === "Swept" && (up ? c[i].c < lvl : c[i].c > lvl)) st = "Reclaimed"; continue; }
      if (up ? c[i].c > lvl : c[i].c < lvl) return "Invalidated";
      st = "Swept";
    }
    return st;
  };
  const liquidity: Liquidity[] = []; const recent = swings.slice(-14);
  for (const sw of recent) {
    const up = sw.type === "high"; const st = statusOf(sw.price, sw.i, up);
    liquidity.push({ kind: up ? "BSL" : "SSL", price: sw.price, tf, t: sw.t, status: st, distPct: dist(sw.price), note: `Confirmed ${n}-bar fractal swing ${up ? "high" : "low"}; resting stops likely ${up ? "above" : "below"} (inferred, not observed orders).` });
  }
  for (let x = 0; x < recent.length; x++) for (let y = x + 1; y < recent.length; y++) {
    const p = recent[x], q = recent[y];
    if (p.type === q.type && Math.abs(p.price - q.price) <= s.eqTolAtr * A[q.i + n]) {
      const up = p.type === "high"; const lvl = up ? Math.max(p.price, q.price) : Math.min(p.price, q.price);
      liquidity.push({ kind: up ? "EQH" : "EQL", price: lvl, tf, t: q.t, status: statusOf(lvl, q.i, up), distPct: dist(lvl), note: `Two swings within ${s.eqTolAtr} ATR — a liquidity pool.` });
    }
  }
  if (pd) {
    const todayStart = c.findIndex((x) => Math.floor(x.t / 86400000) === Math.floor(last.t / 86400000));
    liquidity.push({ kind: "PDH", price: pd.h, tf, t: c[todayStart].t, status: statusOf(pd.h, todayStart - n - 1, true), distPct: dist(pd.h), note: "Previous day high — external buy-side liquidity." });
    liquidity.push({ kind: "PDL", price: pd.l, tf, t: c[todayStart].t, status: statusOf(pd.l, todayStart - n - 1, false), distPct: dist(pd.l), note: "Previous day low — external sell-side liquidity." });
  }
  const lastSweep = [...liquidity].filter((l) => l.status === "Swept" || l.status === "Reclaimed").sort((p, q) => q.t - p.t)[0] ?? null;
  // Order blocks: last opposite candle before a structure-breaking leg
  const zones: Zone[] = [];
  for (const leg of legs.slice(-6)) {
    for (let i = leg.to; i >= leg.from; i--) {
      const bearC = c[i].c < c[i].o;
      if ((leg.dir === "bull" && bearC) || (leg.dir === "bear" && !bearC)) {
        const top = c[i].h, bottom = c[i].l; let st: ZoneStatus = "Untouched";
        for (let k = leg.to + 1; k < c.length; k++) {
          if (leg.dir === "bull" ? c[k].c < bottom : c[k].c > top) {
            st = "Invalidated";
            // Breaker block: a failed OB flips polarity once price closes through it.
            let bs: ZoneStatus = "Untouched";
            for (let m = k + 1; m < c.length; m++) {
              if (leg.dir === "bull" ? c[m].c > top : c[m].c < bottom) { bs = "Invalidated"; break; }
              if (leg.dir === "bull" ? c[m].h >= bottom : c[m].l <= top) bs = "Mitigated";
            }
            zones.push({ kind: leg.dir === "bull" ? "Bear Breaker" : "Bull Breaker", top, bottom, tf, t: c[k].t, formedAt: c[i].t, confirmedAt: closeAt(k), availableAt: closeAt(k), strength: 60, status: bs, fill: 0, note: `Failed ${leg.dir === "bull" ? "bullish" : "bearish"} order block; price closed through it, so it may now act as ${leg.dir === "bull" ? "resistance" : "support"}.` });
            break;
          }
          if (leg.dir === "bull" ? c[k].l <= top : c[k].h >= bottom) st = "Mitigated";
        }
        zones.push({ kind: leg.dir === "bull" ? "Bull OB" : "Bear OB", top, bottom, tf, t: c[i].t, formedAt: c[i].t, confirmedAt: closeAt(leg.to), availableAt: closeAt(leg.to), strength: Math.min(100, 50 + 10 * Math.abs(c[leg.to].c - c[leg.to].o) / Math.max(A[leg.to], 1e-9)), status: st, fill: 0, note: `Last ${leg.dir === "bull" ? "down" : "up"} candle before ${leg.dir === "bull" ? "bullish" : "bearish"} structure break.` });
        break;
      }
    }
  }
  // FVGs (3-candle imbalance), last 80 bars
  for (let i = Math.max(2, c.length - 80); i < c.length; i++) {
    const bull = c[i - 2].h < c[i].l, bear = c[i - 2].l > c[i].h;
    if (!bull && !bear) continue;
    const top = bull ? c[i].l : c[i - 2].l, bottom = bull ? c[i - 2].h : c[i].h;
    if (top - bottom < 0.1 * A[i]) continue;
    let fill = 0; let st: ZoneStatus = "Untouched";
    for (let k = i + 1; k < c.length; k++) {
      const f = bull ? (top - c[k].l) / (top - bottom) : (c[k].h - bottom) / (top - bottom);
      fill = Math.max(fill, Math.min(1, Math.max(0, f)));
      if (bull ? c[k].c < bottom : c[k].c > top) { st = "Invalidated"; break; }
    }
    if (st !== "Invalidated" && fill > 0) st = "Mitigated";
    zones.push({ kind: bull ? "Bull FVG" : "Bear FVG", top, bottom, tf, t: c[i - 1].t, formedAt: c[i - 2].t, confirmedAt: closeAt(i), availableAt: closeAt(i), strength: Math.min(100, 40 + 30 * (top - bottom) / Math.max(A[i], 1e-9)), status: st, fill, note: `Gap between candle 1 and 3; CE (50%) at ${fmtPrice(symbol, (top + bottom) / 2)}. Filled ${(fill * 100).toFixed(0)}%.` });
  }
  const hs = swings.filter((x) => x.type === "high").slice(-3), ls = swings.filter((x) => x.type === "low").slice(-3);
  const range = hs.length && ls.length ? { high: Math.max(...hs.map((x) => x.price)), low: Math.min(...ls.map((x) => x.price)), eq: 0 } : null;
  if (range) range.eq = (range.high + range.low) / 2;
  const zone = !range ? "Equilibrium" : last.c > range.eq + 0.05 * (range.high - range.low) ? "Premium" : last.c < range.eq - 0.05 * (range.high - range.low) ? "Discount" : "Equilibrium";
  let displacement: "bull" | "bear" | null = null;
  for (let i = c.length - 10; i < c.length; i++) if (i > 0 && Math.abs(c[i].c - c[i].o) > s.dispAtr * A[i - 1]) displacement = c[i].c > c[i].o ? "bull" : "bear";
  let ote: OTE | null = null;
  const lastLeg = legs[legs.length - 1];
  if (lastLeg) {
    const seg = c.slice(lastLeg.from);
    const bull = lastLeg.dir === "bull";
    const legLow = bull ? Math.min(...c.slice(lastLeg.from, lastLeg.to + 1).map((x) => x.l)) : Math.min(...seg.map((x) => x.l));
    const legHigh = bull ? Math.max(...seg.map((x) => x.h)) : Math.max(...c.slice(lastLeg.from, lastLeg.to + 1).map((x) => x.h));
    const r = legHigh - legLow;
    if (r > 0) {
      const lvl = (f: number) => bull ? legHigh - f * r : legLow + f * r;
      const top = Math.max(lvl(0.62), lvl(0.79)), bottom = Math.min(lvl(0.62), lvl(0.79));
      const px = last.c;
      const status: OTE["status"] = bull ? (px < legLow ? "Invalidated" : px < bottom ? "Passed" : px <= top ? "In OTE" : "Not reached") : (px > legHigh ? "Invalidated" : px > top ? "Passed" : px >= bottom ? "In OTE" : "Not reached");
      ote = { dir: lastLeg.dir, legLow, legHigh, top, bottom, sweet: lvl(0.705), status, t: c[lastLeg.from].t };
    }
  }
  const closes = c.map((x) => x.c); const vols = c.slice(-21, -1).map((x) => x.v);
  for (const event of events) Object.assign(event, { formedAt: event.t, confirmedAt: event.t + TF_MIN[tf] * 60000, availableAt: event.t + TF_MIN[tf] * 60000, strength: 60 });
  for (const z of zones) {
    if (!z.availableAt) {
      const leg = legs.find((l) => c[l.from].t <= z.t && c[l.to].t >= z.t);
      const availableAt = z.kind.includes("Breaker") ? z.t + TF_MIN[tf] * 60000 : leg ? closeAt(leg.to) : last.t + TF_MIN[tf] * 60000;
      Object.assign(z, { formedAt: z.t, confirmedAt: availableAt, availableAt, strength: 60 });
    }
    z.statusAt = closeAt(c.length - 1);
  }
  for (const l of liquidity) {
    const sw = swings.find((x) => x.t === l.t);
    const availableAt = l.kind.startsWith("PD") ? l.t : sw?.availableAt ?? closeAt(c.length - 1);
    Object.assign(l, { formedAt: l.t, confirmedAt: availableAt, availableAt, strength: l.kind.startsWith("EQ") ? 75 : 60, statusAt: closeAt(c.length - 1) });
  }
  return {
    symbol, tf, candles: c, trend, swings, events, liquidity, zones, range, zone, atr: a,
    rsi: rsi(c).at(-1) ?? 50, ema9: ema(closes, 9).at(-1) ?? last.c, ema20: ema(closes, 20).at(-1) ?? last.c, ema50: ema(closes, 50).at(-1) ?? last.c,
    vwap: vwap(c).at(-1) ?? Number.NaN, relVol: vols.some((v) => v > 0) ? last.v / (vols.reduce((p, q) => p + q, 0) / Math.max(1, vols.length)) : Number.NaN, displacement, lastSweep, ote,
  };
}

/* ---------------- ANALYSTS, SCORING, JUDGE ---------------- */
export type Evidence = { cat: Category; text: string; pts: number };
export type Plan = { dir: "BUY" | "SELL"; entryLow: number; entryHigh: number; sl: number; targets: { price: number; why: string }[]; rr: number; qty: number; risk: number; invalidation: string; confirmation: string[] };
export type Report = {
  divergence: PairDivergence | null; killzones: Killzone[];
  market: Market; profile: VolumeProfile | null; previousProfile: VolumeProfile | null; volumeContext: string; activeSessions: string[];
  symbol: string; generatedAt: number; dataAsOf: number; source: "DEMO" | "SUPPLIED" | "TWELVE_DATA";
  tfs: Record<TF, TFAnalysis>; session: { orh: number; orl: number; gapPct: number; pdh: number; pdl: number; pdc: number; dayHigh: number; dayLow: number };
  bull: { score: number; ev: Evidence[] }; bear: { score: number; ev: Evidence[] }; neutral: number; conflictPenalty: number;
  decision: "BUY" | "SELL" | "WAIT"; reasons: string[]; plan: Plan | null; price: number;
};

function scoreSide(ev: Evidence[], w: Settings["weights"]) {
  const per: Partial<Record<Category, number>> = {};
  for (const e of ev) per[e.cat] = Math.min(1, (per[e.cat] ?? 0) + e.pts);
  return Object.entries(w).reduce((s, [k, wt]) => s + (per[k as Category] ?? 0) * wt, 0);
}

export function analyze(symbol: string, s: Settings = DEFAULT_SETTINGS, c1Override?: Candle[], pair?: PairOptions, peerOverride?: Candle[], source: Report["source"] = c1Override ? "SUPPLIED" : "DEMO", research?: { asOf: number; completeOnly: boolean }): Report {
  const market = marketOf(symbol);
  if (research && !c1Override) throw new Error("Research requires supplied historical candles.");
  const c1 = (c1Override ?? demoSeries(symbol)).filter((c) => !research || c.t + 60000 <= research.asOf);
  const peer = pair?.symbol ?? PAIR_COMPARISONS[symbol]?.[0]?.symbol;
  // Caller-provided primary candles must never use a simulated peer.
  const divergence = market === "forex" && peer ? pairDivergence(symbol, peer, pair?.tf ?? "5m", closedForexBars(c1, pair?.tf ?? "5m"), closedForexBars(peerOverride ?? (c1Override ? [] : demoSeries(peer)), pair?.tf ?? "5m"), (c1.at(-1)?.t ?? 0) + 60000) : null;
  if (c1.length < 30) throw new Error("At least 30 candles across two trading days are required.");
  const lastDay = Math.floor(c1[c1.length - 1].t / 86400000);
  const prev = c1.filter((x) => Math.floor(x.t / 86400000) < lastDay);
  if (!prev.length) throw new Error("Previous day candles are required.");
  const prevDay = Math.floor(prev[prev.length - 1].t / 86400000);
  const pdBars = prev.filter((x) => Math.floor(x.t / 86400000) === prevDay);
  const today = c1.filter((x) => Math.floor(x.t / 86400000) === lastDay);
  const pd = { h: Math.max(...pdBars.map((x) => x.h)), l: Math.min(...pdBars.map((x) => x.l)) };
  const or = today.slice(0, 15);
  const session = {
    orh: Math.max(...or.map((x) => x.h)), orl: Math.min(...or.map((x) => x.l)),
    gapPct: ((today[0].o - pdBars[pdBars.length - 1].c) / pdBars[pdBars.length - 1].c) * 100, pdh: pd.h, pdl: pd.l, pdc: pdBars[pdBars.length - 1].c,
    dayHigh: Math.max(...today.map((x) => x.h)), dayLow: Math.min(...today.map((x) => x.l)),
  };
  const tfs = {} as Record<TF, TFAnalysis>;
  for (const tf of TFS) {
    const bars = research?.completeOnly ? closedSessionBars(c1, tf, market, research.asOf) : source === "TWELVE_DATA" ? closedForexBars(c1, tf) : aggregate(c1, tf, market);
    if (research && bars.length < 20) throw new Error(`Need at least 20 complete ${tf} candles; upload more one-minute history.`);
    if (source === "TWELVE_DATA" && bars.length < 50) throw new Error("Need at least 50 complete candles in each timeframe.");
    tfs[tf] = analyzeTF(tf === "1m" ? bars.slice(-300) : tf === "5m" ? bars.slice(-225) : bars, tf, s, symbol, pd);
  }
  const price = c1[c1.length - 1].c;
  const profile = volumeProfile(today.slice(0, -2));
  const previousProfile = volumeProfile(pdBars);
  const recent = today.slice(-2);
  const volumeContext = !profile ? "Not enough volume data" : recent.every((c) => c.c > profile.vah) ? "Two closes above value — upward acceptance candidate" : recent.every((c) => c.c < profile.val) ? "Two closes below value — downward acceptance candidate" : recent.some((c) => c.h > profile.vah) && price <= profile.vah && price >= profile.val ? "Upper value-area rejection candidate" : recent.some((c) => c.l < profile.val) && price >= profile.val && price <= profile.vah ? "Lower value-area rejection candidate" : "Inside or crossing value — no directional volume confirmation";
  const bull: Evidence[] = [], bear: Evidence[] = [];
  const [h1, m15, m5, m1] = [tfs["1h"], tfs["15m"], tfs["5m"], tfs["1m"]];
  // structure
  for (const [t, w] of [[m15, 0.6], [m5, 0.4]] as const) {
    const ev = t.events.at(-1);
    if (ev && t.trend === "bull") bull.push({ cat: "structure", pts: w, text: `${t.tf} structure bullish (last ${ev.kind} up at ${fmtPrice(symbol, ev.price)}).` });
    if (ev && t.trend === "bear") bear.push({ cat: "structure", pts: w, text: `${t.tf} structure bearish (last ${ev.kind} down at ${fmtPrice(symbol, ev.price)}).` });
  }
  // MTF
  const aligned = (d: "bull" | "bear") => [h1, m15, m5].filter((t) => t.trend === d).length;
  if (h1.trend === "bull") bull.push({ cat: "mtf", pts: 0.5, text: "1H bias bullish." });
  if (h1.trend === "bear") bear.push({ cat: "mtf", pts: 0.5, text: "1H bias bearish." });
  if (aligned("bull") === 3) bull.push({ cat: "mtf", pts: 0.5, text: "1H, 15M, 5M all bullish — aligned." });
  if (aligned("bear") === 3) bear.push({ cat: "mtf", pts: 0.5, text: "1H, 15M, 5M all bearish — aligned." });
  // liquidity
  for (const t of [m15, m5]) {
    const sw = t.lastSweep;
    if (sw && (sw.kind === "SSL" || sw.kind === "EQL" || sw.kind === "PDL")) bull.push({ cat: "liquidity", pts: sw.status === "Reclaimed" ? 0.6 : 0.4, text: `${t.tf}: sell-side liquidity (${sw.kind} ${fmtPrice(symbol, sw.price)}) ${sw.status.toLowerCase()} — stop hunt below, price back above.` });
    if (sw && (sw.kind === "BSL" || sw.kind === "EQH" || sw.kind === "PDH")) bear.push({ cat: "liquidity", pts: sw.status === "Reclaimed" ? 0.6 : 0.4, text: `${t.tf}: buy-side liquidity (${sw.kind} ${fmtPrice(symbol, sw.price)}) ${sw.status.toLowerCase()} — failed breakout above.` });
  }
  const untouchedAbove = m15.liquidity.filter((l) => l.status === "Untouched" && l.price > price);
  const untouchedBelow = m15.liquidity.filter((l) => l.status === "Untouched" && l.price < price);
  if (untouchedAbove.length) bull.push({ cat: "liquidity", pts: 0.3, text: `${untouchedAbove.length} untouched buy-side targets above (draw on liquidity).` });
  if (untouchedBelow.length) bear.push({ cat: "liquidity", pts: 0.3, text: `${untouchedBelow.length} untouched sell-side targets below (draw on liquidity).` });
  if (m15.zone === "Discount") bull.push({ cat: "liquidity", pts: 0.2, text: "Price in 15M discount zone." });
  if (m15.zone === "Premium") bear.push({ cat: "liquidity", pts: 0.2, text: "Price in 15M premium zone." });
  // OB / FVG
  const live = (z: Zone) => z.status !== "Invalidated";
  for (const t of [m15, m5]) {
    const bz = t.zones.filter((z) => live(z) && z.kind.startsWith("Bull") && z.top <= price && price - z.top < 2 * t.atr);
    const sz = t.zones.filter((z) => live(z) && z.kind.startsWith("Bear") && z.bottom >= price && z.bottom - price < 2 * t.atr);
    if (bz.length) bull.push({ cat: "obfvg", pts: 0.5, text: `${t.tf}: ${bz.length} valid bullish OB/FVG just below price (${bz.map((z) => z.kind).join(", ")}).` });
    if (sz.length) bear.push({ cat: "obfvg", pts: 0.5, text: `${t.tf}: ${sz.length} valid bearish OB/FVG just above price (${sz.map((z) => z.kind).join(", ")}).` });
  }
  // momentum
  for (const t of [m5, m1]) {
    if (t.displacement === "bull") bull.push({ cat: "momentum", pts: 0.5, text: `${t.tf}: bullish displacement candle.` });
    if (t.displacement === "bear") bear.push({ cat: "momentum", pts: 0.5, text: `${t.tf}: bearish displacement candle.` });
  }
  if (m5.rsi > 55 && m5.rsi < 75) bull.push({ cat: "momentum", pts: 0.3, text: `5M RSI ${m5.rsi.toFixed(0)} — positive momentum.` });
  if (m5.rsi < 45 && m5.rsi > 25) bear.push({ cat: "momentum", pts: 0.3, text: `5M RSI ${m5.rsi.toFixed(0)} — negative momentum.` });
  // volume
  const lc = m5.candles[m5.candles.length - 1];
  if (m5.relVol > 1.3) (lc.c > lc.o ? bull : bear).push({ cat: "volume", pts: 0.7, text: `5M relative volume ${m5.relVol.toFixed(1)}x on a ${lc.c > lc.o ? "green" : "red"} candle.` });
  if (profile && recent.every((c) => c.c > profile.vah)) bull.push({ cat: "volume", pts: 0.3, text: "Two closes above estimated VAH; acceptance candidate, not a standalone entry." });
  if (profile && recent.every((c) => c.c < profile.val)) bear.push({ cat: "volume", pts: 0.3, text: "Two closes below estimated VAL; acceptance candidate, not a standalone entry." });
  if (Number.isFinite(m5.vwap)) {
    if (price > m5.vwap) bull.push({ cat: "volume", pts: 0.3, text: `Price above VWAP ${fmtPrice(symbol, m5.vwap)}.` });
    else bear.push({ cat: "volume", pts: 0.3, text: `Price below VWAP ${fmtPrice(symbol, m5.vwap)}.` });
  }
  // indicators
  if (m5.ema9 > m5.ema20 && m5.ema20 > m5.ema50) bull.push({ cat: "indicators", pts: 1, text: "5M EMA 9 > 20 > 50." });
  if (m5.ema9 < m5.ema20 && m5.ema20 < m5.ema50) bear.push({ cat: "indicators", pts: 1, text: "5M EMA 9 < 20 < 50." });

  const bs = scoreSide(bull, s.weights), ss = scoreSide(bear, s.weights);
  const conflictPenalty = Math.round(Math.min(bs, ss) * 0.5);
  const neutral = Math.max(0, 100 - Math.max(bs, ss));
  const plan = buildPlan(bs >= ss ? "BUY" : "SELL", tfs, price, s, symbol);
  return { killzones: market === "forex" ? ictKillzones(c1[c1.length - 1].t) : [], divergence, market, profile, previousProfile, volumeContext, activeSessions: market === "forex" ? forexSessions(c1[c1.length - 1].t) : [symbol.startsWith("BSE:") ? "BSE" : "NSE"], symbol, generatedAt: research?.asOf ?? Date.now(), dataAsOf: c1[c1.length - 1].t + (source === "TWELVE_DATA" || research ? 60000 : 0), source, tfs, session, bull: { score: Math.round(bs), ev: bull }, bear: { score: Math.round(ss), ev: bear }, neutral: Math.round(neutral), conflictPenalty, price, ...judge(bs, ss, conflictPenalty, h1.trend, m5.trend, plan, s) };
}

export function judge(bs: number, ss: number, penalty: number, htf: string, ltf: string, plan: Plan | null, s: Settings) {
  const reasons: string[] = [];
  const side = bs >= ss ? "BUY" : "SELL";
  const net = Math.abs(bs - ss) - penalty;
  const top = Math.max(bs, ss);
  const want = side === "BUY" ? "bull" : "bear", against = side === "BUY" ? "bear" : "bull";
  if (top < 55) reasons.push(`Strongest side scores ${Math.round(top)}/100 — below 55 threshold.`);
  if (net < 15) reasons.push(`Edge after conflict penalty is only ${Math.round(net)} points (need 15).`);
  if (htf === against) reasons.push(`1H bias is ${htf === "bull" ? "bullish" : "bearish"} — conflicts with a ${side}.`);
  if (ltf !== want) reasons.push(`5M entry structure is not yet ${want === "bull" ? "bullish" : "bearish"} — no confirmation.`);
  if (!plan) reasons.push("No valid OB/FVG entry zone with structural stop found.");
  else if (plan.rr < s.minRR) reasons.push(`Risk-to-reward ${plan.rr.toFixed(1)} is below minimum ${s.minRR}.`);
  if (reasons.length) return { decision: "WAIT" as const, reasons, plan: plan && plan.dir === side ? plan : null };
  return { decision: side as "BUY" | "SELL", reasons: [`${side} side leads ${Math.round(bs)} vs ${Math.round(ss)}, HTF not opposing, 5M confirms, R:R ${plan?.rr.toFixed(1)}.`], plan };
}

function buildPlan(dir: "BUY" | "SELL", tfs: Record<TF, TFAnalysis>, price: number, s: Settings, symbol: string): Plan | null {
  const a = tfs["5m"].atr; const bull = dir === "BUY";
  const zones = [...tfs["5m"].zones, ...tfs["15m"].zones].filter((z) => z.status !== "Invalidated" && z.kind.startsWith(bull ? "Bull" : "Bear") && (bull ? z.top <= price * 1.001 : z.bottom >= price * 0.999))
    .sort((p, q) => (bull ? q.top - p.top : p.bottom - q.bottom));
  const z = zones[0]; if (!z) return null;
  const entryLow = z.bottom, entryHigh = z.top; const entry = (entryLow + entryHigh) / 2;
  const sl = bull ? entryLow - 0.25 * a : entryHigh + 0.25 * a; const risk = Math.abs(entry - sl);
  if (risk <= 0) return null;
  const liq = [...tfs["15m"].liquidity, ...tfs["1h"].liquidity].filter((l) => l.status === "Untouched" && (bull ? l.price > entry + risk : l.price < entry - risk))
    .sort((p, q) => (bull ? p.price - q.price : q.price - p.price));
  const seen: number[] = []; const targets: Plan["targets"] = [];
  for (const l of liq) { if (seen.some((x) => Math.abs(x - l.price) < 0.3 * a)) continue; seen.push(l.price); targets.push({ price: l.price, why: `${l.tf} ${l.kind} (untouched liquidity)` }); if (targets.length === 3) break; }
  if (!targets.length) return null;
  const qty = marketOf(symbol) === "forex" ? 0 : Math.floor((s.capital * s.riskPct) / 100 / risk);
  return {
    dir, entryLow, entryHigh, sl, targets, rr: Math.abs(targets[0].price - entry) / risk, qty, risk: qty * risk,
    invalidation: `${z.tf} candle close ${bull ? "below" : "above"} ${fmtPrice(symbol, bull ? entryLow : entryHigh)} invalidates the ${z.kind}.`,
    confirmation: [`Price taps ${z.tf} ${z.kind} ${fmtPrice(symbol, entryLow)}–${fmtPrice(symbol, entryHigh)}`, `1M ${bull ? "bullish" : "bearish"} CHoCH inside the zone`, Number.isFinite(tfs["5m"].relVol) ? "Volume above 20-bar average on trigger candle" : "Volume confirmation unavailable from this feed — price-only research", marketOf(symbol) === "forex" ? "Check broker spread, rollover and economic news before entry; lot sizing unavailable" : "Exit all by 15:15 IST"],
  };
}

export const fmtTime = (t: number) => new Date(t).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", hour12: false });
