export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      backtest_runs: {
        Row: {
          configuration: Json
          created_at: string
          id: string
          results: Json | null
          status: string
          user_id: string
        }
        Insert: {
          configuration: Json
          created_at?: string
          id?: string
          results?: Json | null
          status?: string
          user_id: string
        }
        Update: {
          configuration?: Json
          created_at?: string
          id?: string
          results?: Json | null
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      backtest_trades: {
        Row: {
          id: string
          run_id: string
          trade: Json
          user_id: string
        }
        Insert: {
          id?: string
          run_id: string
          trade: Json
          user_id: string
        }
        Update: {
          id?: string
          run_id?: string
          trade?: Json
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "backtest_trades_run_id_fkey"
            columns: ["run_id"]
            isOneToOne: false
            referencedRelation: "backtest_runs"
            referencedColumns: ["id"]
          },
        ]
      }
      kite_sessions: {
        Row: {
          expires_at: string
          id: string
          token_ciphertext: string
          updated_at: string
        }
        Insert: {
          expires_at: string
          id: string
          token_ciphertext: string
          updated_at?: string
        }
        Update: {
          expires_at?: string
          id?: string
          token_ciphertext?: string
          updated_at?: string
        }
        Relationships: []
      }
      market_regimes: {
        Row: {
          created_at: string
          id: string
          prediction_id: string
          regime: Json
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          prediction_id: string
          regime: Json
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          prediction_id?: string
          regime?: Json
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "market_regimes_prediction_id_fkey"
            columns: ["prediction_id"]
            isOneToOne: false
            referencedRelation: "predictions"
            referencedColumns: ["id"]
          },
        ]
      }
      model_evaluations: {
        Row: {
          evaluated_at: string
          id: string
          metrics: Json
          model_id: string
          user_id: string
        }
        Insert: {
          evaluated_at?: string
          id?: string
          metrics: Json
          model_id: string
          user_id: string
        }
        Update: {
          evaluated_at?: string
          id?: string
          metrics?: Json
          model_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "model_evaluations_model_id_fkey"
            columns: ["model_id"]
            isOneToOne: false
            referencedRelation: "model_registry"
            referencedColumns: ["id"]
          },
        ]
      }
      model_registry: {
        Row: {
          artifact_reference: string | null
          created_at: string
          id: string
          metadata: Json
          status: string
          task: string
          user_id: string
          version: string
        }
        Insert: {
          artifact_reference?: string | null
          created_at?: string
          id?: string
          metadata?: Json
          status?: string
          task: string
          user_id: string
          version: string
        }
        Update: {
          artifact_reference?: string | null
          created_at?: string
          id?: string
          metadata?: Json
          status?: string
          task?: string
          user_id?: string
          version?: string
        }
        Relationships: []
      }
      prediction_features: {
        Row: {
          created_at: string
          feature_version: string
          features: Json
          id: string
          prediction_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          feature_version: string
          features: Json
          id?: string
          prediction_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          feature_version?: string
          features?: Json
          id?: string
          prediction_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "prediction_features_prediction_id_fkey"
            columns: ["prediction_id"]
            isOneToOne: false
            referencedRelation: "predictions"
            referencedColumns: ["id"]
          },
        ]
      }
      prediction_outcomes: {
        Row: {
          created_at: string
          evaluated_through: string
          id: string
          outcome: Json
          prediction_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          evaluated_through: string
          id?: string
          outcome: Json
          prediction_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          evaluated_through?: string
          id?: string
          outcome?: Json
          prediction_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "prediction_outcomes_prediction_id_fkey"
            columns: ["prediction_id"]
            isOneToOne: true
            referencedRelation: "predictions"
            referencedColumns: ["id"]
          },
        ]
      }
      predictions: {
        Row: {
          created_at: string
          data_source: string
          exchange: string
          feature_version: string
          horizon_minutes: number
          id: string
          model_version: string | null
          output: Json
          prediction_timestamp: string
          rule_engine_version: string
          snapshot: Json
          snapshot_hash: string
          symbol: string
          timeframe: string
          user_id: string
        }
        Insert: {
          created_at?: string
          data_source: string
          exchange?: string
          feature_version: string
          horizon_minutes: number
          id?: string
          model_version?: string | null
          output: Json
          prediction_timestamp: string
          rule_engine_version: string
          snapshot: Json
          snapshot_hash: string
          symbol: string
          timeframe: string
          user_id: string
        }
        Update: {
          created_at?: string
          data_source?: string
          exchange?: string
          feature_version?: string
          horizon_minutes?: number
          id?: string
          model_version?: string | null
          output?: Json
          prediction_timestamp?: string
          rule_engine_version?: string
          snapshot?: Json
          snapshot_hash?: string
          symbol?: string
          timeframe?: string
          user_id?: string
        }
        Relationships: []
      }
      research_paper_trades: {
        Row: {
          created_at: string
          id: string
          trade: Json
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          trade: Json
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          trade?: Json
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
