import { describe, expect, it } from "vitest";
import { screenshotLiveSymbol } from "@/lib/screenshot-live";

describe("screenshot to live pair handoff", () => {
  it("recognizes supported Forex and Gold tickers without guessing", () => {
    expect(screenshotLiveSymbol("EURUSD")).toBe("EURUSD");
    expect(screenshotLiveSymbol(" EUR / USD ")).toBe("EURUSD");
    expect(screenshotLiveSymbol("OANDA:XAUUSD")).toBe("XAUUSD");
    expect(screenshotLiveSymbol("FX:GBPUSD")).toBe("GBPUSD");
  });
  it("does not substitute a pair for unknown, unreadable or NSE symbols", () => {
    for (const symbol of [null, "", "NSE:RELIANCE", "EUR", "EURUSD maybe", "BTCUSD", "https://example.com/EURUSD"]) {
      expect(screenshotLiveSymbol(symbol)).toBeNull();
    }
  });
});