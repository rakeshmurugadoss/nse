import { describe, expect, it } from "vitest";
import { parseScreenshotResponse, SCREENSHOT_TOPICS, screenshotInput, screenshotResult, validateScreenshot } from "@/lib/screenshot";

describe("screenshot uploads", () => {
  it("accepts PNG, JPEG and WEBP", () => {
    for (const type of ["image/png", "image/jpeg", "image/webp"]) expect(validateScreenshot({ type, size: 1024 })).toBe("");
    expect(validateScreenshot({ type: "image/svg+xml", size: 1024 })).not.toBe("");
  });
  it("retains the 8 MB limit", () => {
    expect(validateScreenshot({ type: "image/png", size: 8 * 1024 * 1024 })).toBe("");
    expect(validateScreenshot({ type: "image/png", size: 8 * 1024 * 1024 + 1 })).not.toBe("");
  });
  it("does not send remote URLs or SVG data to the model", () => {
    expect(screenshotInput.safeParse({ image: "https://example.com/private", language: "en" }).success).toBe(false);
    expect(screenshotInput.safeParse({ image: "data:image/svg+xml;base64,AAAA", language: "en" }).success).toBe(false);
    expect(screenshotInput.safeParse({ image: "data:image/png;base64,AAAA", language: "ta" }).success).toBe(true);
  });
});

describe("screenshot response handling", () => {
  const section = { visibility: "partial", reading: "Lower highs are visible on the right; hidden bars cannot be assessed.", evidence: ["Two lower swing peaks at the right edge."] };
  const sections = { structure: section, liquidity: section, smc: section, levels: section, volume: { visibility: "not_visible", reading: "No volume panel is visible; volume confirmation is unavailable.", evidence: [] }, context: section };
  const report = { isChart: true, readable: true, symbol: "EURUSD", timeframe: "5m", trend: "bear", summary: "Visible downward movement.", observations: ["Lower highs."], limitations: ["Candle data unavailable."], sections, keyLevels: [{ kind: "resistance", priceLabel: null, location: "Recent swing high on the right.", significance: "Repeated rejection area." }], annotations: [{ kind: "bear_fvg", label: "Bear FVG?", x: 0.6, y: 0.2, w: 0.1, h: 0.05 }], judge: { bullPoints: [], bearPoints: ["Lower highs."], lean: "bear", strength: "medium", verdict: "Visual lean bearish; unverified." }, plan: { available: true, direction: "short", entry: { price: "≈1.1650", y: 0.3, note: "Bear FVG" }, stop: { price: null, y: null, note: "Axis not legible" }, target1: { price: "1.1600", y: 0.7, note: "EQL" }, target2: { price: null, y: null, note: "n/a" }, rationale: "Lower highs into FVG." }, scenarios: { bullish: "Watch whether the visible lower high is reclaimed.", bearish: "Watch whether the visible low breaks and holds below.", wait: "Wait while price stays between the visible swings." } };
  const output = [{ type: "message", content: [{ type: "output_text", text: JSON.stringify(report) }] }];
  it("requires every detailed screenshot topic instead of accepting a summary-only report", () => {
    for (const topic of SCREENSHOT_TOPICS) {
      const incomplete = { ...sections, [topic]: undefined };
      expect(screenshotResult.safeParse({ ...report, sections: incomplete }).success).toBe(false);
    }
    expect(screenshotResult.safeParse({ ...report, sections: undefined }).success).toBe(false);
  });
  it("keeps absent volume and unreadable price levels explicitly unavailable", () => {
    const parsed = parseScreenshotResponse({ output });
    expect(parsed.sections.volume.visibility).toBe("not_visible");
    expect(parsed.sections.volume.evidence).toEqual([]);
    expect(parsed.keyLevels[0].priceLabel).toBeNull();
  });
  it("rejects chart marks placed outside the picture", () => {
    expect(screenshotResult.safeParse({ ...report, annotations: [{ ...report.annotations[0], x: 1.4 }] }).success).toBe(false);
  });
  it("requires a trade plan and keeps plan lines inside the picture", () => {
    expect(screenshotResult.safeParse({ ...report, plan: undefined }).success).toBe(false);
    expect(screenshotResult.safeParse({ ...report, plan: { ...report.plan, entry: { ...report.plan.entry, y: 1.2 } } }).success).toBe(false);
  });
  it("requires bull/bear judge points with a lean", () => {
    expect(screenshotResult.safeParse({ ...report, judge: undefined }).success).toBe(false);
  });
  it("requires separate bullish, bearish and wait conditions", () => {
    for (const key of ["bullish", "bearish", "wait"]) {
      expect(screenshotResult.safeParse({ ...report, scenarios: { ...report.scenarios, [key]: undefined } }).success).toBe(false);
    }
  });
  it("accepts validated output when the optional gateway status is absent", () => {
    expect(parseScreenshotResponse({ output })).toEqual(report);
    expect(parseScreenshotResponse({ status: "completed", output })).toEqual(report);
  });
  it("rejects explicit incomplete or failed output even with valid JSON", () => {
    for (const status of ["incomplete", "failed", "cancelled", "queued", "in_progress"]) {
      expect(() => parseScreenshotResponse({ status, output })).toThrow();
    }
    expect(() => parseScreenshotResponse({ output, incomplete_details: { reason: "max_output_tokens" } })).toThrow();
    expect(() => parseScreenshotResponse({ output, error: { code: "server_error" } })).toThrow();
  });
  it("rejects refusals, empty output and invalid reports", () => {
    expect(() => parseScreenshotResponse({ output: [...output, { type: "message", content: [{ type: "refusal" }] }] })).toThrow();
    expect(() => parseScreenshotResponse({ output: [] })).toThrow();
    expect(() => parseScreenshotResponse({ output: [{ type: "message", content: [{ type: "output_text", text: '{"symbol":"EURUSD"}' }] }] })).toThrow();
  });
});