import { describe, expect, it } from "vitest";
import { analyze, demoSeries, pairDivergence, type Candle } from "@/lib/engine";

const end = 62 * 60000;
function fixture(inverse = false) {
  let p = 100, q = 100;
  const a: Candle[] = [], b: Candle[] = [];
  for (let i = 0; i < 62; i++) {
    const move = Math.sin(i * 1.7) * 0.0004;
    p *= Math.exp(move); q *= Math.exp(inverse ? -move : move);
    a.push({ t: i * 60000, o: p, c: p, h: p + 1, l: p - 1, v: 100 });
    b.push({ t: i * 60000, o: q, c: q, h: q + 1, l: q - 1, v: 100 });
  }
  // Comparison candle stays strictly inside its prior range.
  b[61] = { ...b[61], h: q + 0.2, l: q - 0.2 };
  return { a, b };
}
function sweep(a: Candle[], side: "low" | "high") {
  const ref = a.slice(41, 61), c = a[61];
  a[61] = side === "low" ? { ...c, l: Math.min(...ref.map((x) => x.l)) - 0.5 } : { ...c, h: Math.max(...ref.map((x) => x.h)) + 0.5 };
}
describe("Correlated pair divergence confirmation", () => {
  it.each(["low", "high"] as const)("detects positive-pair %s sweep and reclaim", (side) => {
    const { a, b } = fixture(); sweep(a, side);
    const r = pairDivergence("EURUSD", "GBPUSD", "1m", a, b, end);
    expect(r.status).toBe(side === "low" ? "Bullish divergence" : "Bearish divergence");
    expect(r.correlation).toBeCloseTo(1);
    expect(r.samples).toBe(60);
  });
  it.each(["low", "high"] as const)("handles inverse-pair %s sweep", (side) => {
    const { a, b } = fixture(true); sweep(a, side);
    const r = pairDivergence("EURUSD", "USDCHF", "1m", a, b, end);
    expect(r.status).toBe(side === "low" ? "Bullish divergence" : "Bearish divergence");
    expect(r.correlation).toBeCloseTo(-1);
  });
  it("does not confirm when both pairs sweep", () => {
    const { a, b } = fixture(); sweep(a, "low"); sweep(b, "low");
    expect(pairDivergence("EURUSD", "GBPUSD", "1m", a, b, end).status).toBe("No divergence");
  });
  it("requires a reclaim, not a breakout", () => {
    const { a, b } = fixture(); sweep(a, "low"); a[61].c = a[61].l;
    expect(pairDivergence("EURUSD", "GBPUSD", "1m", a, b, end).status).toBe("No divergence");
  });
  it("does not treat an inverse relationship as positive", () => {
    const { a, b } = fixture(true); sweep(a, "low");
    expect(pairDivergence("EURUSD", "GBPUSD", "1m", a, b, end).status).toBe("Unconfirmed");
  });
  it("rejects flat returns", () => {
    const { a, b } = fixture(); b.forEach((c) => { c.o = 100; c.c = 100; c.h = 101; c.l = 99; });
    expect(pairDivergence("EURUSD", "GBPUSD", "1m", a, b, end).correlation).toBeNull();
  });
  it.each(["missing", "duplicate", "stale"])("rejects %s peer candles", (kind) => {
    const { a, b } = fixture(); sweep(a, "low");
    if (kind === "missing") b.splice(30, 1);
    if (kind === "duplicate") b[30].t = b[29].t;
    if (kind === "stale") b.pop();
    expect(pairDivergence("EURUSD", "GBPUSD", "1m", a, b, end).status).toBe("Unconfirmed");
  });
  it("excludes unfinished and future candles", () => {
    const { a, b } = fixture(); sweep(a, "low");
    const original = pairDivergence("EURUSD", "GBPUSD", "1m", a, b, end);
    a.push({ ...a[61], t: end, l: 1 }); b.push({ ...b[61], t: end });
    expect(pairDivergence("EURUSD", "GBPUSD", "1m", a, b, end)).toEqual(original);
  });
  it("keeps divergence separate from existing trade decisions", () => {
    const positive = analyze("EURUSD", undefined, undefined, { symbol: "GBPUSD", tf: "5m" });
    const inverse = analyze("EURUSD", undefined, undefined, { symbol: "USDCHF", tf: "15m" });
    expect(positive.divergence?.peer).toBe("GBPUSD");
    expect(inverse.divergence?.peer).toBe("USDCHF");
    expect(positive.decision).toBe(inverse.decision);
    expect(positive.bull).toEqual(inverse.bull);
    expect(positive.bear).toEqual(inverse.bear);
  });
  it("never substitutes a demo peer for supplied primary candles", () => {
    const r = analyze("EURUSD", undefined, demoSeries("EURUSD"));
    expect(r.divergence?.status).toBe("Unconfirmed");
    expect(r.divergence?.comparison).toBeNull();
  });
  it("does not fabricate currency-pair divergence for Gold or NSE", () => {
    expect(analyze("XAUUSD").divergence).toBeNull();
    expect(analyze("RELIANCE").divergence).toBeNull();
  });
});