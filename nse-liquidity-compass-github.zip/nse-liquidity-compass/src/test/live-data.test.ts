import { describe, expect, it } from "vitest";
import { parseLiveCandles } from "@/lib/live-data";
import { analyze, demoSeries, TFS } from "@/lib/engine";

const bar = { datetime: "2026-11-06 13:13:00", open: "1.1", high: "1.2", low: "1.0", close: "1.15" };
describe("real candle safeguards", () => {
  it("excludes the unfinished minute and keeps missing volume unavailable", () => {
    const now = Date.parse("2026-11-06T13:14:20Z");
    const c = parseLiveCandles({ status: "ok", values: [{ ...bar, datetime: "2026-11-06 13:14:00" }, bar] }, now);
    expect(c).toHaveLength(1); expect(c[0].t).toBe(Date.parse("2026-11-06T13:13:00Z")); expect(c[0].v).toBe(0);
  });
  it("rejects duplicate timestamps", () => {
    expect(() => parseLiveCandles({ status: "ok", values: [bar, bar] }, Date.parse("2026-11-06T13:14:00Z"))).toThrow();
  });
  it("missing volume gives neither side any volume evidence", () => {
    const candles = demoSeries("EURUSD").map((c) => ({ ...c, v: 0 }));
    const r = analyze("EURUSD", undefined, candles, undefined, [], "TWELVE_DATA");
    expect([...r.bull.ev, ...r.bear.ev].filter((e) => e.cat === "volume")).toHaveLength(0);
    expect(r.profile).toBeNull(); expect(Number.isFinite(r.tfs["5m"].vwap)).toBe(false);
    expect(r.source).toBe("TWELVE_DATA"); expect(r.dataAsOf).toBe(candles[candles.length - 1].t + 60000);
    expect(r.divergence?.status).toBe("Unconfirmed");
    if (r.plan) expect(r.plan.confirmation).toContain("Volume confirmation unavailable from this feed — price-only research");
  });
  it("excludes partial higher timeframe candles from live analysis", () => {
    const candles = demoSeries("EURUSD").slice(0, -7);
    const r = analyze("EURUSD", undefined, candles, undefined, [], "TWELVE_DATA");
    for (const tf of TFS) {
      const minutes = { "1h": 60, "15m": 15, "5m": 5, "1m": 1 }[tf];
      const end = r.tfs[tf].candles.at(-1);
      expect((end?.t ?? Infinity) + minutes * 60000).toBeLessThanOrEqual(r.dataAsOf);
    }
  });
});