import { describe, expect, it } from "vitest";
import { orderBlockProtection, DEFAULT_SETTINGS, analyze, type Candle, type TFAnalysis } from "@/lib/engine";
import { DEFAULT_OB_PROTECTION } from "@/lib/order-block-protection";
const start = Date.parse("2026-11-02T03:45:00Z");
const bar = (i: number, o = 100, h = 101, l = 99, c = 100, v = 100): Candle => ({ t: start + i * 60000, o, h, l, c, v });
function frame(extra: Candle[] = []): TFAnalysis {
  const candles = Array.from({ length: 20 }, (_, i) => bar(i));
  candles[19] = bar(19, 100.5, 101, 99, 100);
  candles.push(bar(20, 100, 104.5, 100, 104, 200), ...extra);
  const a = analyze("RELIANCE", DEFAULT_SETTINGS).tfs["1m"];
  return { ...a, candles, swings: [], events: [{ t: start + 20 * 60000, tf: "1m", price: 102, kind: "BOS", dir: "bull", availableAt: start + 21 * 60000 }] };
}
const run = (extra: Candle[] = [], options = {}) => orderBlockProtection(frame(extra), start + (21 + extra.length) * 60000, options);
describe("uploaded order-block protection rules", () => {
  it("keeps package defaults explicit", () => {
    expect(DEFAULT_OB_PROTECTION).toEqual({ atrPeriod: 14, displacementAtrMin: 1.25, bodyRatioMin: 0.55, relativeVolumeMin: 1, searchBars: 12, zoneMode: "full", maxAgeBars: 80, fullMitigationFraction: 0.95 });
  });
  it("does not publish the breaking candle before its close", () => {
    expect(orderBlockProtection(frame(), start + 20 * 60000 + 59999).orderBlocks).toHaveLength(0);
    expect(run().orderBlocks[0].availableAt).toBe(start + 21 * 60000);
  });
  it("keeps qualifying fresh candidates active with prior-volume quality", () => {
    const b = run().protectedActiveOrderBlocks[0];
    expect(b.lifecycle).toBe("fresh"); expect(b.relativeVolume).toBe(2); expect(b.displacementAtr).toBeGreaterThan(1.25);
    expect(b.top).toBe(101); expect(b.bottom).toBe(99);
  });
  it("retains displacement failures for audit but excludes them from active", () => {
    const r = run([], { displacementAtrMin: 3 }); expect(r.orderBlocks[0].qualityPassed).toBe(false); expect(r.protectedActiveOrderBlocks).toHaveLength(0);
  });
  it("rejects weak breaking-candle body quality", () => {
    const a = frame(); a.candles[20].h = 120;
    expect(orderBlockProtection(a, start + 21 * 60000).orderBlocks[0].qualityPassed).toBe(false);
  });
  it("missing volume cannot pass the default volume gate", () => {
    const a = frame(); a.candles.forEach((c) => { c.v = 0; });
    const r = orderBlockProtection(a, start + 21 * 60000);
    expect(r.orderBlocks[0].relativeVolume).toBeNull(); expect(r.protectedActiveOrderBlocks).toHaveLength(0);
  });
  it("distinguishes exact boundary contact from penetration", () => {
    expect(run([bar(21, 102, 103, 101, 102)]).orderBlocks[0].lifecycle).toBe("touched");
    const b = run([bar(21, 102, 103, 100, 102)]).orderBlocks[0]; expect(b.lifecycle).toBe("partially_mitigated"); expect(b.mitigationFraction).toBe(0.5);
  });
  it("excludes a 95% consumed zone", () => {
    const r = run([bar(21, 102, 103, 99.09, 102)]); expect(r.orderBlocks[0].lifecycle).toBe("fully_mitigated"); expect(r.protectedActiveOrderBlocks).toHaveLength(0);
  });
  it("invalidates a bullish gap without zone overlap", () => {
    const r = run([bar(21, 98, 98.5, 97, 98)]); expect(r.orderBlocks[0].lifecycle).toBe("invalidated"); expect(r.orderBlocks[0].invalidatedAt).toBe(start + 22 * 60000); expect(r.protectedActiveOrderBlocks).toHaveLength(0);
  });
  it("tracks invalidation even after consumption", () => {
    expect(run([bar(21, 102, 103, 99, 102), bar(22, 98, 98.5, 97, 98)]).orderBlocks[0].lifecycle).toBe("invalidated");
  });
  it("expires only after the configured bar age", () => {
    expect(run([bar(21, 104, 105, 103, 104)], { maxAgeBars: 1 }).orderBlocks[0].lifecycle).toBe("fresh");
    const r = run([bar(21, 104, 105, 103, 104), bar(22, 104, 105, 103, 104)], { maxAgeBars: 1 }); expect(r.orderBlocks[0].lifecycle).toBe("expired"); expect(r.protectedActiveOrderBlocks).toHaveLength(0);
  });
  it("later candles do not change an earlier as-of lifecycle", () => {
    const a = frame([bar(21, 98, 98.5, 97, 98)]);
    expect(orderBlockProtection(a, start + 21 * 60000)).toEqual(run());
  });
  it("handles bearish gap-through invalidation symmetrically", () => {
    const a = frame([bar(21, 98, 98.5, 97, 98)]);
    a.candles = a.candles.map((c) => ({ ...c, o: 200 - c.o, h: 200 - c.l, l: 200 - c.h, c: 200 - c.c }));
    a.events = [{ ...a.events[0], dir: "bear", price: 98 }];
    const r = orderBlockProtection(a, start + 22 * 60000); expect(r.orderBlocks[0].direction).toBe("bear"); expect(r.orderBlocks[0].lifecycle).toBe("invalidated");
  });
  it("rejects duplicate, nonfinite and unordered candles", () => {
    const a = frame(); a.candles[1] = a.candles[0]; expect(() => orderBlockProtection(a, start + 21 * 60000)).toThrow("duplicate");
    const b = frame(); b.candles[0].v = Infinity; expect(() => orderBlockProtection(b, start + 21 * 60000)).toThrow("Invalid");
  });
  it("rejects invalid protection parameters", () => { expect(() => run([], { maxAgeBars: 0 })).toThrow("parameters"); expect(() => run([], { relativeVolumeMin: NaN })).toThrow("parameters"); });
});