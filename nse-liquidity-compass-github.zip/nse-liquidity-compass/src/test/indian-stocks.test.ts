import { describe, expect, it } from "vitest";
import { parseIndianStocks, searchIndianStocks, researchStockSymbol } from "@/lib/indian-stocks";
import { researchRequest, buildResearch } from "@/lib/predictions";
import { demoSeries } from "@/lib/engine";

const csv = `instrument_token,tradingsymbol,name,instrument_type,segment,exchange
1,ASIANPAINT,"ASIAN PAINTS, LIMITED",EQ,NSE,NSE
2,ASIANPAINT,ASIAN PAINTS,EQ,BSE,BSE
3,OTHER,OTHER INDUSTRIES,EQ,BSE,BSE
4,ASIANFUT,ASIAN FUTURE,FUT,NFO-FUT,NFO
5,INDEX,INDEX,EQ,INDICES,NSE`;
describe("Indian stock research selection", () => {
  it("searches NSE equities beyond the original ten stocks by company name", () => {
    const result = searchIndianStocks(parseIndianStocks(csv), "paints", "NSE");
    expect(result.map((s) => [s.symbol, s.token])).toEqual([["ASIANPAINT", 1]]);
    expect(result[0].name).toBe("ASIAN PAINTS, LIMITED");
  });
  it("selects the BSE token separately from the same NSE ticker", () => {
    const result = searchIndianStocks(parseIndianStocks(csv), "ASIANPAINT", "BSE");
    expect(result.map((s) => [researchStockSymbol(s), s.token])).toEqual([["BSE:ASIANPAINT", 2]]);
  });
  it("excludes futures and index instruments from stock search", () => {
    expect(parseIndianStocks(csv).map((s) => s.token)).toEqual([1, 2, 3]);
  });
  it("allows NSE and BSE research without the example-stock whitelist", () => {
    for (const symbol of ["ASIANPAINT", "BSE:ASIANPAINT"]) {
      expect(researchRequest.safeParse({ symbol, timeframe: "15m", horizon: 5, csv: "", timezone: "offset", filename: "test.csv" }).success).toBe(true);
    }
  });
  it("keeps BSE session identity in supplied-candle research", () => {
    const candles = demoSeries("RELIANCE"); // test-only candles, never used by the directory or live flow
    const text = ["timestamp,open,high,low,close,volume", ...candles.map((c) => `${new Date(c.t).toISOString()},${c.o},${c.h},${c.l},${c.c},${c.v}`)].join("\n");
    const result = buildResearch({ symbol: "BSE:ASIANPAINT", csv: text, filename: "test.csv", timezone: "offset", timeframe: "15m", horizon: 5 });
    expect(result.report.activeSessions).toEqual(["BSE"]);
    expect(result.report.symbol).toBe("BSE:ASIANPAINT");
    expect(result.report.source).toBe("SUPPLIED");
  });
});