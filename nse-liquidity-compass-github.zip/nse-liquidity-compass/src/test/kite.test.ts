import { describe, it, expect } from "vitest";
import { findInstrumentToken, kiteCandlesToCsv, istStamp } from "@/lib/kite";
describe("kite helpers", () => {
  it("finds NSE token", () => {
    const csv = "instrument_token,exchange_token,tradingsymbol,name,last_price,expiry,strike,tick_size,lot_size,instrument_type,segment,exchange\n738561,2885,RELIANCE,RELIANCE,0,,0,0.05,1,EQ,NSE,NSE";
    expect(findInstrumentToken(csv, "RELIANCE")).toBe(738561);
    expect(findInstrumentToken(csv, "TCS")).toBeNull();
  });
  it("drops the still-forming candle and normalises offset", () => {
    const now = Date.parse("2026-11-06T09:16:30+05:30");
    const out = kiteCandlesToCsv([["2026-11-06T09:15:00+0530", 1, 2, 0.5, 1.5, 10], ["2026-11-06T09:16:00+0530", 1, 2, 0.5, 1.5, 10]], now).split("\n");
    expect(out).toEqual(["timestamp,open,high,low,close,volume", "2026-11-06T09:15:00+05:30,1,2,0.5,1.5,10"]);
  });
  it("formats IST stamp", () => expect(istStamp(Date.parse("2026-11-06T03:45:00Z"))).toBe("2026-11-06 09:15:00"));
});

import { kiteChecksum, secondsUntilKiteExpiry } from "@/lib/kite";
describe("kite login", () => {
  it("checksum is sha256 of key+request_token+secret", async () => {
    expect(await kiteChecksum("a", "b", "c")).toBe("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
  });
  it("token expires at 06:00 IST", () => {
    expect(secondsUntilKiteExpiry(Date.parse("2026-11-07T00:00:00Z"))).toBe(30 * 60); // 05:30 IST
    expect(secondsUntilKiteExpiry(Date.parse("2026-11-07T04:00:00Z"))).toBe(20.5 * 3600); // 09:30 IST
  });
});

import { signKiteState, verifyKiteState, encryptKiteToken, decryptKiteToken } from "@/lib/kite";
describe("kite login state", () => {
  it("accepts a fresh signed state without any cookie", async () => {
    const s = await signKiteState("sec", 1_000_000_000_000);
    expect(await verifyKiteState("sec", s, 1_000_000_000_000 + 60_000)).toBe(true);
  });
  it("rejects a state older than 15 minutes", async () => {
    const s = await signKiteState("sec", 1_000_000_000_000);
    expect(await verifyKiteState("sec", s, 1_000_000_000_000 + 16 * 60_000)).toBe(false);
  });
  it("rejects a state signed with another secret", async () => {
    const s = await signKiteState("other", 1_000_000_000_000);
    expect(await verifyKiteState("sec", s, 1_000_000_000_000)).toBe(false);
  });
  it("round-trips the encrypted token", async () => {
    const c = await encryptKiteToken("sec", "abc123");
    expect(c).not.toContain("abc123");
    expect(await decryptKiteToken("sec", c)).toBe("abc123");
  });
});

describe("renamed NSE symbols", () => {
  it("finds Tata Motors under its new TMPV symbol", () => {
    const csv = "instrument_token,exchange_token,tradingsymbol,name,last_price,expiry,strike,tick_size,lot_size,instrument_type,segment,exchange\n111,1,TMPV,TATA MOTORS PV,0,,0,0.05,1,EQ,NSE,NSE";
    expect(findInstrumentToken(csv, "TATAMOTORS")).toBe(111);
  });
});
