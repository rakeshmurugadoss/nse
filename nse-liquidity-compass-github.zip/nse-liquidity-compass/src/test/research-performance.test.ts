import { expect, it } from "vitest";
import { researchPerformance } from "@/lib/research-performance";
import { netPnl } from "@/lib/paper";
it("does not claim accuracy or profit without evaluated directions", () => { const p = researchPerformance([]); expect(p.accuracy).toBeNull(); expect(p.brier).toBeNull(); expect(p.netExpectancy).toBeNull(); });
it("deducts explicitly supplied paper charges and slippage", () => { expect(netPnl({ id: "test", symbol: "TCS", dir: "BUY", qty: 10, entry: 100, sl: 99, target: 102, exit: 102, openedAt: 0, strategy: "", aiDecision: "", brokeragePerOrder: 10, slippagePerSide: 0.001, otherCharges: 5 })).toBeCloseTo(-7.02); });