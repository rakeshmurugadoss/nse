import { expect, it } from "vitest";
import { advancedStructures, type TFAnalysis } from "@/lib/engine";
it("inverse FVG becomes available only after the failure candle closes", () => {
  const a = { tf:"5m", events:[], swings:[], liquidity:[], zones:[{ kind:"Bull FVG", bottom:100, top:102, t:0, formedAt:0, availableAt:300000, status:"Invalidated" }], candles:[{t:0,o:101,h:103,l:100,c:102,v:1},{t:300000,o:102,h:103,l:98,c:99,v:1}] } as unknown as TFAnalysis;
  const result=advancedStructures(a,{...a,tf:"1h",zones:[],events:[]},[]).find((x)=>x.type==='Bear inverse FVG');
  expect(result?.availableAt).toBe(600000); expect(result?.bottom).toBe(100); expect(result?.top).toBe(102);
});