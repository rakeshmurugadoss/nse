import { describe, expect, it } from "vitest";
import { aggregate, analyze, demoSeries, fmtPrice, forexSessions, marketOf, volumeProfile } from "@/lib/engine";

describe("Forex and Gold analysis", () => {
  it("includes Forex and Gold without changing NSE classification", () => {
    expect(marketOf("EURUSD")).toBe("forex");
    expect(marketOf("XAUUSD")).toBe("forex");
    expect(marketOf("RELIANCE")).toBe("nse");
  });
  it("preserves currency-pair and Gold price precision", () => {
    expect(fmtPrice("EURUSD", 1.08543)).toBe("1.08543");
    expect(fmtPrice("USDJPY", 153.1234)).toBe("153.123");
    expect(fmtPrice("XAUUSD", 2700.123)).toBe("2700.12");
  });
  it("uses illustrative full weekday candles and UTC hourly alignment", () => {
    const c = demoSeries("EURUSD", 2);
    expect(c).toHaveLength(2880);
    expect(c.every((x) => ![0, 6].includes(new Date(x.t).getUTCDay()))).toBe(true);
    expect(aggregate(c, "1h", "forex")).toHaveLength(48);
    expect(aggregate(c, "1h", "forex").every((x) => x.t % 3600000 === 0)).toBe(true);
  });
  it("keeps Forex demo-labelled and disables unsupported share-style sizing", () => {
    for (const symbol of ["EURUSD", "GBPUSD", "USDJPY", "XAUUSD"]) {
      const r = analyze(symbol);
      expect(r.source).toBe("DEMO");
      expect(r.profile?.total).toBeGreaterThan(0);
      expect(Number.isFinite(r.price)).toBe(true);
      if (r.plan) {
        expect(r.plan.qty).toBe(0);
        expect(r.plan.confirmation.some((x) => x.includes("15:15"))).toBe(false);
      }
    }
  });
  it("conserves activity and expands a contiguous 70% value area from POC", () => {
    const p = volumeProfile([{ t: 0, o: 1, h: 5, l: 1, c: 3, v: 100 }, { t: 1, o: 2, h: 3, l: 2, c: 2.5, v: 100 }], 4);
    expect(p?.total).toBeCloseTo(200);
    expect(p?.poc).toBe(2.5);
    expect(p?.val).toBe(1);
    expect(p?.vah).toBe(3);
    expect(p?.valueAreaVolume).toBe(150);
  });
  it("does not fabricate a profile for missing volume", () => {
    expect(volumeProfile([{ t: 0, o: 1, h: 2, l: 1, c: 1, v: 0 }])).toBeNull();
  });
  it("adjusts London and New York hours for daylight saving", () => {
    expect(forexSessions(Date.UTC(2026, 6, 1, 7))).toContain("London");
    expect(forexSessions(Date.UTC(2026, 0, 1, 7))).not.toContain("London");
    expect(forexSessions(Date.UTC(2026, 6, 1, 12))).toContain("New York");
    expect(forexSessions(Date.UTC(2026, 0, 1, 12))).not.toContain("New York");
  });
  it("rejects incomplete candle sets", () => {
    expect(() => analyze("EURUSD", undefined, [])).toThrow("At least 30 candles");
  });
});
import { ictKillzones, analyze as analyzeIct } from "@/lib/engine";
describe("ICT tools", () => {
  it("marks London Silver Bullet active at 03:30 New York time", () => {
    const t = Date.UTC(2026, 0, 14, 8, 30); // 03:30 EST
    const k = ictKillzones(t).filter((x) => x.active).map((x) => x.name);
    expect(k).toEqual(["London Open", "London Silver Bullet"]);
  });
  it("OTE zone sits between 62% and 79% of the leg", () => {
    const o = analyzeIct("EURUSD").tfs["15m"].ote!;
    const r = o.legHigh - o.legLow;
    expect(o.top - o.bottom).toBeCloseTo(0.17 * r, 8);
    expect(o.sweet).toBeGreaterThan(o.bottom); expect(o.sweet).toBeLessThan(o.top);
  });
});
