import { describe, expect, it } from "vitest";
import { parseResearchCsv, buildResearch, evaluateOutcome } from "@/lib/predictions";
import { closedSessionBars, analyze, DEFAULT_SETTINGS, type Candle } from "@/lib/engine";
const header = "timestamp,open,high,low,close,volume\n";
const day = Date.parse("2026-11-02T09:15:00+05:30");
function series(days = 5): Candle[] {
  return Array.from({ length: days * 375 }, (_, i) => { const k = i % 375, d = Math.floor(i / 375), price = 100 + Math.sin(i / 12) * 2 + i / 1000; return { t: day + d * 86400000 + k * 60000, o: price, h: price + 0.4, l: price - 0.4, c: price + 0.1, v: 100 }; });
}
const csv = (c: Candle[]) => header + c.map((x) => `${new Date(x.t).toISOString()},${x.o},${x.h},${x.l},${x.c},${x.v}`).join("\n");
describe("advanced historical research", () => {
  it("rejects duplicate candles instead of creating prices", () => { const c = series(1).slice(0, 30); c[1] = c[0]; expect(() => parseResearchCsv(csv(c), "offset")).toThrow("Duplicate"); });
  it("rejects inconsistent OHLC", () => { const c = series(1).slice(0, 30); c[0].h = 1; expect(() => parseResearchCsv(csv(c), "offset")).toThrow("OHLCV"); });
  it("requires explicit timezone when no timezone is declared", () => { expect(() => parseResearchCsv(csv(series(1).slice(0, 30)).replaceAll("Z", ""), "offset")).toThrow("timezone"); });
  it("rejects impossible calendar dates", () => { expect(() => parseResearchCsv(csv(series(1).slice(0, 30)).replaceAll("2026-11-02", "2026-02-30"), "offset")).toThrow("calendar date"); });
  it("aggregates five minutes from NSE 09:15 and excludes incomplete buckets", () => { const c = series(1).slice(0, 6); const bars = closedSessionBars(c, "5m", "nse", day + 6 * 60000); expect(bars).toHaveLength(1); expect(bars[0].t).toBe(day); expect(bars[0].v).toBe(500); });
  it("does not bridge a missing minute", () => { const c = series(1).slice(0, 5).filter((_, i) => i !== 2); expect(closedSessionBars(c, "5m", "nse", day + 5 * 60000)).toHaveLength(0); });
  it("does not include future candles in research reports", () => { const c = series(); const asOf = c[c.length - 1].t; const r = analyze("RELIANCE", DEFAULT_SETTINGS, c, undefined, undefined, "SUPPLIED", { asOf, completeOnly: true }); expect(r.generatedAt).toBe(asOf); expect(r.tfs["1m"].candles.every((x) => x.t + 60000 <= asOf)).toBe(true); expect(r.tfs["1m"].swings.every((s) => (s.availableAt ?? Infinity) <= asOf)).toBe(true); });
  it("never gives an invalid WAIT setup risk levels or an ML probability", () => { const output = buildResearch({ symbol: "RELIANCE", timeframe: "15m", horizon: 5, timezone: "offset", csv: csv(series()), filename: "research.csv" }, Date.parse("2026-11-07T00:00:00Z")); expect(output.report.decision).toBe("WAIT"); expect(output.report.plan).toBeNull(); expect(output.model.score).toBeNull(); expect(output.model.validated).toBe(false); });
  it("leaves outcomes pending without complete future minutes", () => { const output = buildResearch({ symbol: "RELIANCE", timeframe: "15m", horizon: 5, timezone: "offset", csv: csv(series()), filename: "research.csv" }, Date.parse("2026-11-07T00:00:00Z")); expect(() => evaluateOutcome(output, output.candles)).toThrow("pending"); });
  it("marks unknown same-bar barrier order ambiguous", () => { const output = buildResearch({ symbol: "RELIANCE", timeframe: "15m", horizon: 5, timezone: "offset", csv: csv(series()), filename: "research.csv" }, Date.parse("2026-11-07T00:00:00Z")); output.report.plan = { dir: "BUY", entryLow: 99, entryHigh: 100, sl: 98, targets: [{ price: 102, why: "test" }], rr: 2, qty: 1, risk: 1, invalidation: "", confirmation: [] }; const future = Array.from({ length: 5 }, (_, i) => ({ t: output.asOf + i * 60000, o: 100, h: 103, l: 97, c: 101, v: 100 })); expect(evaluateOutcome(output, future).barrier).toBe("ambiguous"); });
});