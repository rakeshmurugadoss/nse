import { describe, expect, it } from "vitest";
import { analyze, judge, DEFAULT_SETTINGS } from "@/lib/engine";
import { netPnl } from "@/lib/paper";

describe("AI judge", () => {
  it("defaults to WAIT when evidence is weak", () => {
    expect(judge(40, 30, 0, "bull", "bull", null, DEFAULT_SETTINGS).decision).toBe("WAIT");
  });
  it("does not BUY against a bearish 1H bias", () => {
    const plan = { dir: "BUY" as const, entryLow: 99, entryHigh: 100, sl: 98, targets: [{ price: 110, why: "" }], rr: 5, qty: 1, risk: 1, invalidation: "", confirmation: [] };
    expect(judge(80, 10, 5, "bear", "bull", plan, DEFAULT_SETTINGS).decision).toBe("WAIT");
    expect(judge(80, 10, 5, "bull", "bull", plan, DEFAULT_SETTINGS).decision).toBe("BUY");
  });
  it("default weights total 100", () => {
    expect(Object.values(DEFAULT_SETTINGS.weights).reduce((a, b) => a + b, 0)).toBe(100);
  });
  it("labels reports as DEMO data", () => {
    expect(analyze("TCS").source).toBe("DEMO");
  });
  it("paper P&L deducts ₹20 per order and slippage", () => {
    expect(netPnl({ id: "1", symbol: "X", dir: "BUY", qty: 10, entry: 100, sl: 99, target: 102, exit: 102, openedAt: 0, strategy: "", aiDecision: "" })).toBeCloseTo(20 - 40 - 0.0005 * 202 * 10);
  });
});
