import { createFileRoute } from "@tanstack/react-router";
import { signKiteState } from "@/lib/kite";

/** Starts Zerodha's official login. A signed, short-lived state protects the callback (no cookie needed). */
export const Route = createFileRoute("/api/public/kite/login")({
  server: {
    handlers: {
      GET: async () => {
        const key = process.env["KITE_API_KEY"], secret = process.env["KITE_API_SECRET"];
        if (!key || !secret) return new Response(null, { status: 302, headers: { Location: "/predictions?kite=missing" } });
        const state = await signKiteState(secret);
        const login = `https://kite.zerodha.com/connect/login?v=3&api_key=${encodeURIComponent(key)}&redirect_params=${encodeURIComponent(`state=${state}`)}`;
        return new Response(null, { status: 302, headers: { Location: login, "Cache-Control": "no-store" } });
      },
    },
  },
});
