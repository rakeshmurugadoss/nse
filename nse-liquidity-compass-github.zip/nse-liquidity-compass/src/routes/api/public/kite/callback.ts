import { createFileRoute } from "@tanstack/react-router";
import { KITE_BASE, kiteChecksum, verifyKiteState } from "@/lib/kite";

const back = (q: string) =>
  new Response(null, {
    status: 302,
    headers: {
      Location: `/predictions?kite=${q}`,
      "Cache-Control": "no-store",
      // clear old cookie-based state from the previous version
      "Set-Cookie": "kite_state=; Path=/api/public/kite; HttpOnly; Secure; SameSite=Lax; Max-Age=0",
    },
  });

/** Zerodha redirects here after login; exchanges the one-time request token for today's access token. */
export const Route = createFileRoute("/api/public/kite/callback")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const requestToken = url.searchParams.get("request_token") ?? "";
        const state = url.searchParams.get("state") ?? "";
        if (url.searchParams.get("status") !== "success" || !/^[A-Za-z0-9]{8,64}$/.test(requestToken)) return back("failed");
        const key = process.env["KITE_API_KEY"], secret = process.env["KITE_API_SECRET"];
        if (!key || !secret) return back("missing");
        if (!(await verifyKiteState(secret, state))) {
          const ts = Number(state.split(".")[0]);
          console.warn("kite state rejected", { parts: state.split(".").length, length: state.length, ageMs: Number.isFinite(ts) ? Date.now() - ts : null });
          return back("expired");
        }
        try {
          const res = await fetch(`${KITE_BASE}/session/token`, {
            method: "POST",
            headers: { "X-Kite-Version": "3", "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({ api_key: key, request_token: requestToken, checksum: await kiteChecksum(key, requestToken, secret) }),
          });
          const body = (await res.json()) as { status?: string; message?: string; error_type?: string; data?: { access_token?: string } };
          const token = body.data?.access_token;
          if (!res.ok || body.status !== "success" || !token || !/^[A-Za-z0-9]+$/.test(token)) {
            console.error("kite session rejected", res.status, body.error_type, body.message);
            return back(body.error_type === "TokenException" ? "token" : "failed");
          }
          const { saveKiteToken } = await import("@/lib/kite-session.server");
          await saveKiteToken(token);
          return back("connected");
        } catch (e) {
          console.error("kite session failed", e instanceof Error ? e.message : e);
          return back("failed");
        }
      },
    },
  },
});
