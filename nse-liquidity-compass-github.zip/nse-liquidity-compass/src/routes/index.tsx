import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Shell, Decision } from "@/components/Shell";
import { Chart } from "@/components/Chart";
import { analyze, symbolLabel, fmtTime } from "@/lib/engine";

import { MarketPicker } from "@/components/MarketPicker";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Liquidity AI — Intraday Liquidity & SMC Analysis for NSE, Forex & Gold" },
      { name: "description", content: "Liquidity-based price action and Smart Money Concepts analysis for NSE, Forex and Gold traders, with beginner and pro modes and paper trading." },
      { property: "og:title", content: "Liquidity AI — Intraday Intelligence for NSE, Forex & Gold" },
      { property: "og:description", content: "Liquidity, order blocks, FVGs, multi-timeframe structure and an AI judge. Paper trading only." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <Shell>
      <section className="py-10 text-center">
        <p className="label">NSE · Forex & Gold · liquidity · volume profile</p>
        <h1 className="mx-auto mt-3 max-w-3xl text-5xl md:text-7xl">Read where the <em>stops</em> are. Then decide.</h1>
        <p className="mx-auto mt-4 max-w-xl text-muted-foreground">One rule-based engine scans 1H, 15M, 5M and 1M for liquidity, structure, order blocks and fair value gaps. A bullish analyst, a bearish analyst and a judge argue it out. Default answer: WAIT.</p>
      </section>
      <LivePreview />
      <div className="grid gap-4 md:grid-cols-2">
        <Link to="/beginner" className="panel group transition-colors hover:border-primary">
          <div className="label">Mode A</div>
          <h2 className="mt-1 text-3xl">Choose Market or Screenshot</h2>
          <p className="mt-2 text-sm text-muted-foreground">Demo stock, Forex and Gold analysis or an AI reading of your chart picture, in English or Tamil.</p>
          <span className="mt-4 inline-block text-sm text-primary">Start →</span>
        </Link>
        <Link to="/pro" className="panel group transition-colors hover:border-primary">
          <div className="label">Mode B</div>
          <h2 className="mt-1 text-3xl">Professional Terminal</h2>
          <p className="mt-2 text-sm text-muted-foreground">Multi-timeframe liquidity map, OB/FVG scanners, BOS/CHoCH, Volume Profile, premium/discount, custom weights and the full judge report.</p>
          <span className="mt-4 inline-block text-sm text-primary">Open terminal →</span>
        </Link>
      </div>
      <p className="mt-8 text-center text-xs text-muted-foreground">Scores are evidence weights, not win probabilities. Educational and research use only. Not investment advice.</p>
    </Shell>
  );
}

function LivePreview() {
  const [sym, setSym] = useState("RELIANCE");
  const r = useMemo(() => analyze(sym), [sym]);
  return (
    <section className="panel mb-6">
      <div className="mb-3 flex flex-wrap items-center gap-3">
        <h2 className="text-2xl">Demo read · <em>{symbolLabel(sym)}</em></h2>
        <MarketPicker symbol={sym} onChange={setSym} />
      </div>
      <div className="grid gap-4 md:grid-cols-[1fr_260px]">
        <Chart a={r.tfs["15m"]} plan={r.plan} compact bars={70} />
        <div className="space-y-3">
          <div className="label">AI verdict</div>
          <Decision d={r.decision} />
          <div className="grid grid-cols-2 gap-2 font-mono text-sm">
            <div className="rounded-lg border p-2 text-bull">Bull {r.bull.score}</div>
            <div className="rounded-lg border p-2 text-bear">Bear {r.bear.score}</div>
          </div>
          <p className="text-sm text-muted-foreground">{r.reasons[0]}</p>
          <p className="font-mono text-[11px] text-muted-foreground">Demo data · {fmtTime(r.dataAsOf)} IST</p>
          <Link to="/pro" className="btn-primary w-full">Open full analysis</Link>
        </div>
      </div>
    </section>
  );
}
