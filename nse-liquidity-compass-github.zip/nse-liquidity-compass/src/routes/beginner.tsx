import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Shell, Decision } from "@/components/Shell";
import { Chart } from "@/components/Chart";
import { PlanCard } from "@/components/PlanCard";
import { PAIR_COMPARISONS, type PairOptions } from "@/lib/engine";
import { PairAnalysis } from "@/components/PairAnalysis";
import { Button } from "@/components/ui/button";
import { ScreenshotAnalysis } from "@/components/ScreenshotAnalysis";
import { MarketPicker } from "@/components/MarketPicker";
import { IctPanel } from "@/components/IctPanel";
import { LiveChartSwitch } from "@/components/LiveChartSwitch";
import { VolumeAnalysis } from "@/components/VolumeAnalysis";
import { marketOf } from "@/lib/engine";
import { CandlestickChart, ImagePlus } from "lucide-react";
import { useAnalysisData } from "@/hooks/use-analysis-data";
import { AnalysisSource } from "@/components/AnalysisSource";

export const Route = createFileRoute("/beginner")({
  head: () => ({
    meta: [
      { title: "Beginner Mode — Upload & Analyze | Liquidity AI" },
      { name: "description", content: "Simple NSE demo analysis and Twelve Data Forex and Gold candle analysis with liquidity, SMC and clear data-source labels." },
      { property: "og:title", content: "Beginner Mode — Liquidity AI" },
      { property: "og:description", content: "Simple chart analysis in English or Tamil." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Beginner,
});

const T = {
  en: { buy: "Buyers look stronger and a safe entry area exists.", sell: "Sellers look stronger and a safe entry area exists.", wait: "The picture is not clear enough. Do not trade now — wait.", why: "Why?", bigTrend: "Big picture (1 hour)", up: "going up", down: "going down", flat: "sideways" },
  ta: { buy: "வாங்குபவர்கள் வலுவாக உள்ளனர், பாதுகாப்பான நுழைவு பகுதி உள்ளது.", sell: "விற்பவர்கள் வலுவாக உள்ளனர், பாதுகாப்பான நுழைவு பகுதி உள்ளது.", wait: "நிலைமை தெளிவாக இல்லை. இப்போது வர்த்தகம் செய்ய வேண்டாம் — காத்திருங்கள்.", why: "ஏன்?", bigTrend: "பெரிய போக்கு (1 மணி)", up: "மேலே செல்கிறது", down: "கீழே செல்கிறது", flat: "பக்கவாட்டில்" },
};

function Beginner() {
  const [symbol, setSymbol] = useState("RELIANCE");
  const [mode, setMode] = useState<"stock" | "screenshot">("stock");
  const [run, setRun] = useState(false);
  const [lang, setLang] = useState<"en" | "ta">("en");
  const [pair, setPair] = useState<PairOptions | undefined>();
  const data = useAnalysisData(symbol, undefined, pair);
  const r = data.source === "live" ? data.report : run ? data.report : null;

  const t = T[lang];

  return (
    <Shell>
      <div className="mx-auto max-w-3xl space-y-4">
        <p className="label">Liquidity AI · Beginner</p>
        <h1 className="text-4xl md:text-5xl">A clearer <em>perspective.</em></h1>
        <div className="grid grid-cols-2 gap-3 border-b pb-5" role="tablist" aria-label="Analysis source">
          <Button role="tab" aria-selected={mode === "stock"} variant={mode === "stock" ? "default" : "outline"} className="h-24 flex-col gap-2" onClick={() => setMode("stock")}><CandlestickChart /><span className="font-display text-2xl">{marketOf(symbol) === "forex" ? "Choose Pair" : "Choose Stock"}</span></Button>
          <Button role="tab" aria-selected={mode === "screenshot"} variant={mode === "screenshot" ? "default" : "outline"} className="h-24 flex-col gap-2" onClick={() => setMode("screenshot")}><ImagePlus /><span className="font-display text-2xl">Screenshot</span></Button>
        </div>
        <div hidden={mode !== "screenshot"}><ScreenshotAnalysis liveBusy={data.busy} onAnalyzeLive={(next) => {
          const peer = PAIR_COMPARISONS[next]?.[0]?.symbol;
          const nextPair: PairOptions | undefined = peer ? { symbol: peer, tf: "5m" } : undefined;
          setSymbol(next); setPair(nextPair); setRun(false); data.setSource("live"); setMode("stock");
          void data.refresh({ symbol: next, pair: nextPair });
        }} /></div>
        {mode === "stock" && <>
        <div className="space-y-4 py-3">
          <MarketPicker symbol={symbol} onChange={(next) => { setSymbol(next); setRun(false); data.setSource("demo"); const peer = PAIR_COMPARISONS[next]?.[0]?.symbol; setPair(peer ? { symbol: peer, tf: "5m" } : undefined); }} />
          <AnalysisSource symbol={symbol} {...data} onSource={data.setSource} onRefresh={() => { void data.refresh(); }} />
          {data.source === "demo" && <Button className="h-12 w-full" onClick={() => setRun(true)}>Analyze {symbol}</Button>}
        </div>

        {r && (
          <>
            <div className="panel space-y-3">
              <div className="flex items-center justify-between"><Decision d={r.decision} />
                <div className="flex rounded-md border">{(["en", "ta"] as const).map((l) => <Button key={l} size="sm" variant={lang === l ? "default" : "ghost"} onClick={() => setLang(l)}>{l === "en" ? "English" : "தமிழ்"}</Button>)}</div>
              </div>
              <p className="text-lg">{r.decision === "BUY" ? t.buy : r.decision === "SELL" ? t.sell : t.wait}</p>
              <p className="text-sm text-muted-foreground">{t.bigTrend}: <b className="text-foreground">{r.tfs["1h"].trend === "bull" ? t.up : r.tfs["1h"].trend === "bear" ? t.down : t.flat}</b></p>
              <div className="label">{t.why}</div>
              <ul className="space-y-1 text-sm text-muted-foreground">{r.reasons.map((x) => <li key={x}>• {x}</li>)}</ul>
              <div className="grid grid-cols-2 gap-2 font-mono text-sm">
                <div className="rounded border p-2 text-bull">Buyers {r.bull.score}/100</div>
                <div className="rounded border p-2 text-bear">Sellers {r.bear.score}/100</div>
              </div>
              <p className="text-xs text-muted-foreground">These are evidence scores, not chances of winning.</p>
            </div>
            <div className="panel"><LiveChartSwitch symbol={r.symbol} interval="15m" source={r.source} busy={data.busy} onAnalyzeLive={() => { data.setSource("live"); void data.refresh(); }} label={`Marked chart · 15 min · ${r.source}`}><Chart a={r.tfs["15m"]} plan={r.plan} source={r.source} compact bars={80} /></LiveChartSwitch></div>
            <IctPanel r={r} a={r.tfs["15m"]} simple />
            <VolumeAnalysis r={r} simple />
            <PairAnalysis r={r} onChange={setPair} simple />
            <PlanCard r={r} />
            <details className="panel text-sm"><summary className="cursor-pointer">See all buyer & seller reasons</summary>
              <div className="mt-3 grid gap-3 md:grid-cols-2">
                <ul className="space-y-1 text-bull">{r.bull.ev.map((e, i) => <li key={i}>+ {e.text}</li>)}</ul>
                <ul className="space-y-1 text-bear">{r.bear.ev.map((e, i) => <li key={i}>− {e.text}</li>)}</ul>
              </div>
            </details>
          </>
        )}
        </>}
      </div>
    </Shell>
  );
}
