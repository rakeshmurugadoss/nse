import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Shell, Decision } from "@/components/Shell";
import { Chart } from "@/components/Chart";
import { PlanCard } from "@/components/PlanCard";
import { DEFAULT_SETTINGS, fmtPrice, TFS, fmtTime, type Settings, type TF, type Category } from "@/lib/engine";

import { MarketPicker } from "@/components/MarketPicker";
import { IctPanel } from "@/components/IctPanel";
import { LiveChartSwitch } from "@/components/LiveChartSwitch";
import { VolumeAnalysis } from "@/components/VolumeAnalysis";
import { PairAnalysis } from "@/components/PairAnalysis";
import { PAIR_COMPARISONS, type PairOptions } from "@/lib/engine";
import { Button } from "@/components/ui/button";
import { CandlestickChart, ImagePlus, Settings2 } from "lucide-react";
import { useAnalysisData } from "@/hooks/use-analysis-data";
import { AnalysisSource } from "@/components/AnalysisSource";
import { ScreenshotAnalysis } from "@/components/ScreenshotAnalysis";

export const Route = createFileRoute("/pro")({
  head: () => ({
    meta: [
      { title: "Pro Terminal — Liquidity AI" },
      { name: "description", content: "Multi-timeframe NSE, Forex and Gold liquidity, SMC and estimated Volume Profile analysis." },
      { property: "og:title", content: "Pro Terminal — Liquidity AI" },
      { property: "og:description", content: "Institutional-style liquidity and SMC analysis terminal." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Pro,
});

function Pro() {
  const [mode, setMode] = useState<"candles" | "screenshot">("candles");
  const [symbol, setSymbol] = useState("RELIANCE");
  const [tf, setTf] = useState<TF>("15m");
  const [s, setS] = useState<Settings>(DEFAULT_SETTINGS);
  const [showSet, setShowSet] = useState(false);
  const [pair, setPair] = useState<PairOptions | undefined>();
  const data = useAnalysisData(symbol, s, pair);
  const r = data.report;
  const a = r?.tfs[tf];
  const sum = Object.values(s.weights).reduce((x, y) => x + y, 0);

  return (
    <Shell>
      <div className="mb-5 flex flex-wrap gap-2 border-b pb-4" role="tablist" aria-label="Pro analysis source">
        <Button role="tab" aria-selected={mode === "candles"} aria-controls="pro-candle-analysis" id="pro-candle-tab" variant={mode === "candles" ? "default" : "outline"} onClick={() => setMode("candles")}><CandlestickChart />Market analysis</Button>
        <Button role="tab" aria-selected={mode === "screenshot"} aria-controls="pro-screenshot-analysis" id="pro-screenshot-tab" variant={mode === "screenshot" ? "default" : "outline"} onClick={() => setMode("screenshot")}><ImagePlus />Screenshot</Button>
      </div>
      <div id="pro-screenshot-analysis" role="tabpanel" aria-labelledby="pro-screenshot-tab" hidden={mode !== "screenshot"} className="mx-auto max-w-3xl"><ScreenshotAnalysis liveBusy={data.busy} onAnalyzeLive={(next) => {
        const peer = PAIR_COMPARISONS[next]?.[0]?.symbol;
        const nextPair: PairOptions | undefined = peer ? { symbol: peer, tf: "5m" } : undefined;
        setSymbol(next); setPair(nextPair); data.setSource("live"); setMode("candles");
        void data.refresh({ symbol: next, pair: nextPair });
      }} /></div>
      <div id="pro-candle-analysis" role="tabpanel" aria-labelledby="pro-candle-tab" hidden={mode !== "candles"}>
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <MarketPicker symbol={symbol} onChange={(next) => { setSymbol(next); data.setSource("demo"); const peer = PAIR_COMPARISONS[next]?.[0]?.symbol; setPair(peer ? { symbol: peer, tf: "5m" } : undefined); }} />
        <div className="flex rounded-md border">{TFS.map((t) => <Button size="sm" variant={t === tf ? "default" : "ghost"} key={t} onClick={() => setTf(t)} className={`px-3 py-1.5 font-mono text-sm ${t === tf ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>{t}</Button>)}</div>
        <Button variant="outline" size="icon" aria-label="Analysis settings" title="Analysis settings" onClick={() => setShowSet(!showSet)}><Settings2 /></Button>
        {r && <span className="ml-auto font-mono text-xs text-muted-foreground">Last candle {fmtPrice(symbol, r.price)} · data as of {fmtTime(r.dataAsOf)} IST · {r.source}</span>}
      </div>
      <AnalysisSource symbol={symbol} {...data} onSource={data.setSource} onRefresh={() => { void data.refresh(); }} />

      {showSet && (
        <div className="panel mb-4 grid gap-3 md:grid-cols-4">
          {([["fractal", "Fractal bars", 1], ["eqTolAtr", "EQ tolerance (ATR)", 0.05], ["dispAtr", "Displacement (ATR)", 0.1], ["minRR", "Min R:R", 0.5], ["capital", "Capital ₹", 1000], ["riskPct", "Risk % / trade", 0.25]] as const).map(([k, l, st]) => (
            <label key={k} className="text-xs text-muted-foreground">{l}<input type="number" step={st} className="field mt-1 w-full font-mono" value={s[k]} onChange={(e) => setS({ ...s, [k]: Number(e.target.value) || s[k] })} /></label>
          ))}
          {(Object.keys(s.weights) as Category[]).map((k) => (
            <label key={k} className="text-xs text-muted-foreground">Weight · {k}<input type="number" className="field mt-1 w-full font-mono" value={s.weights[k]} onChange={(e) => setS({ ...s, weights: { ...s.weights, [k]: Number(e.target.value) } })} /></label>
          ))}
          <p className={`text-xs md:col-span-4 ${sum === 100 ? "text-muted-foreground" : "text-warn"}`}>Weights total {sum}% {sum !== 100 && "— should total 100"}</p>
        </div>
      )}

      {r && a ? <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
        <div className="min-w-0 space-y-4">
          <div className="panel"><LiveChartSwitch symbol={symbol} interval={tf} source={r.source} onAnalyzeLive={() => { data.setSource("live"); void data.refresh(); }} busy={data.busy} label={`AI annotated chart · ${tf} · ${r.source}`}><Chart a={a} plan={r.plan} source={r.source} /></LiveChartSwitch></div>
          <div className="panel overflow-x-auto">
            <div className="label mb-2">Multi-timeframe matrix</div>
            <table className="w-full font-mono text-xs">
              <thead className="text-muted-foreground"><tr>{["TF", "Role", "Trend", "Last event", "Zone", "RSI", "vs VWAP", "RelVol", "Disp."].map((h) => <th key={h} className="p-1 text-left font-normal">{h}</th>)}</tr></thead>
              <tbody>{TFS.map((t) => { const x = r.tfs[t]; const e = x.events.at(-1); return (
                <tr key={t} className="border-t">
                  <td className="p-1">{t}</td><td className="p-1 text-muted-foreground">{{ "1h": "Bias", "15m": "Structure", "5m": "Setup", "1m": "Trigger" }[t]}</td>
                  <td className={`p-1 ${x.trend === "bull" ? "text-bull" : x.trend === "bear" ? "text-bear" : ""}`}>{x.trend}</td>
                  <td className="p-1">{e ? `${e.kind} ${e.dir}` : "—"}</td><td className="p-1">{x.zone}</td><td className="p-1">{x.rsi.toFixed(0)}</td>
                  <td className="p-1">{Number.isFinite(x.vwap) ? r.price > x.vwap ? "above" : "below" : "N/A"}</td><td className="p-1">{Number.isFinite(x.relVol) ? `${x.relVol.toFixed(1)}x` : "N/A"}</td><td className="p-1">{x.displacement ?? "—"}</td>
                </tr>); })}</tbody>
            </table>
          </div>
          <IctPanel r={r} a={a} />
          <VolumeAnalysis r={r} />
          <PairAnalysis r={r} onChange={setPair} />
          <div className="grid gap-4 md:grid-cols-2">
            <ZoneTable title={`Liquidity · ${tf}`} rows={a.liquidity.map((l) => [l.kind, fmtPrice(symbol, l.price), `${l.distPct.toFixed(2)}%`, l.status, fmtTime(l.t)])} />
            <ZoneTable title={`Order Blocks, Breakers & FVG · ${tf}`} rows={a.zones.slice(-14).map((z) => [z.kind, `${fmtPrice(symbol, z.bottom)}–${fmtPrice(symbol, z.top)}`, z.kind.includes("FVG") ? `${(z.fill * 100).toFixed(0)}%` : "—", z.status, fmtTime(z.t)])} />
          </div>
        </div>
        <aside className="space-y-4">
          <div className="panel space-y-3">
            <div className="label">AI Judge</div>
            <Decision d={r.decision} />
            <ul className="space-y-1 text-sm">{r.reasons.map((x) => <li key={x} className="text-muted-foreground">• {x}</li>)}</ul>
            <div className="grid grid-cols-4 gap-2 text-center font-mono text-xs">
              <Score l="Bull" v={r.bull.score} c="text-bull" /><Score l="Bear" v={r.bear.score} c="text-bear" /><Score l="Neutral" v={r.neutral} c="" /><Score l="Conflict" v={-r.conflictPenalty} c="text-warn" />
            </div>
          </div>
          <PlanCard r={r} />
          <Analyst title="Bullish analyst" ev={r.bull.ev} cls="text-bull" />
          <Analyst title="Bearish analyst" ev={r.bear.ev} cls="text-bear" />
          <div className="panel text-xs text-muted-foreground">
            <div className="label mb-1">{r.market === "forex" ? `${r.source} sessions · UTC day` : "Session (IST)"}</div>
            {r.market === "forex" && <p className="mb-2">At candle time: {r.activeSessions.join(" + ") || "Outside main sessions"} · broker rollover and Gold breaks vary</p>}
            {r.market === "forex" ? "UTC day first 15 min" : "Opening range"} {fmtPrice(symbol, r.session.orl)}–{fmtPrice(symbol, r.session.orh)} · Gap {r.session.gapPct.toFixed(2)}% · PDH {fmtPrice(symbol, r.session.pdh)} · PDL {fmtPrice(symbol, r.session.pdl)} · PDC {fmtPrice(symbol, r.session.pdc)} · Day {fmtPrice(symbol, r.session.dayLow)}–{fmtPrice(symbol, r.session.dayHigh)}
          </div>
        </aside>
      </div> : <p className="py-10 text-muted-foreground">{data.busy ? "Fetching market candles…" : "Live analysis awaits a fresh candle request. No demo verdict is shown in this mode."}</p>}
      </div>
    </Shell>
  );
}
const Score = ({ l, v, c }: { l: string; v: number; c: string }) => <div className="rounded border p-2"><div className={`text-lg font-bold ${c}`}>{v}</div><div className="text-muted-foreground">{l}</div></div>;
export const Analyst = ({ title, ev, cls }: { title: string; ev: { cat: string; text: string }[]; cls: string }) => (
  <div className="panel"><div className={`label mb-2 ${cls}`}>{title} · {ev.length} points</div>
    {ev.length ? <ul className="space-y-1 text-sm">{ev.map((e, i) => <li key={i}><span className="chip mr-1">{e.cat}</span>{e.text}</li>)}</ul> : <p className="text-sm text-muted-foreground">No supporting evidence.</p>}
  </div>
);
const ZoneTable = ({ title, rows }: { title: string; rows: string[][] }) => (
  <div className="panel overflow-x-auto"><div className="label mb-2">{title}</div>
    <table className="w-full font-mono text-xs"><tbody>{rows.map((r, i) => <tr key={i} className="border-t">{r.map((c, j) => <td key={j} className={`p-1 ${c === "Untouched" ? "text-liq" : c === "Invalidated" ? "text-muted-foreground" : ""}`}>{c}</td>)}</tr>)}</tbody></table>
  </div>
);
