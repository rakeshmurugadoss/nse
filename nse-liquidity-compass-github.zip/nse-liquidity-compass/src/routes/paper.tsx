import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Shell } from "@/components/Shell";
import { fmtTime } from "@/lib/engine";
import { loadTrades, saveTrades, stats, netPnl, BROKERAGE, SLIPPAGE, type PaperTrade } from "@/lib/paper";
import { Button } from "@/components/ui/button";
import { useResearchSession } from "@/components/ResearchSession";
import { useServerFn } from "@tanstack/react-start";
import { transferPaperTrades } from "@/lib/paper.functions";

export const Route = createFileRoute("/paper")({
  head: () => ({
    meta: [
      { title: "Paper Trading & Journal — Liquidity AI" },
      { name: "description", content: "Simulated trades, P&L, win rate, profit factor and drawdown. No real orders." },
      { property: "og:title", content: "Paper Trading — Liquidity AI" },
      { property: "og:description", content: "Track simulated trades and performance." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Paper,
});

function Paper() {
  const user = useResearchSession(), transfer = useServerFn(transferPaperTrades);
  const [message, setMessage] = useState("");
  const [trades, setTrades] = useState<PaperTrade[]>([]);
  const [exits, setExits] = useState<Record<string, string>>({});
  useEffect(() => setTrades(loadTrades()), []);
  const update = (t: PaperTrade[]) => { setTrades(t); saveTrades(t); };
  const close = (tr: PaperTrade, price: number, reason: string) => update(trades.map((t) => (t.id === tr.id ? { ...t, exit: price, closedAt: Date.now(), reason } : t)));
  const st = stats(trades);
  const open = trades.filter((t) => t.exit == null), closed = trades.filter((t) => t.exit != null);

  return (
    <Shell>
      <h1 className="mb-4 text-4xl md:text-5xl">Paper <em>Trading</em></h1>
      <div className="mb-4 grid grid-cols-2 gap-2 md:grid-cols-6">
        {[["Net P&L", `₹${st.net.toFixed(0)}`], ["Trades", st.count], ["Win rate", `${st.winRate.toFixed(0)}%`], ["Profit factor", Number.isFinite(st.profitFactor) ? st.profitFactor.toFixed(2) : "∞"], ["Max drawdown", `₹${st.maxDD.toFixed(0)}`], ["Avg R:R", st.avgRR.toFixed(2)]].map(([k, v]) => (
          <div key={k} className="panel"><div className="label">{k}</div><div className="mt-1 font-mono text-xl">{v}</div></div>
        ))}
      </div>
      <p className="mb-4 text-xs text-muted-foreground">Costs estimated at ₹{BROKERAGE}/order + {SLIPPAGE * 100}% slippage per side. Trades are saved on this device only.</p>
      {user && trades.length > 0 && <Button variant="outline" className="mb-4" onClick={async () => { if (!confirm("Copy your device paper journal to your private account? Local trades will be kept.")) return; try { const n = await transfer({ data: trades }); setMessage(`${n} journal records copied; device records kept.`); } catch { setMessage("Journal could not be copied."); } }}>Copy journal to my account</Button>}
      {message && <p role="status" className="mb-3 text-sm text-muted-foreground">{message}</p>}

      <div className="panel mb-4 overflow-x-auto">
        <div className="label mb-2">Open positions</div>
        {!open.length && <p className="text-sm text-muted-foreground">No open trades. Create one from a trade plan.</p>}
        {open.map((t) => (
          <div key={t.id} className="flex flex-wrap items-center gap-2 border-t py-2 font-mono text-xs">
            <span className={t.dir === "BUY" ? "text-bull" : "text-bear"}>{t.dir}</span><span>{t.symbol} × {t.qty}</span>
            <span>@ {t.entry.toFixed(2)}</span><span className="text-bear">SL {t.sl.toFixed(2)}</span><span className="text-bull">T {t.target.toFixed(2)}</span>
            <Button variant="outline" size="sm" onClick={() => close(t, t.target, "Target hit")}>Target hit</Button>
            <Button variant="outline" size="sm" onClick={() => close(t, t.sl, "Stop hit")}>Stop hit</Button>
            <input className="field w-24" placeholder="Exit price" value={exits[t.id] ?? ""} onChange={(e) => setExits({ ...exits, [t.id]: e.target.value })} />
            <Button size="sm" disabled={Number(exits[t.id]) <= 0 || !Number.isFinite(Number(exits[t.id]))} onClick={() => close(t, Number(exits[t.id]), "Manual")}>Close</Button>
            <details className="w-full"><summary className="cursor-pointer text-primary">Costs & targets</summary><div className="mt-2 flex flex-wrap gap-3">{([['brokeragePerOrder','Brokerage / order',BROKERAGE],['slippagePerSide','Slippage / side',SLIPPAGE],['otherCharges','Other charges / trade',0]] as const).map(([key,label,fallback]) => <label key={key} className="text-muted-foreground">{label}<input aria-label={`${label} ${t.symbol}`} className="field ml-2 w-24" type="number" min="0" step="0.0001" value={t[key] ?? fallback} onChange={(e) => { const value=Number(e.target.value); if (!Number.isFinite(value) || value < 0 || key==='slippagePerSide' && value>.05) return; update(trades.map((row) => row.id===t.id ? {...row,[key]:value,costAsOf:new Date().toISOString()} : row)); }}/></label>)}<span>Targets {(t.targets ?? [t.target]).map((x) => x.toFixed(2)).join(' · ')}</span><span>MAE / MFE {t.mae ?? 'Unavailable'} / {t.mfe ?? 'Unavailable'}</span></div></details>
          </div>
        ))}
      </div>

      <div className="panel overflow-x-auto">
        <div className="label mb-2">Journal</div>
        <table className="w-full font-mono text-xs">
          <thead className="text-muted-foreground"><tr>{["Closed", "Symbol", "Side", "Qty", "Entry", "Exit", "Reason", "AI said", "Net P&L"].map((h) => <th key={h} className="p-1 text-left font-normal">{h}</th>)}</tr></thead>
          <tbody>{closed.slice().reverse().map((t) => { const p = netPnl(t); return (
            <tr key={t.id} className="border-t"><td className="p-1">{fmtTime(t.closedAt ?? t.openedAt)}</td><td className="p-1">{t.symbol}</td><td className="p-1">{t.dir}</td><td className="p-1">{t.qty}</td><td className="p-1">{t.entry.toFixed(2)}</td><td className="p-1">{t.exit?.toFixed(2) ?? "—"}</td><td className="p-1">{t.reason}</td><td className="p-1">{t.aiDecision}</td><td className={`p-1 ${p > 0 ? "text-bull" : "text-bear"}`}>₹{p.toFixed(0)}</td></tr>
          ); })}</tbody>
        </table>
        {!!trades.length && <Button variant="outline" className="mt-3" onClick={() => confirm("Delete all paper trades?") && update([])}>Clear all</Button>}
      </div>
    </Shell>
  );
}
