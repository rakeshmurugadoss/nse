import { createContext, useContext, type ReactNode } from "react";
import type { User } from "@supabase/supabase-js";
export const ResearchSession = createContext<User | null>(null);
export const useResearchSession = () => useContext(ResearchSession);
export function ResearchSessionProvider({ user, children }: { user: User | null; children: ReactNode }) { return <ResearchSession.Provider value={user}>{children}</ResearchSession.Provider>; }