import { useRef, useState, type ReactNode } from "react";
import { TransformWrapper, TransformComponent } from "react-zoom-pan-pinch";
import { Download, ZoomIn, ZoomOut, RotateCcw, LoaderCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipProvider, TooltipTrigger, TooltipContent } from "@/components/ui/tooltip";
import { chartImage, saveChartImage } from "@/lib/chart-download";

export function ChartViewport({ children, title, asOf, filename, expanded = false, source = "DEMO" }: { children: ReactNode; title: string; asOf: string; filename: string; expanded?: boolean; source?: string }) {
  const surface = useRef<HTMLDivElement>(null);
  const [busy, setBusy] = useState(false);
  const [ready, setReady] = useState<Blob | null>(null);
  const [error, setError] = useState("");
  const [zoom, setZoom] = useState(1);
  const prepare = async () => {
    const svg = surface.current?.querySelector("svg"); if (!svg) return;
    setBusy(true); setError("");
    try { setReady(await chartImage(svg, title, asOf, source)); }
    catch { setError("Could not prepare the image. Please try again."); }
    finally { setBusy(false); }
  };
  return <TransformWrapper minScale={1} maxScale={8} initialScale={1} wheel={{ step: 0.08 }} doubleClick={{ step: 0.8 }} onTransform={(_, state) => setZoom(state.scale)}>
    {({ zoomIn, zoomOut, resetTransform }) => <>
      <div className="mb-2 flex flex-wrap items-center gap-2" role="toolbar" aria-label="Chart viewing controls">
        <TooltipProvider delayDuration={200}>{[{ label: "Zoom in", icon: ZoomIn, action: () => zoomIn(0.5, 0) }, { label: "Zoom out", icon: ZoomOut, action: () => zoomOut(0.5, 0) }, { label: "Reset chart view", icon: RotateCcw, action: () => resetTransform(0) }].map(({ label, icon: Icon, action }) => <Tooltip key={label}><TooltipTrigger asChild><Button variant="outline" size="icon" aria-label={label} onClick={action}><Icon /></Button></TooltipTrigger><TooltipContent>{label}</TooltipContent></Tooltip>)}</TooltipProvider>
        <output aria-label="Chart zoom level" className="w-12 font-mono text-xs text-muted-foreground">{Math.round(zoom * 100)}%</output>
        <Button variant="outline" size="icon" aria-label="Download chart" title="Download chart" disabled={busy} onClick={prepare}>{busy ? <LoaderCircle className="animate-spin" /> : <Download />}</Button>
        {ready && <Button size="sm" onClick={() => { void saveChartImage(ready, filename); }}>Save chart image</Button>}
      </div>
      {error && <p role="alert" className="mb-2 text-sm text-bear">{error}</p>}
      <div ref={surface} className={`chart-viewport overflow-hidden border bg-background ${expanded ? "chart-viewport-expanded" : ""}`}>
        <TransformComponent wrapperClass="chart-zoom-wrapper" contentClass="chart-zoom-content">{children}</TransformComponent>
      </div>
    </>}
  </TransformWrapper>;
}