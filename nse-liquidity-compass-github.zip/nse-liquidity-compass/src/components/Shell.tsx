import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { useResearchSession } from "./ResearchSession";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "./ui/button";

export function Shell({ children }: { children: ReactNode }) {
  const user = useResearchSession(), navigate = useNavigate(), qc = useQueryClient();
  const l = "rounded px-2 py-1 text-sm text-muted-foreground hover:text-foreground";
  const a = { className: "rounded px-2 py-1 text-sm text-primary" };
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-10 border-b bg-background/85 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-2 px-4 py-3">
          <Link to="/" className="mr-3 font-display text-2xl text-foreground">Liquidity<em className="text-primary">AI</em></Link>
          <Link to="/beginner" className={l} activeProps={a}>Beginner</Link>
          <Link to="/pro" className={l} activeProps={a}>Pro Terminal</Link>
          <Link to="/paper" className={l} activeProps={a}>Paper Trading</Link>
          <Link to="/predictions" className={l} activeProps={a}>AI Predictions</Link>
          {user ? <Button variant="ghost" size="sm" onClick={async () => { await qc.cancelQueries(); qc.clear(); await supabase.auth.signOut(); await navigate({ to: "/auth", replace: true }); }}>Sign out</Button> : <Button variant="ghost" size="sm" asChild><Link to="/auth">Sign in</Link></Button>}
        </div>
        <div className="border-t bg-warn/10 px-4 py-1 text-center font-mono text-[11px] text-warn">
          Check each report’s data source · Live analysis: Twelve Data snapshots · Screenshots: unverified · No real orders
        </div>
      </header>
      <main className="mx-auto max-w-7xl px-4 py-6">{children}</main>
    </div>
  );
}

export function Decision({ d }: { d: "BUY" | "SELL" | "WAIT" }) {
  const cls = d === "BUY" ? "bg-bull text-primary-foreground" : d === "SELL" ? "bg-bear text-destructive-foreground" : "bg-secondary text-foreground border";
  return <span className={`rounded-md px-4 py-1.5 font-display text-3xl tracking-wide ${cls}`}>{d}</span>;
}
