import { Checkbox } from "@/components/ui/checkbox";
import type { Zone } from "@/lib/engine";

const APPEARANCE = {
  "Bull FVG": { svg: "fill-fvg-bull stroke-fvg-bull", stroke: "stroke-fvg-bull", swatch: "bg-fvg-bull", label: "Bull FVG" },
  "Bear FVG": { svg: "fill-fvg-bear stroke-fvg-bear", stroke: "stroke-fvg-bear", swatch: "bg-fvg-bear", label: "Bear FVG" },
  "Bull OB": { svg: "fill-ob-bull stroke-ob-bull", stroke: "stroke-ob-bull", swatch: "bg-ob-bull", label: "Bull order block" },
  "Bear OB": { svg: "fill-ob-bear stroke-ob-bear", stroke: "stroke-ob-bear", swatch: "bg-ob-bear", label: "Bear order block" },
  "Bull Breaker": { svg: "fill-brk-bull stroke-brk-bull", stroke: "stroke-brk-bull", swatch: "bg-brk-bull", label: "Bull breaker" },
  "Bear Breaker": { svg: "fill-brk-bear stroke-brk-bear", stroke: "stroke-brk-bear", swatch: "bg-brk-bear", label: "Bear breaker" },
};
export const zoneAppearance = (kind: Zone["kind"]) => APPEARANCE[kind];

export function ChartZoneKey({ zones, history, onHistory }: { zones: Zone[]; history: boolean; onHistory: (value: boolean) => void }) {
  return <div className="mb-3 space-y-2 border-y py-3">
    <div className="flex flex-wrap gap-x-4 gap-y-2 text-xs" aria-label="Chart zone colours">{Object.entries(APPEARANCE).map(([kind, p]) => <span key={kind} className="inline-flex items-center gap-2"><span className={`h-3 w-3 shrink-0 rounded-sm ${p.swatch}`} />{p.label} <span className="font-mono text-muted-foreground">{zones.filter((z) => z.kind === kind).length}</span></span>)}</div>
    <label className="flex items-center gap-2 text-xs text-muted-foreground"><Checkbox checked={history} onCheckedChange={(value) => onHistory(value === true)} />Show invalidated zones</label>
    {!zones.length && <p className="text-xs text-muted-foreground">No active FVG, order block or breaker in this price window with the selected layers.</p>}
  </div>;
}