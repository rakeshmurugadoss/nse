import { useState } from "react";
import { Button } from "@/components/ui/button";
import { fmtPrice, fmtTime, priceDigits, symbolLabel, type Plan, type TFAnalysis, type AdvancedDetection } from "@/lib/engine";
import { ChartViewport } from "@/components/ChartViewport";
import { Dialog, DialogContent, DialogDescription, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Maximize2 } from "lucide-react";
import { zoneAppearance, ChartZoneKey } from "@/components/ChartZoneKey";

export const LAYERS = ["Liquidity", "EQH/EQL", "Order Blocks", "Breakers", "FVG", "OTE", "Support/Resistance", "BOS/CHoCH", "Swings", "Premium/Discount", "Trade Plan"] as const;
type Layer = (typeof LAYERS)[number];

export function Chart({ a, plan, bars = 120, compact, source = "DEMO", detections = [] }: { a: TFAnalysis; plan: Plan | null; bars?: number; compact?: boolean; source?: string; detections?: AdvancedDetection[] }) {
  const [advancedOn, setAdvancedOn] = useState(true);
  const [on, setOn] = useState<Record<Layer, boolean>>(() => Object.fromEntries(LAYERS.map((l) => [l, true])) as Record<Layer, boolean>);
  const [tip, setTip] = useState<string | null>(null);
  const [history, setHistory] = useState(false);
  const c = a.candles.slice(-bars);
  if (!c.length) return <p>No candle data.</p>;
  const f = (p: number) => fmtPrice(a.symbol, p);
  const t0 = c[0].t;
  const W = 1200, H = compact ? 420 : 560, PR = 300;
  const tradeHeader = on["Trade Plan"] ? 220 : 0;
  let hi = Math.max(...c.map((x) => x.h)), lo = Math.min(...c.map((x) => x.l));
  if (plan && on["Trade Plan"]) { const prices = [plan.entryLow, plan.entryHigh, plan.sl, ...plan.targets.map((target) => target.price)]; hi = Math.max(hi, ...prices); lo = Math.min(lo, ...prices); }
  const pad = Math.max((hi - lo) * 0.05, Math.abs(hi) * 0.00001); hi += pad; lo -= pad;
  const y = (p: number) => ((hi - p) / (hi - lo)) * H;
  const cw = (W - PR) / c.length;
  const xT = (t: number) => { const i = c.findIndex((k) => k.t >= t); return i < 0 ? W - PR : i * cw; };
  const vis = (p: number) => p <= hi && p >= lo;
  const asOf = fmtTime(c[c.length - 1].t);
  const title = `${symbolLabel(a.symbol)} · ${a.tf} · Liquidity AI analysis`;
  const filename = `liquidity-ai-${a.symbol.toLowerCase()}-${a.tf}-${new Date(c[c.length - 1].t).toISOString().slice(0, 16).replace(/[:T]/g, "-")}.png`;
  const hover = (s: string) => ({ onMouseEnter: () => setTip(s), onClick: () => setTip(s), style: { cursor: "pointer" } });
  const shownZones = a.zones.filter((z) => (history || z.status !== "Invalidated") && z.top >= lo && z.bottom <= hi && ((z.kind.includes("OB") && on["Order Blocks"]) || (z.kind.includes("FVG") && on["FVG"]) || (z.kind.includes("Breaker") && on["Breakers"])));
  const advancedMarks = advancedOn ? detections.filter((d) => d.tf === a.tf && d.status !== "Invalidated" && d.availableAt >= t0 && vis(d.top) && !d.type.startsWith("Internal") && !d.type.startsWith("External")).slice(-4) : [];
  const labelledZones = [...shownZones].sort((p, q) => q.t - p.t).slice(0, advancedMarks.length ? 4 : 8).sort((p, q) => y(p.top) - y(q.top));
  const labelLimit = H - advancedMarks.length * 58;
  let previousLabel = -60;
  const labels = labelledZones.map((z, i) => {
    const natural = Math.max(14, Math.min(labelLimit - 50, y((z.top + z.bottom) / 2) - 20));
    const ly = Math.max(previousLabel + 58, Math.min(natural, labelLimit - (labelledZones.length - i) * 58));
    previousLabel = ly;
    return { z, ly };
  });
  const support = [...a.liquidity].filter((l) => l.status === "Untouched" && ["SSL", "EQL", "PDL"].includes(l.kind) && l.price < c[c.length - 1].c).sort((p, q) => q.price - p.price)[0];
  const resistance = [...a.liquidity].filter((l) => l.status === "Untouched" && ["BSL", "EQH", "PDH"].includes(l.kind) && l.price > c[c.length - 1].c).sort((p, q) => p.price - q.price)[0];

  const chart = <svg viewBox={`0 0 ${W} ${H + tradeHeader}`} role="img" aria-label={`${title} · ${source} · ${plan?.dir ?? "WAIT"} trade idea`} className="block w-full bg-background text-foreground" onMouseLeave={() => setTip(null)}>
        {tradeHeader > 0 && <g aria-label="Chart trade idea" className="font-mono">
          <rect x={10} y={10} width={W - 20} height={196} rx={6} className="fill-background stroke-border" strokeWidth={2} />
          <text x={30} y={52} fontSize={34} className={plan?.dir === "BUY" ? "fill-bull" : plan?.dir === "SELL" ? "fill-bear" : "fill-warn"}>{plan?.dir ?? "WAIT"}</text>
          <text x={205} y={52} fontSize={26} className="fill-muted-foreground">{source === "DEMO" ? "DEMO" : source === "TWELVE_DATA" ? "TWELVE DATA" : source} · {a.tf} · RESEARCH ONLY</text>
          {plan ? <>
            <text x={30} y={98} fontSize={34} className="fill-primary">Entry {f(plan.entryLow)}–{f(plan.entryHigh)}</text>
            {[{ label: "SL", value: plan.sl, cls: "fill-bear" }, { label: "T1", value: plan.targets[0]?.price, cls: "fill-bull" }, { label: "T2", value: plan.targets[1]?.price, cls: "fill-bull" }].map(({ label, value, cls }, i) => <text key={label} x={30 + i * 390} y={146} fontSize={32} className={cls}>{label} {value === undefined ? "—" : f(value)}</text>)}
            <text x={30} y={185} fontSize={24} className="fill-muted-foreground">Conditional setup · confirm before any paper trade</text>
          </> : <>
            <text x={30} y={110} fontSize={34} className="fill-foreground">No clear setup · no entry, SL or targets</text>
            <text x={30} y={164} fontSize={28} className={a.trend === "bull" ? "fill-bull" : a.trend === "bear" ? "fill-bear" : "fill-muted-foreground"}>{a.trend === "bull" ? "↑ Bullish structure" : a.trend === "bear" ? "↓ Bearish structure" : "↔ Sideways structure"}</text>
          </>}
        </g>}
        <g transform={`translate(0 ${tradeHeader})`}>
        {on["Premium/Discount"] && a.range && (
          <>
            <rect x={0} y={y(a.range.high)} width={W - PR} height={Math.max(0, y(a.range.eq) - y(a.range.high))} className="fill-bear/5" {...hover(`Premium zone ${f(a.range.eq)}–${f(a.range.high)} · ${a.tf}`)} />
            <rect x={0} y={y(a.range.eq)} width={W - PR} height={Math.max(0, y(a.range.low) - y(a.range.eq))} className="fill-bull/5" {...hover(`Discount zone ${f(a.range.low)}–${f(a.range.eq)} · ${a.tf}`)} />
            <line x1={0} x2={W - PR} y1={y(a.range.eq)} y2={y(a.range.eq)} className="stroke-muted-foreground" strokeDasharray="2 4" />
          </>
        )}
        {on["OTE"] && a.ote && a.ote.status !== "Invalidated" && (() => { const o = a.ote; const x0 = xT(o.t); return <g aria-label="OTE zone" {...hover(`ICT OTE (${o.dir === "bull" ? "buy" : "sell"} side) ${f(o.bottom)}–${f(o.top)} · sweet spot 70.5% ${f(o.sweet)} · ${o.status} · 62–79% retracement of the latest ${o.dir === "bull" ? "bullish" : "bearish"} structure leg`)}><rect x={x0} y={y(o.top)} width={W - PR - x0} height={Math.max(2, y(o.bottom) - y(o.top))} className="fill-ote stroke-ote" fillOpacity={0.12} strokeOpacity={0.7} strokeDasharray="2 3" /><line x1={x0} x2={W - PR} y1={y(o.sweet)} y2={y(o.sweet)} className="stroke-ote" strokeWidth={1.2} /><text x={x0 + 4} y={y(o.top) - 4} fontSize={11} className="fill-ote font-mono">OTE 62–79% · {o.status}</text></g>; })()}
        {shownZones.map((z, i) => {
          const appearance = zoneAppearance(z.kind);
          const top = Math.max(0, y(z.top)), bottom = Math.min(H, y(z.bottom));
          return <g key={i} aria-label={`${z.kind} zone ${f(z.bottom)} to ${f(z.top)}`} {...hover(`${z.kind} ${f(z.bottom)}–${f(z.top)} · ${z.tf} · ${z.status} · ${z.note}`)}><rect x={xT(z.t)} y={top} width={W - PR - xT(z.t)} height={Math.max(2, bottom - top)} className={appearance.svg} fillOpacity={z.status === "Invalidated" ? 0.05 : z.kind.includes("FVG") ? 0.17 : 0.22} strokeOpacity={z.status === "Invalidated" ? 0.3 : 0.85} strokeWidth={1.5} strokeDasharray={z.kind.includes("FVG") ? "6 3" : z.kind.includes("Breaker") ? "1 3" : undefined} /><title>{`${z.kind} · ${z.status} · ${f(z.bottom)}–${f(z.top)}`}</title></g>;
        })}
        {c.map((k, i) => {
          const up = k.c >= k.o; const cls = up ? "stroke-bull fill-bull" : "stroke-bear fill-bear";
          return (
            <g key={k.t} className={cls}>
              <line x1={i * cw + cw / 2} x2={i * cw + cw / 2} y1={y(k.h)} y2={y(k.l)} strokeWidth={1} />
              <rect x={i * cw + cw * 0.15} y={y(Math.max(k.o, k.c))} width={cw * 0.7} height={Math.max(1, Math.abs(y(k.o) - y(k.c)))} />
            </g>
          );
        })}
        {a.liquidity.filter((l) => vis(l.price) && (["EQH", "EQL"].includes(l.kind) ? on["EQH/EQL"] : on["Liquidity"])).map((l, i) => {
          const x0 = l.kind.startsWith("PD") ? 0 : xT(l.t);
          return (
            <g key={i} {...hover(`${l.kind} ${f(l.price)} · ${l.tf} · ${l.status} · ${f(l.distPct)}% away · ${l.note}`)}>
              <line x1={x0} x2={W - PR} y1={y(l.price)} y2={y(l.price)} className="stroke-liq" strokeOpacity={l.status === "Untouched" ? 0.9 : 0.35} strokeDasharray={l.status === "Untouched" ? undefined : "4 3"} strokeWidth={l.kind.length === 3 && l.kind !== "BSL" && l.kind !== "SSL" ? 1.6 : 1} />
              <title>{l.kind} · {f(l.price)} · {l.status}</title>
            </g>
          );
        })}
        {on["BOS/CHoCH"] && a.events.filter((e) => e.t >= t0 && vis(e.price)).map((e, i) => (
          <g key={i} {...hover(`${e.kind} ${e.dir === "bull" ? "bullish" : "bearish"} at ${f(e.price)} · ${e.tf}`)}>
            <line x1={Math.max(0, xT(e.t) - cw * 8)} x2={xT(e.t)} y1={y(e.price)} y2={y(e.price)} className={e.dir === "bull" ? "stroke-bull" : "stroke-bear"} strokeWidth={1.5} />
            <text x={xT(e.t) - cw * 8} y={y(e.price) + (e.dir === "bull" ? -4 : 11)} fontSize={10} className={`${e.dir === "bull" ? "fill-bull" : "fill-bear"} font-mono`}>{e.kind}</text>
          </g>
        ))}
        {on["Swings"] && a.swings.filter((s) => s.t >= t0).map((s, i) => (
          <text key={i} x={xT(s.t)} y={s.type === "high" ? y(s.price) - 5 : y(s.price) + 13} fontSize={9} className="fill-muted-foreground font-mono" textAnchor="middle" {...hover(`${s.label} ${f(s.price)} · ${a.tf} · confirmed fractal swing`)}>{s.label}</text>
        ))}
        {plan && on["Trade Plan"] && (
          <g>
            <rect x={W - PR - cw * 25} y={y(plan.entryHigh)} width={cw * 25} height={Math.max(2, y(plan.entryLow) - y(plan.entryHigh))} className="fill-primary" fillOpacity={0.3} {...hover(`Entry zone ${f(plan.entryLow)}–${f(plan.entryHigh)}`)} />
            <line x1={W - PR - cw * 25} x2={W - PR} y1={y(plan.sl)} y2={y(plan.sl)} className="stroke-destructive" strokeWidth={2} {...hover(`Stop loss ${f(plan.sl)}`)} />
            {plan.targets.filter((t) => vis(t.price)).map((t, i) => (
              <line key={i} x1={W - PR - cw * 25} x2={W - PR} y1={y(t.price)} y2={y(t.price)} className="stroke-bull" strokeWidth={2} {...hover(`Target ${i + 1} ${f(t.price)} · ${t.why}`)} />
            ))}
          </g>
        )}
        {advancedMarks.map((d, i) => {
          const ly = labelLimit + i * 58;
          const cls = d.direction === "bull" ? "stroke-brk-bull" : d.direction === "bear" ? "stroke-fvg-bear" : "stroke-liq";
          return <g key={`advanced-${i}`} aria-label={d.type} {...hover(`${d.type} ${f(d.bottom)}–${f(d.top)} · available ${fmtTime(d.availableAt)} · ${d.reason}`)}>
            <rect x={xT(d.availableAt)} y={Math.max(0, y(d.top))} width={Math.max(1, W - PR - xT(d.availableAt))} height={Math.max(2, Math.min(H, y(d.bottom)) - Math.max(0, y(d.top)))} className={cls} fill="none" strokeDasharray="3 5"/>
            <path d={`M ${W - PR - 8} ${Math.max(2, Math.min(H - 2, y(d.top)))} L ${W - PR + 44} ${ly + 22}`} fill="none" className={cls}/>
            <rect x={W - PR + 44} y={ly} width={205} height={50} rx={4} className={`fill-background ${cls}`} />
            <text x={W - PR + 53} y={ly + 17} fontSize={11} className="fill-foreground font-mono">{d.type}</text>
            <text x={W - PR + 53} y={ly + 36} fontSize={12} className="fill-muted-foreground font-mono">{f(d.bottom)}–{f(d.top)}</text>
          </g>;
        })}
        {[0, 0.25, 0.5, 0.75, 1].map((f) => (
          <text key={f} x={W - 4} y={f * H + (f === 0 ? 10 : f === 1 ? -3 : 3)} textAnchor="end" fontSize={10} className="fill-muted-foreground font-mono">{(hi - f * (hi - lo)).toFixed(priceDigits(a.symbol))}</text>
        ))}
        {on["Support/Resistance"] && [{ level: support, name: "Support candidate", cls: "stroke-bull fill-bull" }, { level: resistance, name: "Resistance candidate", cls: "stroke-bear fill-bear" }].map(({ level, name, cls }) => level && vis(level.price) ? <g key={name} {...hover(`${name} · ${level.kind} · ${f(level.price)} · Untouched liquidity, not guaranteed to hold`)}><line x1={0} x2={W - PR} y1={y(level.price)} y2={y(level.price)} className={cls} strokeWidth={2} strokeDasharray="10 5" /><rect x={10} y={Math.max(2, Math.min(H - 25, y(level.price) - 23))} width={230} height={22} rx={3} className="fill-background" /><text x={16} y={Math.max(17, Math.min(H - 10, y(level.price) - 7))} className={`${cls} font-mono`} strokeWidth={0} fontSize={12}>{name} {f(level.price)}</text></g> : null)}
        {labels.map(({ z, ly }, i) => <g key={i} aria-label={`${z.kind} label`} {...hover(`${z.kind} ${f(z.bottom)}–${f(z.top)} · ${z.status} · ${z.note}`)}>
          <path d={`M ${W - PR - 8} ${Math.max(2, Math.min(H - 2, y((z.top + z.bottom) / 2)))} L ${W - PR + 34} ${ly + 22} L ${W - PR + 44} ${ly + 22}`} fill="none" className={zoneAppearance(z.kind).svg} strokeWidth={1.3} fillOpacity={0} />
          <rect x={W - PR + 44} y={ly} width={205} height={50} rx={4} className={`fill-background ${zoneAppearance(z.kind).stroke}`} fillOpacity={1} strokeWidth={1.5} />
          <text x={W - PR + 53} y={ly + 17} className={`${zoneAppearance(z.kind).svg} font-mono`} strokeWidth={0} fontSize={13}>{z.kind} · {z.status}</text>
          <text x={W - PR + 53} y={ly + 36} className="fill-foreground font-mono" fontSize={12}>{f(z.bottom)}–{f(z.top)}</text>
        </g>)}
        </g>
      </svg>;
    return <div>
      <div className="mb-2 flex flex-wrap gap-1">
        {!!detections.length && <Button size="sm" variant="outline" aria-pressed={advancedOn} onClick={() => setAdvancedOn(!advancedOn)}>Advanced structures</Button>}
        {LAYERS.map((l) => <Button size="sm" variant="outline" aria-pressed={on[l]} key={l} onClick={() => setOn({ ...on, [l]: !on[l] })} className={`chip ${on[l] ? "border-primary text-primary" : "text-muted-foreground"}`}>{l}</Button>)}
      </div>
      <ChartZoneKey zones={shownZones} history={history} onHistory={setHistory} />
      <div className="mb-2 flex justify-end"><Dialog><DialogTrigger asChild><Button variant="outline" size="sm"><Maximize2 />Full view</Button></DialogTrigger><DialogContent className="h-[100dvh] max-w-none grid-rows-[auto_auto_1fr_auto] gap-3 overflow-y-auto p-4 sm:h-[92dvh] sm:w-[96vw] sm:rounded-xl"><div className="pr-10"><DialogTitle className="font-display text-2xl">{title}</DialogTitle><DialogDescription>{source} candles · last bar starts {asOf} IST</DialogDescription></div><ChartViewport title={title} asOf={asOf} source={source} filename={filename} expanded>{chart}</ChartViewport><p className="min-h-5 font-mono text-xs text-muted-foreground">{tip ?? ""}</p></DialogContent></Dialog></div>
      <ChartViewport key={`${a.symbol}-${a.tf}-${source}-${c[c.length - 1].t}-${history}-${LAYERS.map((l) => on[l]).join()}`} title={title} asOf={asOf} source={source} filename={filename}>{chart}</ChartViewport>
      <p className="mt-1 min-h-5 font-mono text-xs text-muted-foreground">{tip ?? ""}</p>
    </div>;
}
