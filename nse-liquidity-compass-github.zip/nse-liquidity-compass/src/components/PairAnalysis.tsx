import { useState } from "react";
import { Button } from "@/components/ui/button";
import { PAIR_COMPARISONS, TFS, fmtPrice, fmtTime, symbolLabel, type PairOptions, type Report } from "@/lib/engine";

export function PairAnalysis({ r, onChange, simple = false }: { r: Report; onChange: (options: PairOptions) => void; simple?: boolean }) {
  const [detail, setDetail] = useState(!simple);
  if (r.market !== "forex") return null;
  const d = r.divergence;
  const candidates = PAIR_COMPARISONS[r.symbol] ?? [];
  return <section aria-label="Correlated-pair divergence" className="space-y-4 border-y py-5">
    <div className="flex flex-wrap items-center justify-between gap-3"><h2 className="text-3xl">Pair <em>Divergence</em></h2><div className="flex gap-1"><Button size="sm" variant={!detail ? "default" : "outline"} onClick={() => setDetail(false)}>Simple</Button><Button size="sm" variant={detail ? "default" : "outline"} onClick={() => setDetail(true)}>Intermediate</Button></div></div>
    <p className="text-xs text-warn">{r.source === "DEMO" ? "DEMO comparison · Not live Forex confirmation" : `${r.source} comparison · Closed, aligned candles only`}</p>
    {!d || !candidates.length ? <p className="text-sm text-muted-foreground">No supported currency-pair comparison for {symbolLabel(r.symbol)}. Gold requires a suitable synchronised comparison feed.</p> : <>
      <div className="flex flex-wrap items-end gap-3">
        <label className="min-w-0 text-sm text-muted-foreground">Compare with<select aria-label="Comparison pair" className="field mt-1 block w-full font-mono" value={d.peer} onChange={(e) => onChange({ symbol: e.target.value, tf: d.tf })}>{candidates.map((p) => <option key={p.symbol} value={p.symbol}>{symbolLabel(p.symbol)} · {p.inverse ? "Inverse" : "Positive"}</option>)}</select></label>
        <label className="text-sm text-muted-foreground">Timeframe<select aria-label="Divergence timeframe" className="field mt-1 block font-mono" value={d.tf} onChange={(e) => onChange({ symbol: d.peer, tf: e.target.value as PairOptions["tf"] })}>{TFS.map((tf) => <option key={tf} value={tf}>{tf}</option>)}</select></label>
      </div>
      <div className="flex flex-wrap items-baseline justify-between gap-2 border-b pb-3"><h3 className={`text-2xl ${d.status === "Bullish divergence" ? "text-bull" : d.status === "Bearish divergence" ? "text-bear" : "text-warn"}`}>{d.status}</h3><span className="font-mono text-xs text-muted-foreground">Return correlation {d.correlation === null ? "—" : d.correlation.toFixed(2)}</span></div>
      <p className="text-sm text-muted-foreground">{d.reason}</p>
      {detail && <div className="space-y-3 border-t pt-3 text-sm">
        <p className="font-mono text-xs text-muted-foreground">{d.samples} pre-event returns · {d.inverse ? "Inverse" : "Positive"} relationship · minimum {d.inverse ? "−0.70" : "+0.70"} correlation · {d.asOf ? `closed at ${fmtTime(d.asOf)} IST` : "No aligned candle"}</p>
        {d.reference && d.primary && d.comparison && <div className="overflow-x-auto"><table className="w-full text-left font-mono text-xs"><thead className="text-muted-foreground"><tr><th className="py-2 font-normal">Pair</th><th className="p-2 font-normal">Prior 20-bar low / high</th><th className="p-2 font-normal">Latest low / high</th></tr></thead><tbody>{[{ symbol: d.symbol, low: d.reference.low, high: d.reference.high, candle: d.primary }, { symbol: d.peer, low: d.reference.peerLow, high: d.reference.peerHigh, candle: d.comparison }].map((x) => <tr key={x.symbol} className="border-t"><td className="py-2">{symbolLabel(x.symbol)}</td><td className="p-2">{fmtPrice(x.symbol, x.low)} / {fmtPrice(x.symbol, x.high)}</td><td className="p-2">{fmtPrice(x.symbol, x.candle.l)} / {fmtPrice(x.symbol, x.candle.h)}</td></tr>)}</tbody></table></div>}
        <p className="text-muted-foreground">Liquidity-sweep SMT: one pair breaks and closes back inside its prior 20-bar extreme while the other stays inside its equivalent extreme. Equal levels and tiny breaks are excluded. Correlations change; missing or unfinished candles cannot confirm divergence.</p>
      </div>}
      <p className="text-sm text-muted-foreground">Extra evidence only. Entry still needs aligned structure, an OB/FVG retest, a trigger and risk checks. Divergence does not override the judge or change its scores.</p>
    </>}
  </section>;
}