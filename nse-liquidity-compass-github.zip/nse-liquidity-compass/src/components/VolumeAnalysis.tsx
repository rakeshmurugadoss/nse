import { useState } from "react";
import { Button } from "@/components/ui/button";
import { fmtPrice, fmtTime, type Report } from "@/lib/engine";

export function VolumeAnalysis({ r, simple = false }: { r: Report; simple?: boolean }) {
  const [detail, setDetail] = useState(!simple);
  const p = r.profile;
  const f = (v: number) => fmtPrice(r.symbol, v);
  if (!p) return <section className="border-y py-5"><h2 className="text-3xl">Volume analysis</h2><p>Volume data unavailable. Volume Profile, VWAP and relative-volume confirmation are not used when this feed supplies no volume.</p></section>;
  const max = Math.max(...p.bins.map((b) => b.volume));
  const height = 240, width = 480;
  const y = (v: number) => height - (v - p.bins[0].low) / (p.bins[p.bins.length - 1].high - p.bins[0].low) * height;
  return <section aria-label="Volume analysis" className="space-y-4 border-y py-5">
    <div className="flex flex-wrap items-center justify-between gap-3"><h2 className="text-3xl">Volume <em>Profile</em></h2><div className="flex gap-1" aria-label="Volume detail level"><Button size="sm" variant={!detail ? "default" : "outline"} onClick={() => setDetail(false)}>Simple</Button><Button size="sm" variant={detail ? "default" : "outline"} onClick={() => setDetail(true)}>Intermediate</Button></div></div>
    <p className="text-xs text-warn">{r.source === "DEMO" ? r.market === "forex" ? "Demo tick activity · Forex has no centralised traded-volume feed" : "Demo candle volume" : "Provider candle volume"} · Estimated distribution, not real order flow</p>
    <div className="grid gap-5 md:grid-cols-2">
      <div className="space-y-3"><p className="text-lg">{r.volumeContext}</p>
        <dl className="space-y-2 text-sm">{[["Most active price · POC", p.poc], ["Upper value edge · VAH", p.vah], ["Lower value edge · VAL", p.val]].map(([label, value]) => <div key={String(label)} className="flex justify-between gap-2 border-b pb-2"><dt className="text-muted-foreground">{label}</dt><dd className="font-mono">{f(Number(value))}</dd></div>)}</dl>
        <p className="text-sm text-muted-foreground">The value area holds at least 70% of estimated activity. Volume supports the liquidity and structure checks; it does not confirm a trade alone.</p>
      </div>
      <svg viewBox={`0 0 ${width} ${height}`} role="img" aria-label="Estimated volume activity by price" className="w-full border-l">
        {p.bins.map((b, i) => <rect key={i} x={0} y={y(b.high)} width={max ? b.volume / max * 300 : 0} height={height / p.bins.length - 1} className={b.low <= p.poc && b.high >= p.poc ? "fill-primary" : b.low >= p.val && b.high <= p.vah ? "fill-liq/60" : "fill-muted-foreground/30"}><title>{`${f(b.low)}–${f(b.high)} · ${b.volume.toFixed(0)} estimated activity`}</title></rect>)}
        {([["VAH", p.vah], ["POC", p.poc], ["VAL", p.val]] as const).map(([label, v]) => <g key={label}><line x1={0} x2={310} y1={y(v)} y2={y(v)} className="stroke-primary" strokeDasharray="3 3" /><text x={320} y={Math.max(13, Math.min(height - 5, y(v) + 4))} className="fill-foreground font-mono" fontSize={11}>{label} {f(v)}</text></g>)}
      </svg>
    </div>
    {detail && <div className="space-y-3 border-t pt-3 text-sm">
      <p className="font-mono text-xs text-muted-foreground">Developing UTC day · {fmtTime(p.start)} – {fmtTime(p.end)} IST · excludes last two candles for acceptance check</p>
      <div className="grid gap-3 md:grid-cols-2"><div><div className="label">High-volume nodes · activity clusters</div><p className="mt-1 font-mono">{p.hvn.length ? p.hvn.map(f).join(" · ") : "None identified"}</p></div><div><div className="label">Low-volume nodes · thin activity</div><p className="mt-1 font-mono">{p.lvn.length ? p.lvn.map(f).join(" · ") : "None identified"}</p></div></div>
      {r.previousProfile && <p className="font-mono text-xs">Previous UTC day: POC {f(r.previousProfile.poc)} · VAH {f(r.previousProfile.vah)} · VAL {f(r.previousProfile.val)}</p>}
      <p className="text-muted-foreground">Each candle’s activity is spread evenly across its high–low range. Nodes and value edges are approximations; bid/ask delta, footprint and actual volume at price are unavailable.</p>
    </div>}
  </section>;
}