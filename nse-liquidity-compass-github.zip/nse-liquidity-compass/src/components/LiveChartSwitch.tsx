import { useEffect, useRef, useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { marketOf } from "@/lib/engine";

/** Maps app symbols to TradingView feed symbols (view-only; our engine cannot read these candles). */
export function tvSymbol(symbol: string) {
  if (symbol === "XAUUSD") return "OANDA:XAUUSD";
  if (symbol === "TATAMOTORS") return "NSE:TATAMOTORS";
  return marketOf(symbol) === "forex" ? `FX:${symbol}` : `NSE:${symbol}`;
}

const TV_INTERVAL: Record<string, string> = { "1m": "1", "5m": "5", "15m": "15", "1h": "60" };

function TradingViewWidget({ symbol, interval }: { symbol: string; interval: string }) {
  const q = new URLSearchParams({
    symbol: tvSymbol(symbol), interval: TV_INTERVAL[interval] ?? "15", theme: "dark", style: "1", locale: "en",
    timezone: marketOf(symbol) === "forex" ? "Etc/UTC" : "Asia/Kolkata", hide_side_toolbar: "0", allow_symbol_change: "1",
    withdateranges: "1", toolbarbg: "0b0f17",
  });
  return (
    <iframe
      key={`${symbol}-${interval}`}
      title={`Live TradingView chart for ${tvSymbol(symbol)}`}
      src={`https://s.tradingview.com/widgetembed/?${q.toString()}`}
      className="h-[60dvh] min-h-[380px] w-full rounded-md border"
      allowFullScreen
    />
  );
}

export function LiveChartSwitch({ symbol, interval, label, children, source = "DEMO", onAnalyzeLive, busy }: { symbol: string; interval: string; label: string; children: ReactNode; source?: string; onAnalyzeLive?: () => void; busy?: boolean }) {
  const [view, setView] = useState<"ai" | "live">("ai");
  const chartArea = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (source !== "TWELVE_DATA") return;
    setView("ai");
    const frame = requestAnimationFrame(() => chartArea.current?.scrollIntoView({ block: "start", behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth" }));
    return () => cancelAnimationFrame(frame);
  }, [source, symbol]);
  return (
    <div ref={chartArea} className="scroll-mt-20">
      <div className="mb-2 flex flex-wrap items-center gap-2">
        <div className="label mr-auto">{view === "ai" ? label : `Live TradingView · ${tvSymbol(symbol)}`}</div>
        <div className="flex rounded-md border" role="tablist" aria-label="Chart view">
          <Button size="sm" role="tab" aria-selected={view === "ai"} variant={view === "ai" ? "default" : "ghost"} onClick={() => setView("ai")}>AI chart</Button>
          <Button size="sm" role="tab" aria-selected={view === "live"} variant={view === "live" ? "default" : "ghost"} onClick={() => setView("live")}>
            <span className="mr-1 inline-block h-2 w-2 rounded-full bg-bull" aria-hidden />Live chart
          </Button>
        </div>
      </div>
      {view === "ai" ? children : (
        <>
          <TradingViewWidget symbol={symbol} interval={interval} />
          {marketOf(symbol) === "forex" && onAnalyzeLive && <Button className="mt-3" disabled={busy} onClick={() => { setView("ai"); onAnalyzeLive(); }}>Analyze live with Twelve Data</Button>}
          <p className="mt-2 text-xs text-muted-foreground">TradingView is view-only. AI analysis uses {source === "DEMO" ? "DEMO candles" : "separate Twelve Data candles"}, not this chart. Feeds may differ; changing the symbol inside TradingView does not change the app instrument. {marketOf(symbol) === "nse" && " TradingView may block Indian NSE stocks inside other websites — if so, "}{marketOf(symbol) === "nse" && <a className="text-primary underline" href={`https://www.tradingview.com/chart/?symbol=${encodeURIComponent(tvSymbol(symbol))}`} target="_blank" rel="noreferrer">open it on TradingView</a>}</p>
        </>
      )}
    </div>
  );
}
