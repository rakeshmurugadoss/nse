import { useNavigate } from "@tanstack/react-router";
import { fmtPrice, type Report } from "@/lib/engine";
import { Button } from "@/components/ui/button";
import { loadTrades, saveTrades } from "@/lib/paper";

export function PlanCard({ r }: { r: Report }) {
  const nav = useNavigate();
  const p = r.plan;
  const f = (v: number) => fmtPrice(r.symbol, v);
  if (!p) return <div className="panel"><div className="label">Trade plan</div><p className="mt-2 text-sm text-muted-foreground">No plan — required conditions are not met. Waiting is a position.</p></div>;
  const paper = () => {
    const t = loadTrades();
    const first = p.targets[0]; if (!first || p.qty <= 0) return;
    t.push({ id: crypto.randomUUID(), symbol: r.symbol, dir: p.dir, qty: p.qty, entry: (p.entryLow + p.entryHigh) / 2, sl: p.sl, target: first.price, targets: p.targets.map((x) => x.price), openedAt: Date.now(), strategy: "Liquidity + OB/FVG", aiDecision: r.decision });
    saveTrades(t); nav({ to: "/paper" });
  };
  return (
    <div className="panel space-y-2">
      <div className="flex items-center justify-between"><div className="label">Trade plan · {p.dir} {r.decision === "WAIT" && "(watch only)"}</div><span className="chip">R:R {p.rr.toFixed(2)}</span></div>
      <Row k="Entry zone" v={`${f(p.entryLow)} – ${f(p.entryHigh)}`} />
      <Row k="Stop loss" v={f(p.sl)} cls="text-bear" />
      {p.targets.map((t, i) => <Row key={i} k={`Target ${i + 1}`} v={`${f(t.price)}  · ${t.why}`} cls="text-bull" />)}
      {r.market === "nse" ? <Row k="Position size" v={`${p.qty} shares · risk ₹${p.risk.toFixed(0)}`} /> : <p className="text-xs text-warn">Lot sizing and Forex paper orders unavailable — broker contract, account currency and costs are required.</p>}
      <p className="text-xs text-muted-foreground"><b className="text-foreground">Invalidation:</b> {p.invalidation}</p>
      <ul className="list-disc pl-4 text-xs text-muted-foreground">{p.confirmation.map((c) => <li key={c}>{c}</li>)}</ul>
      {r.market === "nse" && <Button className="w-full" onClick={paper}>Paper {p.dir} (simulated)</Button>}
    </div>
  );
}
const Row = ({ k, v, cls = "" }: { k: string; v: string; cls?: string }) => (
  <div className="flex justify-between gap-3 text-sm"><span className="text-muted-foreground">{k}</span><span className={`text-right font-mono ${cls}`}>{v}</span></div>
);
