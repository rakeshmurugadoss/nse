import { fmtPrice, type Report, type TFAnalysis } from "@/lib/engine";

export function IctPanel({ r, a, simple }: { r: Report; a: TFAnalysis; simple?: boolean }) {
  const f = (p: number) => fmtPrice(r.symbol, p);
  const o = a.ote;
  const breakers = a.zones.filter((z) => z.kind.includes("Breaker") && z.status !== "Invalidated").slice(-3);
  const activeKz = r.killzones.filter((k) => k.active);
  return <div className="panel space-y-4 text-sm">
    <div><div className="label">ICT tools · {a.tf}</div><p className="text-xs text-muted-foreground">{r.source} candles · extra context only, not an entry signal.</p></div>
    {r.market === "forex" ? <div>
      <h3 className="mb-2 font-display text-lg">Killzones & Silver Bullet</h3>
      <p className="mb-2">{activeKz.length ? <>At the latest candle: <span className="text-primary">{activeKz.map((k) => k.name).join(" + ")}</span></> : "At the latest candle: outside all killzones — moves are usually weaker."}</p>
      <div className="flex flex-wrap gap-2">{r.killzones.map((k) => <span key={k.name} className={`rounded border px-2 py-1 font-mono text-xs ${k.active ? "border-primary text-primary" : "text-muted-foreground"}`}>{k.name} {k.start}–{k.end}</span>)}</div>
      <p className="mt-1 text-xs text-muted-foreground">Times are New York time{simple ? "" : " (DST-aware)"}. Silver Bullet = 1-hour window to look for an FVG entry after a liquidity sweep.</p>
    </div> : <p className="text-xs text-muted-foreground">Killzones apply to Forex and Gold. NSE uses its own session analysis.</p>}
    <div>
      <h3 className="mb-1 font-display text-lg">Optimal Trade Entry (OTE)</h3>
      {o ? <p>{simple ? `Best pullback area for a ${o.dir === "bull" ? "buy" : "sell"}: ` : `${o.dir === "bull" ? "Bullish" : "Bearish"} leg ${f(o.legLow)}–${f(o.legHigh)} · 62–79% zone `}<span className="font-mono">{f(o.bottom)}–{f(o.top)}</span> · sweet spot <span className="font-mono">{f(o.sweet)}</span> · <span className="text-primary">{o.status}</span></p> : <p className="text-muted-foreground">No structure break yet, so no OTE zone.</p>}
    </div>
    <div>
      <h3 className="mb-1 font-display text-lg">Breaker blocks</h3>
      {breakers.length ? <ul className="space-y-1">{breakers.map((z) => <li key={z.t + z.kind} className="font-mono text-xs"><span className={z.kind.startsWith("Bull") ? "text-bull" : "text-bear"}>{z.kind}</span> {f(z.bottom)}–{f(z.top)} · {z.status}{simple ? ` · may act as ${z.kind.startsWith("Bull") ? "support" : "resistance"}` : ""}</li>)}</ul> : <p className="text-muted-foreground">No active breaker block — no order block has failed recently.</p>}
    </div>
  </div>;
}
