import { Button } from "@/components/ui/button";
import { marketOf, symbolsFor, symbolLabel, type Market } from "@/lib/engine";

export function MarketPicker({ symbol, onChange }: { symbol: string; onChange: (symbol: string) => void }) {
  const market = marketOf(symbol);
  return <div className="flex flex-wrap items-center gap-3">
    <div className="flex gap-1" aria-label="Market selection">
      {(["nse", "forex"] as Market[]).map((m) => <Button key={m} size="sm" variant={market === m ? "default" : "outline"} aria-pressed={market === m} onClick={() => onChange(m === "forex" ? "XAUUSD" : "RELIANCE")}>{m === "nse" ? "NSE Stocks" : "Forex & Gold"}</Button>)}
    </div>
    <label className="flex min-w-0 items-center gap-2 text-sm text-muted-foreground">{market === "nse" ? "Stock" : "Pair"}
      <select aria-label="Choose instrument" className="field min-w-0 font-mono" value={symbol} onChange={(e) => onChange(e.target.value)}>{symbolsFor(market).map((s) => <option key={s} value={s}>{symbolLabel(s)}</option>)}</select>
    </label>
  </div>;
}