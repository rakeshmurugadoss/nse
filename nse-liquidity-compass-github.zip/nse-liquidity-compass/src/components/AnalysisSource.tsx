import { Button } from "@/components/ui/button";
import { marketOf, fmtTime } from "@/lib/engine";
import { RefreshCw } from "lucide-react";

export function AnalysisSource({ symbol, source, onSource, onRefresh, busy, error, warning, fetchedAt }: { symbol: string; source: "demo" | "live"; onSource: (source: "demo" | "live") => void; onRefresh: () => void; busy: boolean; error: string; warning: string; fetchedAt?: number | undefined }) {
  return <div className="mb-4 space-y-2 border-y py-3">
    <div className="flex flex-wrap items-center gap-2" aria-label="Candle analysis source">
      <Button size="sm" variant={source === "demo" ? "default" : "outline"} onClick={() => onSource("demo")}>Demo analysis</Button>
      <Button size="sm" disabled={marketOf(symbol) !== "forex"} variant={source === "live" ? "default" : "outline"} onClick={() => onSource("live")}>Live analysis</Button>
      {source === "live" && <Button size="sm" variant="outline" disabled={busy} onClick={onRefresh}><RefreshCw className={busy ? "animate-spin" : ""} />{busy ? "Fetching candles…" : fetchedAt ? "Refresh live analysis" : "Analyze live candles"}</Button>}
    </div>
    <p className="text-xs text-warn">{source === "demo" ? "DEMO candles · Not live market analysis" : "Twelve Data candles · Manual refresh · TradingView is a separate feed · Volume may be unavailable"}</p>
    {marketOf(symbol) !== "forex" && <p className="text-xs text-muted-foreground">NSE live analysis needs a separate authorised market-data connection.</p>}
    {fetchedAt && source === "live" && <p className="font-mono text-xs text-muted-foreground">Fetched {fmtTime(fetchedAt)} IST</p>}
    {error && <p role="alert" className="text-sm text-bear">{error}</p>}
    {warning && <p role="status" className="text-xs text-warn">{warning}</p>}
  </div>;
}