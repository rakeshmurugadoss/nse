import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { CandlestickChart, ImagePlus, LoaderCircle, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Decision } from "./Shell";
import { readScreenshot } from "@/lib/screenshot.functions";
import { SCREENSHOT_TOPICS, validateScreenshot, type ScreenshotResult } from "@/lib/screenshot";
import { screenshotLiveSymbol } from "@/lib/screenshot-live";

const REPORT_LABELS = {
  en: { title: "Detailed screenshot analysis", structure: "Trend & market structure", liquidity: "Liquidity & sweeps", smc: "SMC & ICT zones", levels: "Support & resistance", volume: "Volume & Volume Profile", context: "Timeframe, indicators & context", visible: "Visible", partial: "Partly visible", not_visible: "Not visible", areas: "Key areas on your chart", scenarios: "Conditional scenarios", bullish: "Bullish case", bearish: "Bearish case", wait: "Wait / invalidation", bull: "Upward bias", bear: "Downward bias", range: "Range / sideways", unclear: "Unclear bias", unpriced: "Price not legible", followup: "Separate current-market analysis" },
  ta: { title: "விரிவான படப் பகுப்பாய்வு", structure: "போக்கு & சந்தை அமைப்பு", liquidity: "திரவத்தன்மை & ஸ்வீப்", smc: "SMC & ICT பகுதிகள்", levels: "ஆதரவு & எதிர்ப்பு", volume: "அளவு & Volume Profile", context: "கால அளவு, குறிகாட்டிகள் & சூழல்", visible: "தெரிகிறது", partial: "பகுதியாகத் தெரிகிறது", not_visible: "தெரியவில்லை", areas: "படத்தின் முக்கிய பகுதிகள்", scenarios: "நிபந்தனைச் சூழல்கள்", bullish: "மேல்நோக்கிச் சூழல்", bearish: "கீழ்நோக்கிச் சூழல்", wait: "காத்திருப்பு / செல்லாத நிலை", bull: "மேல்நோக்குச் சார்பு", bear: "கீழ்நோக்குச் சார்பு", range: "பக்கவாட்டுச் சார்பு", unclear: "தெளிவற்ற சார்பு", unpriced: "விலை தெளிவாக இல்லை", followup: "தனியான தற்போதைய சந்தைப் பகுப்பாய்வு" },
};

const PLAN_LABEL = { entry: "Entry", stop: "Stop loss", target1: "Target 1", target2: "Target 2" } as const;

const KIND_LABEL = { bull_fvg: "Bull FVG", bear_fvg: "Bear FVG", bull_ob: "Bull OB", bear_ob: "Bear OB", support: "Support", resistance: "Resistance", liquidity: "Liquidity", bos: "BOS", choch: "CHoCH" } as const;

const MARK = {
  bull_fvg: { svg: "fill-fvg-bull stroke-fvg-bull", bg: "bg-fvg-bull" },
  bear_fvg: { svg: "fill-fvg-bear stroke-fvg-bear", bg: "bg-fvg-bear" },
  bull_ob: { svg: "fill-ob-bull stroke-ob-bull", bg: "bg-ob-bull" },
  bear_ob: { svg: "fill-ob-bear stroke-ob-bear", bg: "bg-ob-bear" },
  support: { svg: "fill-bull stroke-bull", bg: "bg-bull" },
  resistance: { svg: "fill-bear stroke-bear", bg: "bg-bear" },
  liquidity: { svg: "fill-warn stroke-warn", bg: "bg-warn" },
  bos: { svg: "fill-primary stroke-primary", bg: "bg-primary" },
  choch: { svg: "fill-primary stroke-primary", bg: "bg-primary" },
};

export function ScreenshotAnalysis({ onAnalyzeLive, liveBusy = false }: { onAnalyzeLive?: (symbol: string) => void; liveBusy?: boolean }) {
  const [file, setFile] = useState<File | null>(null);
  const [url, setUrl] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<ScreenshotResult | null>(null);
  const [lang, setLang] = useState<"en" | "ta">("en");
  const input = useRef<HTMLInputElement>(null);
  const feedback = useRef<HTMLDivElement>(null);
  const read = useServerFn(readScreenshot);
  const liveSymbol = result?.isChart && result.readable ? screenshotLiveSymbol(result.symbol) : null;
  const labels = REPORT_LABELS[lang];
  useEffect(() => {
    if (!file) { setUrl(""); return; }
    const next = URL.createObjectURL(file); setUrl(next);
    return () => URL.revokeObjectURL(next);
  }, [file]);
  useEffect(() => {
    if (!result && !error) return;
    const target = feedback.current;
    if (!target || target.getClientRects().length === 0) return;
    target.focus({ preventScroll: true });
    target.scrollIntoView({ block: "start", behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });
  }, [result, error]);
  function choose(next?: File) {
    setError(""); setResult(null); setFile(null);
    if (!next) return;
    const invalid = validateScreenshot(next);
    if (invalid) { setError(invalid); return; }
    setFile(next);
  }
  async function analyzeImage() {
    if (!file || busy) return;
    setBusy(true); setError(""); setResult(null);
    try {
      const image = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => typeof reader.result === "string" ? resolve(reader.result) : reject(new Error("Unable to open this picture."));
        reader.onerror = () => reject(new Error("Unable to open this picture."));
        reader.readAsDataURL(file);
      });
      const response = await read({ data: { image, language: lang } });
      if (response.error) setError(response.error);
      else if (response.result) setResult(response.result);
    } catch { setError("Screenshot reading failed. Please try again later."); }
    finally { setBusy(false); }
  }
  return <div className="space-y-5">
    <div className="flex flex-wrap items-center justify-between gap-3"><h2 className="text-3xl">Your chart, <em>your view.</em></h2>
      <div className="flex gap-1" aria-label="Screenshot result language">{(["en", "ta"] as const).map((l) => <Button key={l} disabled={busy} variant={lang === l ? "default" : "ghost"} size="sm" aria-pressed={lang === l} onClick={() => { setLang(l); setResult(null); }}>{l === "en" ? "English" : "தமிழ்"}</Button>)}</div>
    </div>
    <input ref={input} aria-label="Upload chart screenshot" type="file" accept="image/png,image/jpeg,image/webp" className="sr-only" disabled={busy} onChange={(e) => choose(e.target.files?.[0])} />
    {!file ? <Button variant="outline" disabled={busy} className="h-48 w-full flex-col gap-3 border-dashed bg-card/40" onClick={() => input.current?.click()}><ImagePlus className="size-8 text-primary" /><span className="font-display text-2xl">Upload screenshot</span><span className="text-xs text-muted-foreground">PNG, JPG or WEBP · up to 8 MB</span></Button>
      : <div className="space-y-3"><img src={url} alt="Uploaded chart screenshot" className="max-h-96 w-full rounded-md border object-contain" /><div className="flex items-center justify-between gap-3"><p className="min-w-0 break-all text-sm text-muted-foreground">{file.name}</p><Button variant="ghost" size="icon" title="Remove screenshot" aria-label="Remove screenshot" disabled={busy} onClick={() => { choose(); if (input.current) input.current.value = ""; }}><Trash2 /></Button></div></div>}
    <p className="text-xs text-muted-foreground">Screenshot-only reading · Not live market data · Pictures are sent to AI for analysis.</p>
    <Button className="h-12 w-full" disabled={!file || busy} onClick={analyzeImage}>{busy ? <><LoaderCircle className="animate-spin motion-reduce:animate-none" />Reading screenshot…</> : "Analyse screenshot"}</Button>
     <div ref={feedback} tabIndex={-1} aria-live="polite" className="scroll-mt-44 focus:outline-none">
     {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
    {result && <section aria-label="Screenshot analysis result" className="space-y-4 border-t pt-6">
      <h2 className="text-3xl">{labels.title}</h2>
      <div className="flex flex-wrap items-center gap-3"><Decision d="WAIT" /><span className="text-xs text-warn">{result.isChart && result.readable ? "Screenshot only · Unverified" : "No readable chart"}</span><span className="text-sm font-medium">{labels[result.trend]}</span></div>
      <div className="grid grid-cols-2 gap-3"><div><div className="label">Instrument</div><p className="break-words font-mono text-sm">{result.symbol ?? "Not visible"}</p></div><div><div className="label">Timeframe</div><p className="break-words font-mono text-sm">{result.timeframe ?? "Not visible"}</p></div></div>
            {url && (result.annotations.length > 0 || result.plan.available) && <figure className="space-y-2"><div className="relative overflow-hidden rounded-md border">
        <img src={url} alt="Your screenshot with AI-marked zones" className="block h-auto w-full" />
        <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden>
          {result.annotations.map((a, i) => <rect key={i} x={a.x * 100} y={a.y * 100} width={Math.max(a.w * 100, 0.6)} height={Math.max(a.h * 100, 0.4)} className={MARK[a.kind].svg} fillOpacity={0.22} vectorEffect="non-scaling-stroke" strokeWidth={2} strokeDasharray={a.kind === "bos" || a.kind === "choch" ? "4 3" : undefined} />)}
        </svg>
        {result.plan.available && (["entry", "stop", "target1", "target2"] as const).map((k) => { const l = result.plan[k]; if (l.y === null) return null; const c = k === "entry" ? "bg-primary" : k === "stop" ? "bg-bear" : "bg-bull"; return <div key={k} className="absolute inset-x-0" style={{ top: `${l.y * 100}%` }}><div className={`h-0.5 w-full opacity-90 ${c}`} /><span className={`absolute right-0 -translate-y-full rounded-sm px-1 font-mono text-[10px] font-semibold leading-4 text-background ${c}`}>{PLAN_LABEL[k]}{l.price ? ` ${l.price}` : ""}</span></div>; })}
        {result.annotations.map((a, i) => <span key={i} className={`absolute -translate-y-full whitespace-nowrap rounded-sm px-1 font-mono text-[10px] leading-4 text-background ${MARK[a.kind].bg}`} style={{ left: `${Math.min(a.x * 100, 85)}%`, top: `${Math.max(a.y * 100, 4)}%` }}>{a.label}</span>)}
        <div className="absolute left-1 top-1 rounded-md border border-primary/60 bg-background/85 p-1.5 font-mono text-[10px] leading-4 shadow backdrop-blur-sm">
          <div className={`font-semibold ${result.plan.direction === "long" ? "text-bull" : result.plan.direction === "short" ? "text-bear" : "text-warn"}`}>{result.plan.available ? (result.plan.direction === "long" ? "▲ BUY idea" : "▼ SELL idea") : "◆ WAIT · no setup"}</div>
          {result.plan.available && (["entry", "stop", "target1", "target2"] as const).map((k) => <div key={k} className="flex justify-between gap-2"><span className={k === "entry" ? "text-primary" : k === "stop" ? "text-bear" : "text-bull"}>{k === "entry" ? "Entry" : k === "stop" ? "SL" : k === "target1" ? "T1" : "T2"}</span><span>{result.plan[k].price ?? "—"}</span></div>)}
          <div className="text-muted-foreground">Judge: {result.judge.lean === "bull" ? "Bull" : result.judge.lean === "bear" ? "Bear" : "Neutral"} · {result.judge.strength}</div>
        </div>
      </div>
      <div className="flex flex-wrap gap-x-3 gap-y-1 text-[11px]">{[...new Set(result.annotations.map((a) => a.kind))].map((k) => <span key={k} className="flex items-center gap-1"><span className={`size-2.5 rounded-sm ${MARK[k].bg}`} />{KIND_LABEL[k]}</span>)}</div>
      <figcaption className="text-xs text-warn">AI-marked zones · approximate visual positions · unverified</figcaption></figure>}
      <section className="space-y-3 rounded-md border border-primary/50 bg-card/40 p-4" aria-label="Educational trade idea">
        <div className="flex flex-wrap items-center justify-between gap-2"><h3 className="text-2xl">Trade idea <span className="text-sm text-warn">(educational)</span></h3><span className={`font-mono text-sm font-semibold ${result.plan.direction === "long" ? "text-bull" : result.plan.direction === "short" ? "text-bear" : "text-warn"}`}>{result.plan.available ? (result.plan.direction === "long" ? "BUY idea" : "SELL idea") : "No clear setup"}</span></div>
        {result.plan.available && <div className="grid grid-cols-2 gap-2">{(["entry", "stop", "target1", "target2"] as const).map((k) => <div key={k} className={`rounded-md border p-2 ${k === "entry" ? "border-primary" : k === "stop" ? "border-bear" : "border-bull"}`}><div className="label">{PLAN_LABEL[k]}</div><p className="font-mono text-base">{result.plan[k].price ?? "Not legible"}</p><p className="text-xs text-muted-foreground">{result.plan[k].note}</p></div>)}</div>}
        <p className="text-xs text-warn">≈ = estimated from the chart's price scale · picture-only · educational, not advice.</p>
      </section>
      <details className="rounded-md border bg-card/40 p-3"><summary className="cursor-pointer text-sm font-semibold text-primary">Show full written details</summary><div className="mt-4 space-y-4">
      <p className="text-base">{result.summary}</p>
      <p className="text-sm">{result.plan.rationale}</p>
      <section className="space-y-3 rounded-md border bg-card/40 p-4" aria-label="Screenshot judge">
        <div className="flex flex-wrap items-center justify-between gap-2"><h3 className="text-2xl">AI Judge</h3><span className={`font-mono text-sm font-semibold ${result.judge.lean === "bull" ? "text-bull" : result.judge.lean === "bear" ? "text-bear" : "text-warn"}`}>{result.judge.lean === "bull" ? "Bullish lean" : result.judge.lean === "bear" ? "Bearish lean" : "Neutral"} · {result.judge.strength}</span></div>
        <div className="flex h-2 overflow-hidden rounded-full bg-muted"><div className="bg-bull" style={{ flex: result.judge.bullPoints.length || 0.001 }} /><div className="bg-bear" style={{ flex: result.judge.bearPoints.length || 0.001 }} /></div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div><div className="label text-bull">Bull points ({result.judge.bullPoints.length})</div><ul className="mt-1 space-y-1 text-sm">{result.judge.bullPoints.map((x, i) => <li key={i}>+ {x}</li>)}</ul></div>
          <div><div className="label text-bear">Bear points ({result.judge.bearPoints.length})</div><ul className="mt-1 space-y-1 text-sm">{result.judge.bearPoints.map((x, i) => <li key={i}>− {x}</li>)}</ul></div>
        </div>
        <p className="text-sm">{result.judge.verdict}</p>
      </section>
      {result.observations.length > 0 && <div><h3 className="mb-2 text-2xl">Visible observations</h3><ul className="space-y-2 text-sm text-muted-foreground">{result.observations.map((x, i) => <li key={i}>• {x}</li>)}</ul></div>}
      <div className="divide-y">{SCREENSHOT_TOPICS.map((topic) => {
        const section = result.sections[topic];
        return <section key={topic} className="space-y-3 py-5" aria-label={labels[topic]}>
          <div className="flex flex-wrap items-baseline justify-between gap-2"><h3 className="text-2xl">{labels[topic]}</h3><span className={`text-xs ${section.visibility === "not_visible" ? "text-muted-foreground" : "text-warn"}`}>{labels[section.visibility]}</span></div>
          <p className="break-words text-sm leading-relaxed">{section.reading}</p>
          {section.evidence.length > 0 && <ul className="space-y-2 text-sm leading-relaxed text-muted-foreground">{section.evidence.map((item, i) => <li key={i} className="break-words">• {item}</li>)}</ul>}
        </section>;
      })}</div>
      {result.keyLevels.length > 0 && <section className="space-y-3 border-t pt-5"><h3 className="text-2xl">{labels.areas}</h3><ul className="divide-y">{result.keyLevels.map((level, i) => <li key={i} className="space-y-2 py-3"><div className="flex flex-wrap items-center gap-3"><span className="label">{level.kind}</span><span className="break-words font-mono text-sm text-primary">{level.priceLabel ?? labels.unpriced}</span></div><p className="break-words text-sm">{level.location}</p><p className="break-words text-sm text-muted-foreground">{level.significance}</p></li>)}</ul></section>}
      <section className="space-y-4 border-t pt-5"><h3 className="text-2xl">{labels.scenarios}</h3>{(["bullish", "bearish", "wait"] as const).map((scenario) => <div key={scenario} className={`border-l-2 pl-4 ${scenario === "bullish" ? "border-bull" : scenario === "bearish" ? "border-bear" : "border-warn"}`}><h4 className="font-body text-sm font-semibold">{labels[scenario]}</h4><p className="mt-2 break-words text-sm leading-relaxed text-muted-foreground">{result.scenarios[scenario]}</p></div>)}</section>
      <div className="border-l-2 border-warn pl-4"><h3 className="mb-2 text-2xl">Before any trade</h3><ul className="space-y-2 text-sm text-muted-foreground">{result.limitations.map((x, i) => <li key={i}>• {x}</li>)}</ul><p className="mt-3 text-xs text-warn">The trade idea is read from a picture only; full candle data is needed to verify it.</p></div>
      </div></details>
      {onAnalyzeLive && liveSymbol && <div className="space-y-3 border-t pt-5"><h3 className="text-2xl">{labels.followup}</h3><Button className="min-h-12 w-full whitespace-normal" disabled={liveBusy} onClick={() => onAnalyzeLive(liveSymbol)}><CandlestickChart />Analyze {liveSymbol} with live candles</Button><p className="text-xs text-muted-foreground">Latest Twelve Data candles · Not the picture’s historical moment or TradingView feed · Check that {liveSymbol} is the intended pair.</p></div>}
    </section>}
     </div>
  </div>;
}