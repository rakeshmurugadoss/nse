<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->
- Analysis engine lives in src/lib/engine.ts as pure deterministic TS shared by every mode; UI never computes zones itself so Beginner and Pro always agree.
- noUncheckedIndexedAccess is off: the engine does heavy candle-array indexing.
- Screenshot AI reads only visible observations and may give an educational entry/stop/target idea priced only from the visible axis (≈ when estimated, null when illegible); never synthesize OHLC or claim engine verification, and keep it separate from candle-engine reports.
- Screenshot reports require six evidence/visibility sections, nullable legible-price labels and separate conditional scenarios through one validated schema shared by both modes, so a summary-only response cannot masquerade as detailed analysis.
- Screenshot inference uses a same-origin server function and the Lovable AI Gateway SDK; images are transient, not persisted, to avoid retaining uploaded chart content.
- Screenshot replies accept an omitted optional gateway status only with validated JSON and no failure, refusal or incomplete markers, to avoid discarding successful synchronous output.
- Screenshot-to-live handoff whitelist-matches the visible ticker and passes an explicit symbol and peer into the shared live hook, so a React state transition cannot fetch the previously selected instrument.
- Instrument metadata, market sessions, and candle-estimated volume profiles stay in the shared engine so all modes agree; Forex position sizing and paper execution remain unavailable until contract and currency conversion data exist.
- Correlated-pair SMT uses shared-engine closed, exactly aligned bars and measured pre-event return correlation; keep it separate from judge scores and never combine supplied candles with a demo peer, to avoid false entry confirmation.
- Chart viewing uses react-zoom-pan-pinch; export original selected-layer SVG to a prepared PNG before saving, so touch gestures stay reliable and downloads retain all annotations rather than a zoomed crop.
- Chart zone colours and callouts distinguish existing engine FVG/OB types; support/resistance labels reference untouched engine liquidity, and breaker blocks, OTE and ICT killzones come only from shared-engine detection, never UI-side relabelling.
- Live TradingView is view-only; Twelve Data analysis uses a separate server-fetched candle snapshot, with source labels across reports, charts and downloads to prevent feed confusion.
- Shared candle charts render the engine trade plan in a reserved SVG header, including exports, and open the marked view when live results arrive; never cover candles or invent a plan for WAIT.
- Live candles are validated, closed and fully aggregated before the shared engine; missing volume earns no volume evidence, and unavailable peer candles never use demo data.
- Advanced research uses strict one-minute CSV inputs and explicit as-of complete NSE-session aggregation through the shared engine; historical outputs never fall back to demo candles.
- Private prediction server functions compute reports before storing immutable snapshots and outcomes under owner-scoped policies; public research access must never expose saved user history.
- Python research services consume versioned TypeScript detections and causal features, rather than maintain competing zone logic; deployment and durable workers are external and unavailable actions fail closed.
- Advanced structure candidate definitions are deterministic shared-engine outputs with explicit availability times; Python task labels use fixed as-of thresholds and purged chronology, and never grant model influence without calibrated baseline and cost validation.
- Uploaded order-block protection rules are additive shared-engine evidence built from existing confirmed events; Python validates saved evidence instead of redetecting zones, preserving current plans and a single source of truth.
- Zerodha Kite login uses an HMAC-signed short-lived state and stores the daily access token AES-encrypted in a service-role-only table, because in-app/mobile browsers drop cookies between login and callback and preview/published hosts do not share cookies.
- Research stock search uses Kite's current EQ instrument directory and exchange-specific tokens; BSE symbols retain an exchange prefix in requests and saved reports to prevent cross-exchange candle confusion, while both exchanges share the regular Indian-equity session engine.
- Python candle intelligence is a separate versioned, read-only enrichment of existing minute OHLCV; it never replaces TS zones or plans. Session-complete independent frames and decision-time structural states prevent look-ahead, and Python remains externally hosted rather than bundled into the Worker.
