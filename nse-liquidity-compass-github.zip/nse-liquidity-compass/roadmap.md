# Advanced candle intelligence
- [x] Inspect existing Python/Kite architecture and explain additive integration.
- [x] Add typed causal candle analysis, classifications, evidence and configurable scores.
- [x] Add authenticated FastAPI analysis using existing OHLCV, documentation and chronological tests.
- [x] Verify 57 core Python tests, 2 stored API tests, 25 existing TS regressions, and local endpoint with 297 real Kite candles; preserve current app.
- [ ] Deploy and verify hosted owner/store candle endpoints — blocked: Python hosting/service URL and hosted account/store access are unavailable; no website integration claimed.

# Uploaded order-block protection package
- [x] Integrate the uploaded protection rules as additive shared-engine evidence and an authenticated Python evidence endpoint without replacing existing analysis.
- [x] Test causal timing, quality filters and every lifecycle state; 77 TS and 18 Python regressions pass, compilation is clean, and desktop/mobile test-only CSV flow succeeds.
- [ ] Verify the deployed protection endpoint against an actual private saved prediction — blocked: separate Python hosting and a signed-in app account are unavailable; local endpoint ownership tests use controlled stores.

# Screenshot analysis
- [x] Add detailed image-specific structure, liquidity, SMC/ICT, levels, volume and conditional scenarios in both modes; verify real screenshot results.
- [x] Add detected-pair handoff to full live analysis in both modes and verify real candles.
- [x] Diagnose and repair screenshot analysis failure; verify real image results in both modes.
- [x] Separate Choose Stock and Screenshot on the Beginner page.
- [x] Connect screenshot reading with conservative, image-only results.
- [x] Verify upload validation, stock analysis, and screenshot analysis.

# Forex & Gold analysis
- [x] Extend the shared engine with Forex pairs, precision, sessions and estimated Volume Profile.
- [x] Add market selection and simple/intermediate volume results without mixing screenshot inference.
- [x] Test market rules and verify the analysis on desktop and mobile.

# Correlated-pair divergence
- [x] Add shared, timestamp-aligned SMT divergence with measured correlation and conservative confirmation checks.
- [x] Add comparison-pair and timeframe options to Beginner and Pro analysis.
- [x] Test bullish/bearish, inverse, missing-data and weak-correlation rules; verify desktop and mobile flows.

# Chart viewing and downloads
- [x] Add zoom, pinch, pan and expanded chart viewing with shared layer selections.
- [x] Add high-resolution annotated image export with demo identification.
- [x] Verify desktop/mobile controls and downloaded image; explain TradingView live-data limitations.

# Chart zone clarity
- [x] Distinguish and label FVG/order blocks, with price/status details and support/resistance candidates.
- [x] Verify Gold chart, phone view and annotated download; clarify breaker-block availability without inventing zones.

# Live candle analysis
- [x] Add an in-chart trade idea box and open the marked chart after live analysis in both modes; verify phone and desktop.
- [x] Connect Twelve Data and validate closed candles without fabricated volume.
- [x] Add live analysis in both modes, keeping TradingView and demo data separate.
- [x] Test safeguards and verify real candle analysis on desktop and mobile.

# Advanced hybrid predictions
- [x] Read the upgrade brief and inspect existing app, services and public database schema.
- [x] Review and approve the incremental upgrade plan.
- [x] Add Advanced AI Predictions with validated CSV research, annotated charts and honest NSE/model status; private saving uses authenticated functions.
- [x] Add initial causal timing, complete session aggregation, regime/statistics, timeframe agreement and invalid-setup WAIT vetoes.
- [x] Apply nine owner-isolated research tables for snapshots, model records, outcomes, backtests and paper transfers.
- [x] Add separate authenticated Python evidence service, purged logistic baseline helpers, safety tests and setup instructions.
- [x] Add appended-candle outcomes, pending/ambiguous safeguards and private directional breakdowns; extend paper cost/target fields without deleting local trades.
- [x] Verify public desktop/mobile CSV analysis and sign-in navigation; run TS/Python regressions.
- [ ] Verify private save → history → appended outcome and cross-user isolation — blocked: no app auth users; an actual sign-in is required.
- [ ] Deploy Python service and durable training/replay workers — blocked: external Python-compatible hosting/service URL is not available.
- [ ] Connect NSE provider and automated outcomes — blocked: NSE-compatible provider and real historical dataset are not available.
- [x] Add timestamped advanced MSS/internal-external, inverse-FVG and inducement/mitigation candidates; show selected marks and evidence on research charts.
- [x] Add eight task label helpers, chronological calibration/boosted baseline and cost-based override gate; no unvalidated ML influence.
- [x] Add opt-in paper journal copying and dated estimated cost controls; keep MAE/MFE unavailable without real trade paths.
- [ ] Validate deployed models, calibrated/cost performance and automated trade-path excursions — blocked: real labelled dataset, Python hosting and genuine execution/path data are unavailable.
# Zerodha Kite data
- [x] Add searchable NSE/BSE directory and exchange-specific candles; real ASIANPAINT load → CSV download → analysis succeeded on both exchanges, phone/desktop search checked, 92 tests passed.
- [x] Load NSE 1-minute candles from Kite on the Predictions page instead of CSV; worker package stored for later hosting.
- [x] Verify real Kite candle loading and CSV downloads using the connected account.
