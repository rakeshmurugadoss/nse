CREATE TABLE public.kite_sessions (id text PRIMARY KEY, token_ciphertext text NOT NULL, expires_at timestamptz NOT NULL, updated_at timestamptz NOT NULL DEFAULT now());
GRANT ALL ON public.kite_sessions TO service_role;
ALTER TABLE public.kite_sessions ENABLE ROW LEVEL SECURITY;