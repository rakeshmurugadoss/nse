from copy import deepcopy
from fastapi.testclient import TestClient
from main import app
from auth import require_user

ID = "00000000-0000-0000-0000-000000000001"
def evidence():
    return {"asOf": 300, "protection": {"engineVersion": "shared-ob-protection-1", "snapshotAt": 300, "orderBlocks": [{"id": "test", "direction": "bull", "top": 101, "bottom": 99, "formedAt": 100, "confirmedAt": 200, "availableAt": 200, "statusAt": 300, "qualityPassed": True, "qualityScore": 75, "lifecycle": "fresh", "mitigationFraction": 0, "firstTouchAt": None, "invalidatedAt": None, "expiredAt": None}], "protectedActiveOrderBlocks": []}}

class Store:
    def __init__(self, output, visible=True): self.output, self.visible, self.queries = output, visible, []
    async def rows(self, table, query):
        self.queries.append((table, query))
        return [{"output": self.output}] if self.visible else []

def request(output, visible=True):
    store = Store(output, visible)
    app.dependency_overrides[require_user] = lambda: store
    try:
        response = TestClient(app).post("/api/v1/structure/order-block-protection", json={"prediction_id": ID})
        return response, store
    finally: app.dependency_overrides.clear()

def test_endpoint_requires_auth():
    assert TestClient(app).post("/api/v1/structure/order-block-protection", json={"prediction_id": ID}).status_code == 401

def test_returns_owned_saved_evidence_and_derives_active_list():
    response, store = request(evidence())
    assert response.status_code == 200
    assert len(response.json()["protectedActiveOrderBlocks"]) == 1
    assert store.queries == [("predictions", f"id=eq.{ID}&select=*")]

def test_foreign_or_missing_prediction_cannot_be_read():
    response, _ = request(evidence(), False)
    assert response.status_code == 404

def test_legacy_snapshot_requires_new_analysis():
    assert request({"asOf": 300})[0].status_code == 409

def test_future_status_and_transition_rejected():
    output = evidence(); output["protection"]["orderBlocks"][0]["statusAt"] = 400
    assert request(output)[0].status_code == 422
    output = evidence(); output["protection"]["orderBlocks"][0]["firstTouchAt"] = 400
    assert request(output)[0].status_code == 422

def test_terminal_blocks_not_active_even_if_supplied_active():
    output = evidence(); b = output["protection"]["orderBlocks"][0]
    b["lifecycle"], b["invalidatedAt"] = "invalidated", 250
    output["protection"]["protectedActiveOrderBlocks"] = [deepcopy(b)]
    assert request(output)[0].json()["protectedActiveOrderBlocks"] == []

def test_unsupported_version_rejected():
    output = evidence(); output["protection"]["engineVersion"] = "unknown"
    assert request(output)[0].status_code == 422