from ml_labels import label
from ml_training import override_gate
def output():
    return {"asOf": 0, "report": {"price": 100, "plan": None, "tfs": {"1h": {"trend": "bull"}}}, "statistics": {"atr": 2}, "detections": []}
def candles(n=15):
    return [{"t": i*60000, "o":100,"h":102,"l":99,"c":101,"v":100} for i in range(n)]
def test_task_horizons():
    assert label("up_5m", output(), candles(5)) == 1
    assert label("up_15m", output(), candles(5)) is None
    assert label("down_15m", output(), candles()) == 0
def test_missing_setup_and_sweep_have_no_label():
    assert label("target_before_stop", output(), candles()) is None
    assert label("sweep_reversal", output(), candles()) is None
def test_missing_cost_comparison_blocks_override():
    assert not override_gate({"pr_auc": .9}, {}, {})