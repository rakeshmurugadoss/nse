"""Synthetic fixtures test mathematics only; they are never application market data."""
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from copy import deepcopy
import json
import pytest
from pydantic import ValidationError
from fastapi.testclient import TestClient
from main import app
from auth import require_user
from candle_intelligence import CandleInput, Thresholds, StructuralEvidence, analyze_minutes, aggregate_minutes

START = datetime(2026,11,6,9,15,tzinfo=ZoneInfo("Asia/Kolkata"))
ID = "00000000-0000-0000-0000-000000000001"

def bar(i, o=100, h=101, l=99, c=100.5, v=100):
    return CandleInput(timestamp=START+timedelta(minutes=i),open=o,high=h,low=l,close=c,volume=v)

def last(o,h,l,c,v=100,cfg=None):
    candles=[bar(i) for i in range(60)]+[bar(60,o,h,l,c,v)]
    return analyze_minutes(candles,START+timedelta(minutes=61),["1m"],cfg).timeframes["1m"][-1]

@pytest.mark.parametrize("name,values",[
    ("strong_bullish",(99,101,99,101)),("strong_bearish",(101,101,99,99)),
    ("bullish_rejection",(100.7,101,98,100.9)),("bearish_rejection",(99.3,102,99,99.1)),
    ("long_legged_doji",(100,102,98,100)),("dragonfly_doji",(101,101,98,101)),
    ("gravestone_doji",(99,102,99,99)),("spinning_top",(99.6,102,98,100.4)),
    ("marubozu",(99,101,99,101)),("inside_bar",(100,100.8,99.2,100.5)),
    ("outside_bar",(100,102,98,100.5)),("wide_range_bar",(99,103,98,102)),
    ("narrow_range_bar",(100,100.5,99.5,100.2)),
    ("high_volume_expansion",(99,103,98,102,200)),("low_volume_compression",(100,100.5,99.5,100.2,50))])
def test_all_major_patterns(name,values):
    result=last(*values)
    assert name in result.detected_patterns
    assert next(e.rule for e in result.evidence if e.code==name)
    negative = last(100,101,99,101) if name == "spinning_top" else last(100,101,99,100.5)
    assert name not in negative.detected_patterns

def test_anatomy_exact():
    r=last(100,105,98,104)
    assert r.anatomy.absolute_body==4
    assert r.anatomy.range==7
    assert r.anatomy.upper_wick==1
    assert r.anatomy.lower_wick==2
    assert r.anatomy.body_to_range==pytest.approx(4/7)
    assert r.anatomy.close_position==pytest.approx(6/7)
    assert r.anatomy.gap_from_previous==-.5
    assert r.anatomy.relative_body==8

def test_zero_range_and_missing_volume_safe():
    r=last(100,100,100,100,None)
    assert r.anatomy.close_position is None
    assert r.anatomy.body_to_range==0
    assert "marubozu" not in r.detected_patterns
    assert r.volume_metrics.relative_volume is None
    assert r.quality_score.components["volume_confirmation"].score is None
    json.dumps(r.model_dump(mode="json"),allow_nan=False)

@pytest.mark.parametrize("values",[(100,99,98,100),(100,101,99,float("nan")),(100,101,99,100,-1),(100,101,99,100,float("inf"))])
def test_invalid_missing_and_nonfinite_rejected(values):
    with pytest.raises(ValidationError):bar(0,*values)

def test_naive_timestamp_rejected():
    with pytest.raises(ValidationError):CandleInput(timestamp=START.replace(tzinfo=None),open=1,high=1,low=1,close=1)

def test_forming_bars_and_correct_independent_alignment():
    candles=[bar(i) for i in range(61)]
    result=analyze_minutes(candles,START+timedelta(minutes=60,seconds=30))
    assert [len(result.timeframes[k]) for k in ("1m","5m","15m","60m")]==[60,12,4,1]
    assert result.timeframes["60m"][0].timestamp==START
    assert result.timeframes["60m"][0].decision_timestamp==START+timedelta(hours=1)
    assert result.timeframes["5m"][0].volume_metrics.volume==500

def test_session_final_60m_bar_is_15_minutes():
    candles=[bar(i) for i in range(375)]
    frames,_=aggregate_minutes(candles,"60m",START+timedelta(minutes=375))
    assert len(frames)==7
    assert frames[-1][0].timestamp==START+timedelta(minutes=360)
    assert frames[-1][1]==START+timedelta(minutes=375)
    assert frames[-1][0].volume==1500

def test_gaps_duplicates_and_out_of_order():
    rows,warnings=aggregate_minutes([bar(i) for i in (0,1,3,4)],"5m",START+timedelta(minutes=5))
    assert rows==[] and any("incomplete" in w for w in warnings)
    for candles in ([bar(0),bar(0)],[bar(1),bar(0)]):
        with pytest.raises(ValueError):analyze_minutes(candles,START+timedelta(minutes=5))

def test_prefix_invariance_all_timeframes():
    candles=[bar(i,c=100+(i%5)*.1) for i in range(180)]
    a=analyze_minutes(candles[:60],START+timedelta(minutes=60))
    b=analyze_minutes(candles,START+timedelta(minutes=180))
    for tf in a.timeframes:
        assert [r.model_dump() for r in a.timeframes[tf]]==[r.model_dump() for r in b.timeframes[tf][:len(a.timeframes[tf])]]

def test_prior_baselines_do_not_contain_current_bar():
    r=last(100,110,90,109,1000)
    assert r.strength_metrics.atr_normalized_range==10
    assert r.volume_metrics.relative_volume==10
    assert r.anatomy.relative_body==18

def test_displacement_both_directions():
    assert last(99,105,99,105).displacement_type=="bullish"
    assert last(105,105,99,99).displacement_type=="bearish"
    assert last(99,105,99,102).displacement_type is None

def test_sweeps_and_exhaustion_are_only_proxy_evidence():
    r=last(100,105,99,100)
    assert {"potential_liquidity_sweep_high","potential_exhaustion"}.issubset({e.code for e in r.evidence})
    assert "potential_breakout_up" in {e.code for e in last(100,103,100,102.5).evidence}

def test_failed_breakout_only_at_failure_close():
    candles=[bar(i) for i in range(30)]+[bar(30,100,103,100,102.5),bar(31,102.5,103,100,100.5)]
    result=analyze_minutes(candles,START+timedelta(minutes=32),["1m"]).timeframes["1m"]
    assert "failed_breakout" not in {e.code for e in result[-2].evidence}
    assert "failed_breakout" in {e.code for e in result[-1].evidence}

def test_structural_availability_and_no_final_state_backprojection():
    candles=[bar(i) for i in range(60)]
    state=StructuralEvidence(id="ob",kind="OB",timeframe="1m",bottom=99,top=101,available_at=START+timedelta(minutes=20),status_at=START+timedelta(minutes=60))
    result=analyze_minutes(candles,START+timedelta(minutes=60),["1m"],structures=[state]).timeframes["1m"]
    assert all(not r.context.existing_zones for r in result[:-1])
    assert result[-1].context.existing_zones==["ob"]
    future=state.model_copy(update={"available_at":START+timedelta(minutes=61),"status_at":START+timedelta(minutes=61)})
    assert not analyze_minutes(candles,START+timedelta(minutes=60),["1m"],structures=[future]).timeframes["1m"][-1].context.existing_zones

def test_configurable_scores_and_no_signals():
    assert 0<=last(99,101,99,101).quality_score.total<=100
    assert "strong_bullish" not in last(100,101,99,100.5,cfg=Thresholds(strong_body=.9)).detected_patterns
    assert "signal" not in last(99,101,99,101).model_dump()
    with pytest.raises(ValidationError):Thresholds(weights={"body_strength":1})

def test_confirmed_swings_remain_available_only_after_confirmation():
    candles=[bar(i) for i in range(30)]
    confirmation=START+timedelta(minutes=20)
    swing=StructuralEvidence(id="pivot",kind="swing_high",timeframe="1m",bottom=101,top=101,available_at=confirmation,status_at=confirmation)
    result=analyze_minutes(candles,START+timedelta(minutes=30),["1m"],structures=[swing]).timeframes["1m"]
    assert all(r.context.confirmed_swing_high is None for r in result[:19])
    assert all(r.context.confirmed_swing_high==101 for r in result[19:])

def test_empty_input_and_missing_ohlc():
    assert analyze_minutes([],START).timeframes["1m"]==[]
    with pytest.raises(ValidationError):CandleInput(timestamp=START,open=100,high=101,low=99)

def test_adapter_reads_actual_ts_tfs_without_mutating_snapshot():
    from candle_intelligence.snapshot import snapshot_inputs
    t=int(START.timestamp()*1000)
    output={"asOf":t+60000,"candles":[{"t":t,"o":100,"h":101,"l":99,"c":100.5,"v":100}],
        "report":{"tfs":{"1m":{"tf":"1m","zones":[{"kind":"Bull OB","bottom":99,"top":101,"availableAt":t+60000,"statusAt":t+60000,"status":"Untouched"}]}}}}
    original=deepcopy(output)
    candles,as_of,structures=snapshot_inputs(output)
    assert len(structures)==1 and structures[0].kind=="OB"
    assert output==original
    assert analyze_minutes(candles,as_of,["1m"],structures=structures).timeframes["1m"][0].context.existing_zones==["1m:zone:0"]

def test_strict_inside_outside_equality_boundaries():
    r=last(100,101,99,100)
    assert "inside_bar" not in r.detected_patterns and "outside_bar" not in r.detected_patterns

def test_sequences_windows_and_indicator_warmup():
    result=analyze_minutes([bar(i) for i in range(60)],START+timedelta(minutes=60),["1m"]).timeframes["1m"]
    assert result[-1].strength_metrics.bullish_sequence==60
    assert result[7].context.ema9 is None
    assert result[8].context.ema9==100.5
    assert result[12].context.atr is None
    assert result[13].context.atr==2
    assert result[-1].context.rsi==50
    assert result[9].context.previous_windows["10"]["high"] is None
    assert result[10].context.previous_windows["10"]["high"]==101

def test_vwap_missing_volume_no_credit_and_day_reset():
    candles=[bar(0,v=None),bar(1)]+[bar(0).model_copy(update={"timestamp":START+timedelta(days=3)})]
    r=analyze_minutes(candles,START+timedelta(days=3,minutes=1),["1m"]).timeframes["1m"]
    assert r[0].context.vwap is None and r[1].context.vwap is None
    assert r[2].context.vwap==pytest.approx((101+99+100.5)/3)

class Store:
    def __init__(self,visible=True):self.visible=visible
    async def rows(self,table,query):
        assert table=="predictions" and f"id=eq.{ID}" in query
        return [{"output":{"candles":[{"t":int(bar(i).timestamp.timestamp()*1000),"o":100,"h":101,"l":99,"c":100.5,"v":100} for i in range(60)],"asOf":int((START+timedelta(minutes=60)).timestamp()*1000)}}] if self.visible else []

def test_endpoint_auth_ownership_and_readback():
    client=TestClient(app)
    assert client.post("/api/v1/candles/intelligence",json={"prediction_id":ID}).status_code==401
    app.dependency_overrides[require_user]=lambda:Store()
    try:
        response=client.post("/api/v1/candles/intelligence",json={"prediction_id":ID})
        assert response.status_code==200
        assert len(response.json()["timeframes"]["1m"])==60
        assert response.json()["schema_version"]=="candle-intelligence-1"
        app.dependency_overrides[require_user]=lambda:Store(False)
        assert client.post("/api/v1/candles/intelligence",json={"prediction_id":ID}).status_code==404
    finally:app.dependency_overrides.clear()