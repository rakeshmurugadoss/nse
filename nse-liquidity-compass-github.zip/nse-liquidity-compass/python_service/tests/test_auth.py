from fastapi.testclient import TestClient
from main import app
def test_all_research_endpoints_require_authentication():
    client = TestClient(app)
    for path in ("/api/v1/predictions/history", "/api/v1/models/status", "/api/v1/models/performance", "/api/v1/backtest/results", "/api/v1/predictions/00000000-0000-0000-0000-000000000000"):
        assert client.get(path).status_code == 401
    for path, body in (("/api/v1/predictions/analyze", {"prediction_id":"test"}), ("/api/v1/predictions/multi-timeframe", {"prediction_id":"test"}), ("/api/v1/models/train", {"task":"up_5m"}), ("/api/v1/backtest/run", {"predictions":["test"]})):
        assert client.post(path,json=body).status_code == 401