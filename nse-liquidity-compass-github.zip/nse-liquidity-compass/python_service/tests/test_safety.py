import numpy as np
import pytest
from backtesting import barrier_label, performance
from ml_training import purged_walk_forward, train_baseline
from ml_prediction import allowed_influence
from risk_engine import costs, excursion

def test_unknown_barrier_order_is_ambiguous():
    assert barrier_label([{"h": 103, "l": 97}], 102, 98, "BUY") == "ambiguous"
def test_wait_for_barrier():
    assert barrier_label([{"h": 101, "l": 99}], 102, 98, "BUY") == "neither"
def test_training_requires_real_sample_coverage():
    with pytest.raises(ValueError, match="1000"):
        train_baseline(np.ones((20, 2)), np.zeros(20), list(range(20)), list(range(1, 21)))
def test_purge_removes_overlapping_horizons():
    times = np.arange(2000) * 60000
    for train, test in purged_walk_forward(times, times + 900000):
        assert max(times[train] + 900000) < times[test[0]] - 900000
        assert max(test) < 1600
def test_unvalidated_model_cannot_override():
    assert not allowed_influence({"validated_override": True, "calibrated": False})
def test_transaction_costs_are_deducted():
    assert costs(100, 102, 10) == pytest.approx(41.01)
    assert performance([{"entry": 100, "exit": 102, "quantity": 10, "direction": "BUY"}])["net"] == pytest.approx(-21.01)
def test_missing_path_has_no_excursion():
    assert excursion([], 100, "BUY") == {"mae": None, "mfe": None}