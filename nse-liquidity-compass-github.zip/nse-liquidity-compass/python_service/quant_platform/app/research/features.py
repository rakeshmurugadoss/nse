"""Causal features: each row uses current/past candles only."""
import numpy as np
import pandas as pd

FEATURE_COLUMNS = [
    "ret_1","ret_3","ret_6","range_atr","body_atr","ema_gap",
    "rsi_14","volatility_20","volume_z20","close_vs_vwap_proxy",
    "high_break_20","low_break_20","hour"
]

def build_features(candles: pd.DataFrame) -> pd.DataFrame:
    required = {"timestamp","open","high","low","close","volume"}
    if not required.issubset(candles.columns):
        raise ValueError(f"Missing columns: {sorted(required-set(candles.columns))}")
    d = candles.copy().sort_values("timestamp").drop_duplicates("timestamp")
    for c in ["open","high","low","close","volume"]:
        d[c] = pd.to_numeric(d[c], errors="coerce")
    if (d[["open","high","low","close"]] <= 0).any().any():
        raise ValueError("OHLC prices must be positive")
    prev_close = d.close.shift(1)
    tr = pd.concat([(d.high-d.low), (d.high-prev_close).abs(),
                    (d.low-prev_close).abs()], axis=1).max(axis=1)
    atr = tr.rolling(14, min_periods=14).mean()
    ema9 = d.close.ewm(span=9, adjust=False).mean()
    ema21 = d.close.ewm(span=21, adjust=False).mean()
    delta = d.close.diff()
    gain = delta.clip(lower=0).rolling(14).mean()
    loss = (-delta.clip(upper=0)).rolling(14).mean()
    rs = gain / loss.replace(0, np.nan)
    d["rsi_14"] = 100 - 100/(1+rs)
    d["ret_1"] = d.close.pct_change(1)
    d["ret_3"] = d.close.pct_change(3)
    d["ret_6"] = d.close.pct_change(6)
    d["range_atr"] = (d.high-d.low) / atr.replace(0,np.nan)
    d["body_atr"] = (d.close-d.open).abs() / atr.replace(0,np.nan)
    d["ema_gap"] = (ema9-ema21) / atr.replace(0,np.nan)
    d["volatility_20"] = d.ret_1.rolling(20).std()
    vol_mean = d.volume.rolling(20).mean()
    vol_std = d.volume.rolling(20).std()
    d["volume_z20"] = (d.volume-vol_mean) / vol_std.replace(0,np.nan)
    typical = (d.high+d.low+d.close)/3
    # Rolling VWAP proxy; session VWAP should replace this when session boundaries are known.
    d["close_vs_vwap_proxy"] = (d.close - (typical*d.volume).rolling(20).sum() /
                                d.volume.rolling(20).sum().replace(0,np.nan)) / atr.replace(0,np.nan)
    d["high_break_20"] = d.close / d.high.shift(1).rolling(20).max() - 1
    d["low_break_20"] = d.close / d.low.shift(1).rolling(20).min() - 1
    ts = pd.to_datetime(d.timestamp)
    d["hour"] = ts.dt.hour + ts.dt.minute/60
    return d.replace([np.inf,-np.inf],np.nan)
