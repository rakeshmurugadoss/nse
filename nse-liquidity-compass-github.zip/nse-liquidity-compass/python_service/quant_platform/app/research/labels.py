"""Forward labels are for training only. Never expose them to live decision features."""
import numpy as np
import pandas as pd

def make_forward_return_labels(df, horizon=6, threshold=0.0015):
    """Three-class future-return label: -1/down, 0/neutral, +1/up."""
    future = df["close"].shift(-horizon) / df["close"] - 1
    labels = pd.Series(np.where(future > threshold, 1,
                       np.where(future < -threshold, -1, 0)),
                       index=df.index, dtype="float")
    labels[future.isna()] = np.nan
    return labels
