"""Chronological validation baseline. Not a production-grade alpha claim."""
import os, json
from pathlib import Path
import joblib
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import balanced_accuracy_score
from app.research.features import build_features, FEATURE_COLUMNS
from app.research.labels import make_forward_return_labels

def train(candles, model_path=None, min_rows=None):
    model_path = model_path or os.getenv("MODEL_PATH","models/quant_model.joblib")
    min_rows = int(min_rows or os.getenv("MIN_TRAIN_ROWS","1500"))
    f = build_features(candles)
    y = make_forward_return_labels(candles.reset_index(drop=True))
    dataset = f[FEATURE_COLUMNS].copy()
    valid = dataset.notna().all(axis=1) & y.notna()
    X, y = dataset.loc[valid], y.loc[valid].astype(int)
    if len(X) < min_rows:
        raise ValueError(f"Need at least {min_rows} clean labelled rows; got {len(X)}")
    pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("model", HistGradientBoostingClassifier(
            max_iter=150, learning_rate=0.06, max_leaf_nodes=15,
            l2_regularization=2.0, random_state=42
        ))
    ])
    splits = TimeSeriesSplit(n_splits=5)
    scores = []
    for tr, te in splits.split(X):
        if y.iloc[tr].nunique() < 2:
            continue
        pipe.fit(X.iloc[tr], y.iloc[tr])
        pred = pipe.predict(X.iloc[te])
        scores.append(balanced_accuracy_score(y.iloc[te], pred))
    pipe.fit(X, y)
    Path(model_path).parent.mkdir(parents=True, exist_ok=True)
    joblib.dump({"pipeline":pipe,"features":FEATURE_COLUMNS,
                 "classes":[int(x) for x in pipe.named_steps["model"].classes_]}, model_path)
    report = {
        "rows":int(len(X)), "walk_forward_balanced_accuracy":scores,
        "mean_balanced_accuracy":float(np.mean(scores)) if scores else None,
        "label_horizon_bars":6, "label_threshold":0.0015,
        "warning":"Research baseline only. Include fees/slippage and a final untouched holdout before paper deployment."
    }
    Path(model_path + ".json").write_text(json.dumps(report, indent=2))
    return report
