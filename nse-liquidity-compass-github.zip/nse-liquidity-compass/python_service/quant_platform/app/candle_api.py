"""Additive stored-OHLCV path. Reuses ResearchStore; never changes Kite credentials."""
import logging
from datetime import datetime, timezone
from fastapi import APIRouter, Header, HTTPException, Query
from pydantic import Field
from app.api import guard
from app.data.store import ResearchStore
from candle_intelligence import CandleInput, Thresholds, analyze_minutes
from candle_intelligence.schemas import StrictModel, Timeframe, BatchResult

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/quant", tags=["Candle intelligence"])

class StoredRequest(StrictModel):
    symbol: str = Field(pattern=r"^[A-Z0-9][A-Z0-9&_.-]{0,39}$")
    exchange: str = Field(default="NSE", pattern=r"^(NSE|BSE)$")
    as_of: datetime
    limit: int = Field(default=2000, ge=30, le=10000)
    timeframes: list[Timeframe] = Field(default_factory=lambda:["1m","5m","15m","60m"],min_length=1,max_length=4)
    thresholds: Thresholds = Field(default_factory=Thresholds)

@router.post("/candle-intelligence", response_model=BatchResult)
def stored_intelligence(request: StoredRequest, x_market_data_key: str|None=Header(default=None)):
    guard(x_market_data_key)
    if request.as_of.tzinfo is None or request.as_of > datetime.now(timezone.utc):
        raise HTTPException(422, "as_of must be timezone-aware and no later than now")
    try:
        # Filter before LIMIT, so future database rows cannot evict historical warm-up.
        df = ResearchStore().load_candles_as_of(request.symbol,request.exchange,"minute",request.as_of,request.limit)
    except Exception:
        logger.warning("Stored market candle source unavailable")
        raise HTTPException(503,"Existing candle storage unavailable; no substitute candles were generated")
    if df.empty:
        raise HTTPException(404,"No stored one-minute OHLCV; run the existing Kite history sync first")
    try:
        candles = [CandleInput.model_validate(row) for row in df.to_dict("records")]
        return analyze_minutes(candles,request.as_of,request.timeframes,request.thresholds,source="existing_market_candles")
    except (ValueError,TypeError):
        logger.warning("Invalid stored one-minute OHLCV")
        raise HTTPException(422,"Stored OHLCV is invalid; reconcile with the existing data provider")