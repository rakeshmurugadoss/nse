"""Conservative decision gate: ML is one input, never a standalone trade command."""
import joblib
import pandas as pd
from app.research.features import build_features, FEATURE_COLUMNS

def judge(candles, structure=None, model_path="models/quant_model.joblib",
          min_confidence=0.60):
    structure = structure or {}
    result = {"decision":"WAIT","reasons":[],"model_score":None,
              "confidence_is_probability":False}
    if len(candles) < 100:
        result["reasons"].append("Insufficient candle history")
        return result
    try:
        saved = joblib.load(model_path)
        f = build_features(candles)
        row = f[FEATURE_COLUMNS].tail(1)
        if row.isna().any(axis=1).iloc[0]:
            result["reasons"].append("Latest feature row incomplete")
            return result
        model = saved["pipeline"]
        probs = model.predict_proba(row)[0]
        classes = model.classes_
        best_i = int(probs.argmax())
        cls, score = int(classes[best_i]), float(probs[best_i])
        result["model_score"] = score
        result["model_direction"] = "BULLISH" if cls == 1 else "BEARISH" if cls == -1 else "NEUTRAL"
        result["reasons"].append("Model score is an uncalibrated classifier score, not win probability")
        if score < min_confidence:
            result["reasons"].append("Model score below configured research threshold")
            return result
        bias = str(structure.get("higher_timeframe_bias","UNKNOWN")).upper()
        confirmed = bool(structure.get("lower_timeframe_confirmation",False))
        fresh_ob = bool(structure.get("fresh_order_block",False))
        if not confirmed or not fresh_ob:
            result["reasons"].append("Missing lower-timeframe confirmation or fresh OB")
            return result
        if cls == 1 and bias == "BULLISH":
            result["decision"] = "BUY_CANDIDATE"
        elif cls == -1 and bias == "BEARISH":
            result["decision"] = "SELL_CANDIDATE"
        else:
            result["reasons"].append("ML direction conflicts with higher-timeframe structure")
        return result
    except FileNotFoundError:
        result["reasons"].append("No trained model found; train and validate first")
        return result
