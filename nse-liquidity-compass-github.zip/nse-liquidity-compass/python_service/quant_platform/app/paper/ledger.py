"""Tiny paper-only ledger. No broker order placement."""
class PaperLedger:
    def __init__(self, starting_cash=100000.0):
        self.cash = float(starting_cash)
        self.positions = {}
        self.trades = []

    def open_position(self, symbol, side, qty, entry, stop, target):
        if side not in {"LONG","SHORT"} or qty <= 0 or entry <= 0:
            raise ValueError("Invalid paper trade")
        if symbol in self.positions:
            raise ValueError("Position already open for symbol")
        risk = abs(entry-stop)*qty
        self.positions[symbol] = {
            "side":side,"qty":int(qty),"entry":float(entry),
            "stop":float(stop),"target":float(target),"risk":float(risk)
        }
        return self.positions[symbol]

    def close_position(self, symbol, exit_price, reason="MANUAL"):
        p = self.positions.pop(symbol)
        sign = 1 if p["side"] == "LONG" else -1
        pnl = (float(exit_price)-p["entry"])*p["qty"]*sign
        trade = {"symbol":symbol,**p,"exit":float(exit_price),
                 "pnl_before_costs":pnl,"reason":reason}
        self.trades.append(trade)
        return trade
