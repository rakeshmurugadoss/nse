"""Supabase persistence. Service-role key must remain backend-only."""
from supabase import create_client
from app.config import required

class ResearchStore:
    def __init__(self):
        self.client = create_client(required("SUPABASE_URL"),
                                    required("SUPABASE_SERVICE_ROLE_KEY"))

    def upsert_candles(self, symbol, exchange, interval, rows):
        payload = []
        for r in rows:
            ts = r["timestamp"]
            payload.append({
                "symbol":symbol, "exchange":exchange, "interval":interval,
                "timestamp":ts.isoformat() if hasattr(ts,"isoformat") else str(ts),
                "open":float(r["open"]), "high":float(r["high"]),
                "low":float(r["low"]), "close":float(r["close"]),
                "volume":int(r["volume"])
            })
        if payload:
            self.client.table("market_candles").upsert(
                payload, on_conflict="exchange,symbol,interval,timestamp"
            ).execute()
        return len(payload)

    def load_candles(self, symbol, exchange, interval, limit=5000):
        result = (self.client.table("market_candles").select(
            "timestamp,open,high,low,close,volume"
        ).eq("symbol",symbol).eq("exchange",exchange).eq("interval",interval)
         .order("timestamp", desc=True).limit(limit).execute())
        import pandas as pd
        df = pd.DataFrame(result.data or [])
        if not df.empty:
            df["timestamp"] = pd.to_datetime(df["timestamp"])
            df = df.sort_values("timestamp").reset_index(drop=True)
        return df

    def save_prediction(self, record):
        return self.client.table("research_predictions").insert(record).execute()

    def load_candles_as_of(self, symbol, exchange, interval, as_of, limit=5000):
        """Read existing candles strictly before decision time, prior to applying LIMIT."""
        result = (self.client.table("market_candles").select(
            "timestamp,open,high,low,close,volume"
        ).eq("symbol",symbol).eq("exchange",exchange).eq("interval",interval)
         .lt("timestamp",as_of.isoformat()).order("timestamp",desc=True).limit(limit).execute())
        import pandas as pd
        df = pd.DataFrame(result.data or [])
        if not df.empty:
            df["timestamp"] = pd.to_datetime(df["timestamp"],utc=True)
            df = df.sort_values("timestamp").reset_index(drop=True)
        return df
