"""Kite Connect data-only provider. No order placement functionality."""
from datetime import datetime
import pandas as pd
from kiteconnect import KiteConnect
from app.config import setting, required

class KiteProvider:
    def __init__(self):
        self.kite = KiteConnect(api_key=required("KITE_API_KEY"))
        self.kite.set_access_token(required("KITE_ACCESS_TOKEN"))

    def instrument_token(self, symbol: str, exchange: str = "NSE") -> int:
        matches = [x for x in self.kite.instruments(exchange)
                   if x.get("tradingsymbol") == symbol]
        if not matches:
            raise ValueError(f"Instrument not found: {exchange}:{symbol}")
        return int(matches[0]["instrument_token"])

    def historical(self, token: int, start: datetime, end: datetime,
                   interval: str = "5minute") -> pd.DataFrame:
        rows = self.kite.historical_data(
            int(token), start, end, interval, continuous=False, oi=False
        )
        df = pd.DataFrame(rows)
        if df.empty:
            return pd.DataFrame(columns=[
                "timestamp","open","high","low","close","volume"
            ])
        df = df.rename(columns={"date":"timestamp"})
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        return df[["timestamp","open","high","low","close","volume"]].sort_values(
            "timestamp"
        ).drop_duplicates("timestamp").reset_index(drop=True)

    def ticker(self):
        from kiteconnect import KiteTicker
        return KiteTicker(required("KITE_API_KEY"), required("KITE_ACCESS_TOKEN"))
