"""Tick-to-candle aggregator. Reconcile/backfill with broker candles after reconnect."""
from datetime import datetime
from threading import RLock

INTERVALS = {"1minute":1, "5minute":5, "15minute":15, "60minute":60}

def bucket_time(ts: datetime, minutes: int):
    return ts.replace(minute=(ts.minute // minutes)*minutes, second=0, microsecond=0)

class CandleBuilder:
    def __init__(self, intervals=None):
        self.intervals = intervals or list(INTERVALS)
        if set(self.intervals) - set(INTERVALS):
            raise ValueError("Unsupported interval")
        self.active = {}
        self.previous_day_volume = {}
        self.lock = RLock()

    def on_tick(self, tick):
        token = int(tick["instrument_token"])
        price = float(tick.get("last_price") or 0)
        if price <= 0:
            return []
        ts = tick.get("exchange_timestamp") or tick.get("last_trade_time")
        if ts is None:
            raise ValueError("Tick has no exchange timestamp; refusing machine-time fallback")
        day_volume = int(tick.get("volume_traded") or 0)
        prev = self.previous_day_volume.get(token)
        # First tick volume is unknown; never invent it.
        delta = 0 if prev is None or day_volume < prev else day_volume - prev
        self.previous_day_volume[token] = day_volume
        done = []
        with self.lock:
            for interval in self.intervals:
                bucket = bucket_time(ts, INTERVALS[interval])
                key = (token, interval)
                old = self.active.get(key)
                if old is None or old["timestamp"] != bucket:
                    if old is not None:
                        old["is_complete"] = True
                        done.append(old.copy())
                    self.active[key] = {
                        "instrument_token":token, "interval":interval,
                        "timestamp":bucket, "open":price, "high":price,
                        "low":price, "close":price, "volume":delta,
                        "is_complete":False
                    }
                else:
                    old["high"] = max(old["high"], price)
                    old["low"] = min(old["low"], price)
                    old["close"] = price
                    old["volume"] += delta
        return done
