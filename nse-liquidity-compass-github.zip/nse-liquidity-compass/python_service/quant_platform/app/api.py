import os
from datetime import datetime, timedelta
from fastapi import APIRouter, Header, HTTPException, Query
from app.data.kite_provider import KiteProvider
from app.data.store import ResearchStore
from app.research.train import train
from app.research.features import build_features

router = APIRouter(prefix="/api/v1/quant", tags=["AI Quant Research"])

def guard(key):
    expected = os.getenv("MARKET_DATA_API_KEY")
    if not expected or key != expected:
        raise HTTPException(401, "Invalid API key")

@router.get("/health")
def health():
    return {"status":"ok","mode":"research_and_paper_only"}

@router.post("/sync/history")
def sync_history(symbol: str, interval: str="5minute",
                 days: int=Query(30, ge=1, le=365),
                 x_market_data_key: str|None=Header(default=None)):
    guard(x_market_data_key)
    try:
        provider, store = KiteProvider(), ResearchStore()
        token = provider.instrument_token(symbol)
        end = datetime.now()
        df = provider.historical(token, end-timedelta(days=days), end, interval)
        count = store.upsert_candles(symbol,"NSE",interval,df.to_dict("records"))
        return {"symbol":symbol,"interval":interval,"fetched":len(df),"stored":count}
    except Exception as e:
        raise HTTPException(502,str(e)) from e

@router.get("/candles")
def candles(symbol: str, interval: str="5minute", limit: int=1000,
            x_market_data_key: str|None=Header(default=None)):
    guard(x_market_data_key)
    df = ResearchStore().load_candles(symbol,"NSE",interval,min(limit,10000))
    if not df.empty:
        df["timestamp"] = df["timestamp"].astype(str)
    return {"symbol":symbol,"interval":interval,"count":len(df),
            "candles":df.to_dict("records")}

@router.post("/train")
def train_model(symbol: str, interval: str="5minute",
                x_market_data_key: str|None=Header(default=None)):
    guard(x_market_data_key)
    df = ResearchStore().load_candles(symbol,"NSE",interval,10000)
    try:
        return train(df)
    except Exception as e:
        raise HTTPException(400,str(e)) from e

@router.get("/features/latest")
def latest_features(symbol: str, interval: str="5minute",
                    x_market_data_key: str|None=Header(default=None)):
    guard(x_market_data_key)
    df = ResearchStore().load_candles(symbol,"NSE",interval,500)
    if df.empty:
        raise HTTPException(404,"No candles stored yet")
    f = build_features(df).tail(1).replace({float("nan"):None})
    return f.to_dict("records")[0]
