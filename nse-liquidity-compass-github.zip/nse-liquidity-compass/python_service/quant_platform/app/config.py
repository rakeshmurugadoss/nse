import os
from dotenv import load_dotenv
load_dotenv()

def required(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"Missing environment variable: {name}")
    return value

def setting(name: str, default: str) -> str:
    return os.getenv(name, default).strip()
