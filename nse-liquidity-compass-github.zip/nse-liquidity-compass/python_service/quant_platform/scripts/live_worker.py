"""Run this as a persistent backend worker during market hours."""
import os, time
from datetime import datetime, timedelta
from app.data.kite_provider import KiteProvider
from app.data.candle_builder import CandleBuilder
from app.data.store import ResearchStore

SYMBOL = os.getenv("DEFAULT_SYMBOL","INFY")
EXCHANGE = os.getenv("DEFAULT_EXCHANGE","NSE")
INTERVALS = ["1minute","5minute","15minute","60minute"]

def main():
    provider, store = KiteProvider(), ResearchStore()
    token = provider.instrument_token(SYMBOL, EXCHANGE)
    # Initial warm-up/backfill so features have historical context.
    end = datetime.now()
    for interval in INTERVALS:
        df = provider.historical(token, end-timedelta(days=30), end, interval)
        store.upsert_candles(SYMBOL, EXCHANGE, interval, df.to_dict("records"))
        print("Backfilled", interval, len(df))
    builder = CandleBuilder(INTERVALS)
    ticker = provider.ticker()
    def on_connect(ws, response):
        ws.subscribe([token])
        ws.set_mode(ws.MODE_FULL,[token])
        print("Live feed connected", SYMBOL, token)
    def on_ticks(ws, ticks):
        for tick in ticks:
            for candle in builder.on_tick(tick):
                store.upsert_candles(SYMBOL, EXCHANGE, candle["interval"], [candle])
                print("Stored completed candle", candle["interval"], candle["timestamp"])
    ticker.on_connect = on_connect
    ticker.on_ticks = on_ticks
    ticker.on_error = lambda ws, code, reason: print("Ticker error",code,reason)
    ticker.on_close = lambda ws, code, reason: print("Ticker closed",code,reason)
    ticker.connect(threaded=False)

if __name__ == "__main__":
    main()
