from fastapi import FastAPI
from app.api import router
from app.candle_api import router as candle_router
app = FastAPI(title="AI Quant Research Platform", version="0.1.0")
app.include_router(router)
app.include_router(candle_router)
@app.get("/")
def root():
    return {"name":"AI Quant Research Platform","status":"starter scaffold"}
