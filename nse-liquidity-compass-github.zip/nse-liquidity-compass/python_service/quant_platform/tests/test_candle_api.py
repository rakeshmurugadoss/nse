"""Stored-candle route integration; fixtures never replace production market data."""
from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock
import pandas as pd
from fastapi import FastAPI
from fastapi.testclient import TestClient
from app.candle_api import router
from app.data.store import ResearchStore

def test_api_reuses_storage_and_checks_key(monkeypatch):
    monkeypatch.setenv("MARKET_DATA_API_KEY","test-only-key")
    app=FastAPI();app.include_router(router);client=TestClient(app)
    request={"symbol":"RELIANCE","exchange":"NSE","as_of":"2026-11-06T04:45:00Z"}
    assert client.post("/api/v1/quant/candle-intelligence",json=request).status_code==401
    data=[{"timestamp":datetime(2026,11,6,3,45,tzinfo=timezone.utc)+timedelta(minutes=i),"open":100,"high":101,"low":99,"close":100.5,"volume":100} for i in range(60)]
    store=MagicMock();store.load_candles_as_of.return_value=pd.DataFrame(data)
    monkeypatch.setattr("app.candle_api.ResearchStore",lambda:store)
    response=client.post("/api/v1/quant/candle-intelligence",json=request,headers={"X-Market-Data-Key":"test-only-key"})
    assert response.status_code==200
    assert len(response.json()["timeframes"]["60m"])==1
    assert store.load_candles_as_of.call_args.args[:3]==("RELIANCE","NSE","minute")
    store.load_candles_as_of.return_value=pd.DataFrame()
    assert client.post("/api/v1/quant/candle-intelligence",json=request,headers={"X-Market-Data-Key":"test-only-key"}).status_code==404

def test_as_of_filter_applied_before_limit():
    store=ResearchStore.__new__(ResearchStore)
    store.client=MagicMock()
    chain=store.client.table.return_value.select.return_value
    chain.eq.return_value=chain
    chain.lt.return_value=chain
    chain.order.return_value=chain
    chain.limit.return_value=chain
    chain.execute.return_value.data=[]
    as_of=datetime(2026,11,6,4,45,tzinfo=timezone.utc)
    store.load_candles_as_of("RELIANCE","BSE","minute",as_of,100)
    calls=[c[0] for c in chain.mock_calls]
    assert calls.index("lt")<calls.index("limit")
    chain.lt.assert_called_once_with("timestamp",as_of.isoformat())