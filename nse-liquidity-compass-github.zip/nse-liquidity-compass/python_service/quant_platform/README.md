# AI Quant Research Platform — starter implementation

This is a modular, data-first research platform built around your current stack:
**FastAPI + Supabase + Zerodha Kite Connect + Python market-structure engine**.

It replaces CSV uploads with automatic historical backfill and a live WebSocket worker.
It is deliberately research/paper-only: there is no order placement code.

## Architecture

1. `KiteProvider`: resolves NSE instrument tokens and fetches historical candles.
2. `CandleBuilder`: aggregates WebSocket ticks into 1m/5m/15m/60m candles.
3. `ResearchStore`: persists normalized candles in Supabase.
4. `features.py`: creates causal technical/statistical features from past/current bars.
5. `train.py`: chronological TimeSeriesSplit research baseline.
6. `judge.py`: conservative BUY_CANDIDATE / SELL_CANDIDATE / WAIT gate; requires structure evidence.
7. `paper/ledger.py`: paper-only position ledger.
8. FastAPI endpoints: history sync, candle retrieval, training, latest features.

## Important before running

- Kite Connect market data requires a market-data-enabled Kite Connect subscription. Check current pricing/permissions in your Zerodha Developer Console.
- Kite access tokens expire daily. Your existing daily login process must refresh `KITE_ACCESS_TOKEN`.
- Keep Kite API secret/access token and Supabase service-role key on the backend only.
- Use a persistent worker process for WebSocket streaming; do not run the live feed inside a short-lived serverless request.
- This scaffold has not been connected to your live account or validated against your Supabase project.

## Setup

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Fill `.env`. Apply `supabase/schema.sql` in Supabase SQL Editor.

## Start API

```bash
uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

Set a strong `MARKET_DATA_API_KEY` in `.env`, then call:
```bash
curl -X POST -H "X-Market-Data-Key: YOUR_KEY" \
 "http://127.0.0.1:8000/api/v1/quant/sync/history?symbol=INFY&interval=5minute&days=30"
```
Fetch candles:
```bash
curl -H "X-Market-Data-Key: YOUR_KEY" \
 "http://127.0.0.1:8000/api/v1/quant/candles?symbol=INFY&interval=5minute&limit=1000"
```
Train baseline:
```bash
curl -X POST -H "X-Market-Data-Key: YOUR_KEY" \
 "http://127.0.0.1:8000/api/v1/quant/train?symbol=INFY&interval=5minute"
```

## Start automatic live pipeline

Run the worker in a separate persistent process after daily token refresh:
```bash
python -m scripts.live_worker
```
It first backfills 30 calendar days of historical candles, then connects the Kite WebSocket and stores completed candles.
Start with one symbol. Expand to a watchlist only after checking API limits and data quality.

## Model research cautions

- The classifier is a baseline, not an alpha engine and not a promise of returns.
- Labels use future returns only for training targets. Features are causal. Do not accidentally pass labels/future columns into inference.
- TimeSeriesSplit is a first chronological validation, not sufficient proof. Keep a final untouched date range; use walk-forward retraining and compare to simple baselines.
- Add realistic brokerage, STT, exchange fees, GST, stamp duty, spread, slippage and latency to backtests.
- Calibrate probabilities and thresholds only on separate validation data. Current `predict_proba` scores are not calibrated win probabilities.
- Current sample labels use fixed horizon/threshold. Replace with volatility-scaled triple-barrier labels after initial data pipeline is verified.
- Confirmed pivots/OB events must only become available after their confirmation candle. For historical backtests, calculate features and structure as-of each decision timestamp.
- Tick-aggregated candles can differ from exchange/broker candles, especially around reconnects, opening/closing sessions and missing ticks. Backfill gaps from historical API and reconcile.
- `CandleBuilder` intentionally emits a candle only when a tick arrives in the next bucket. Add session-end flush and robust reconnect/backfill handling before production.
- `close_vs_vwap_proxy` is a rolling proxy, not true exchange-session VWAP. Replace it with session-reset VWAP for live deployment.
- No claims of institutional order flow can be made from OHLCV alone.

## Integration with your existing OB engine

In the live worker, after persisting a completed candle:
1. Load the required aligned timeframe windows.
2. Run your existing market structure / protected OB / FVG modules.
3. Pass the resulting point-in-time structure evidence to `app.decision.judge`.
4. Save every prediction with decision timestamp, model version, feature snapshot and reason codes.
5. Track hypothetical outcomes in the paper ledger; do not auto-route orders.

The `judge.py` module is a conservative starting gate and currently expects a structure dictionary:
```python
{
  "higher_timeframe_bias": "BULLISH",
  "lower_timeframe_confirmation": True,
  "fresh_order_block": True
}
```
Wire these fields only from your actual engine outputs; never hardcode them.
