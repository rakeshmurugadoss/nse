# Advanced research setup and readiness

The existing app is preserved. `/predictions` accepts real, regular-session NSE **one-minute** OHLCV history. It does not auto-load demo candles. Sign in with Google or Lovable to save private research. Upload enough history for at least 20 complete one-hour bars, normally four or more sessions. TradingView remains view-only; annotated historical charts and PNG exports are rendered separately.

## CSV
Download `/research-csv-template.csv`. The exact header is `timestamp,open,high,low,close,volume`. Fill it with actual provider history, chronological and unique. Timestamps are candle opens, ISO dates with an offset, or declared Asia/Kolkata. Regular weekdays 09:15–15:30 IST only; special sessions/holiday calendars are not yet supported. No fabricated example prices are supplied. Maximum 50,000 rows / 6 MB. Missing minutes are not filled; they veto entries. Final partial hourly session bars are excluded.

## Workflow
1. Upload history and select symbol, horizon and timezone.
2. Analyse; a signed-in request computes and stores the snapshot/report server-side before any outcome.
3. Prediction history opens the saved report, not a recomputation with later prices.
4. Upload the same history with genuine later minutes appended and select **Evaluate appended candles**. Earlier supplied rows must match. Missing horizon minutes stay pending; ambiguous target/stop order stays ambiguous. Outcomes are historical price-path research, not proof of a paper fill.

Migration SQL is in `drizzle/migrations/0000_advanced_prediction_research.sql`, applied through Lovable Cloud. Predictions and outcomes are immutable for ordinary authenticated users. Reads and inserts are isolated to each user's UUID. No profile fields are needed. Direct authenticated writes are user-supplied research, not independently certified results. No public sharing.

## Python service (separate host required)
The website's hosting does not run Python daemons. Deploy `python_service/` on a Python-compatible host. From that folder:

```sh
python -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python -m pytest tests
.venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000
```

Set private `SUPABASE_URL` and `SUPABASE_PUBLISHABLE_KEY` using deployment environment configuration for your connected Cloud backend. Never set service-role credentials or tokens in source or browser code. Every endpoint validates the user's bearer session with the authentication service and performs owner-scoped reads through RLS. No CORS access is opened. Production callers should use same-origin authenticated website functions. The service consumes saved TS evidence rather than inventing or independently redetecting zones. API docs are at `/docs` on the Python host.
Set the website's private `PYTHON_RESEARCH_URL` to the deployed HTTPS service origin. `enrichWithPython` verifies ownership and forwards the caller's bearer token only to that configured origin. No URL supplied by the browser is accepted. It fails closed when not configured.

Implemented endpoints: analyze and multi-timeframe enrich an already stored prediction ID; history/detail and model/backtest records are authenticated reads. Training and backtest launch endpoints currently fail closed: insufficient labels return 409; missing durable workers return 503. They do not pretend jobs ran. Python baseline helpers offer purged walk-forward logistic training and final-test metrics, but do not create validated deployed models.

## Order-block protection package
The uploaded Python package is adapted into `src/lib/order-block-protection.ts`, exported through the shared engine. Advanced research stores selected-timeframe protection in its immutable output (rule version `liquidity-research-2`, protection version `shared-ob-protection-1`). Existing chart layers, zones, scores and entry plans are unchanged. No new database table or provider is required.

Protection reuses existing confirmed swings and close-based BOS/CHoCH, not the upload's separate pivot detector. Availability is the confirming candle's close. Defaults: prior Wilder ATR period 14; displacement ≥1.25 ATR; body/range ≥0.55; relative volume ≥1 against 20 **prior** bars; last strictly opposite candle within 12 bars; full-candle zone; expiry after 80 subsequent available bars; consumption at ≥95% penetration. Missing volume fails the default quality gate. Failed candidates remain in the audit list, not the active list. Fresh, boundary-touched and partially mitigated candidates may be active; consumed, invalidated and expired candidates cannot. Close-through invalidation includes gaps and can be recorded after consumption. All lifecycle timestamps are candle closes. Rerun truncated data for point-in-time replay; never use later status for an earlier decision.

The shared engine's existing bounded history (300 one-minute/225 five-minute bars) and swing settings apply. This is supplemental candidate evidence, not full-history tracking or a standalone signal; quality scores are not probabilities. The authenticated Python `POST /api/v1/structure/order-block-protection` accepts `{ "prediction_id": "<saved prediction UUID>" }`, reads only the caller's prediction, validates causal versioned evidence and derives the active list. Older snapshots return 409 requiring a new analysis; they are never rewritten. The endpoint still requires separate Python hosting and is not advertised as deployed.

## Current limits and remaining stages
- No NSE provider or automatic later-candle retrieval. Forex/Gold Twelve Data remains unchanged.
- Python is not deployed or connected; training and durable replay workers are not configured.
- Advanced research adds MSS, selected-timeframe internal/1H external structure, inverse FVG and explicitly labelled inducement/mitigation-block candidates. These are documented research definitions, not observed institutional order flow; charts show a selected subset and expandable evidence includes availability times.
- Eight task label helpers, chronological sigmoid calibration and a fixed gradient-boosted baseline helper are provided; model artifacts, training execution, durable jobs and real out-of-sample cost comparisons are not deployed. No validated model is advertised.
- Private history includes directional totals and symbol/timeframe/regime breakdowns. Calibrated metrics and expectancy remain unavailable without validated model output and verified fill paths.
- Paper journal is preserved locally; opt-in private copying and dated estimated brokerage/slippage/other-charge controls are added. No automatic tax schedule is asserted, and MAE/MFE stay unavailable without real trade-path candles.
- Research rule engine versioning records identifiers but historical source-version execution is not yet an archived-code replay service.
- Complete signed-in saving/ownership checks require an actual app account. No account is auto-created.

These limits are reflected in the roadmap. No trained score or guaranteed-profit claim is displayed.