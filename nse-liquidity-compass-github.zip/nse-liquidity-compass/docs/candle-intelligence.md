# Advanced Candle Intelligence

## Integration and files

Added a read-only Python candle-analysis layer, not a new application. Existing
Zerodha login, credentials, stock search, historical fetching, TS reports, APIs,
database tables and broker behaviour remain unchanged. No schema migrations or
broker orders. Nothing is trained and no quality score is a win probability.

Created:
- `python_service/candle_intelligence/__init__.py`: reusable public imports.
- `python_service/candle_intelligence/schemas.py`: strict Pydantic inputs, thresholds,
  output models, evidence and versioning.
- `python_service/candle_intelligence/engine.py`: anatomy, causal indicators,
  independent aggregation, pattern rules and six-dimensional quality score.
- `python_service/candle_intelligence/snapshot.py`: existing saved TS snapshot adapter.
- `python_service/candle_intelligence/api.py`: owned-prediction endpoint.
- `python_service/quant_platform/app/candle_api.py`: existing stored OHLCV endpoint.
- `python_service/tests/test_candle_intelligence.py`: patterns, edge cases, chronology,
  scores and owned endpoint tests.
- `python_service/quant_platform/tests/test_candle_api.py`: stored endpoint and query tests.
- `docs/candle-intelligence-example.json`: full output from a real loaded Kite candle.
- This guide.

Modified: `python_service/main.py`, `python_service/requirements.txt`,
`python_service/quant_platform/main.py`, `python_service/quant_platform/app/data/store.py`,
`AGENTS.md`, `roadmap.md`. No existing handler was replaced.

## Architecture

```text
Existing real Kite OHLCV / immutable prediction snapshot
  -> typed minute input validation
  -> NSE/BSE session-anchored complete 1m / 5m / 15m / 60m buckets
  -> per-frame anatomy, past-only baselines and causal indicators
  -> configurable classifications + rule/measurement evidence
  -> separate context + six-component quality score
  -> typed JSON (transient; existing snapshot remains unchanged)
```

The standalone quant scaffold and owner-authenticated research service are separate
Python apps. Both import the same reusable module. Candle indicators have their own
version and never overwrite the authoritative shared TS engine. No Python zone or
swing detector was introduced. Saved TS OB/FVG/liquidity context requires an exact
decision-time status; final snapshot state is never projected into earlier candles.
Immutable confirmed pivots remain available after confirmation. Earlier candles
without authoritative state return empty context and warnings, not guessed zones.
Stored-market endpoint provides candle features but has no structural evidence source.

## Exact API endpoints

### Owner-authenticated research service

`POST /api/v1/candles/intelligence`

Use the app user's bearer session, not a market-data key. Reads only an owned existing
prediction through current user-scoped storage. Load from Kite and save the research
prediction using the existing app first; CSV uploading is not required.

```http
POST /api/v1/candles/intelligence
Authorization: Bearer <current-app-session>
Content-Type: application/json

{
  "prediction_id": "<your-existing-owned-prediction-uuid>",
  "timeframes": ["1m", "5m", "15m", "60m"],
  "thresholds": {"strong_body": 0.7, "displacement_atr": 1.5}
}
```

### Existing automatic market-candle storage

`POST /api/v1/quant/candle-intelligence`

Uses the standalone platform's existing `X-Market-Data-Key` protection and
`ResearchStore`, without replacing KiteProvider. This is a backend-only shared-key
endpoint, never expose the key to browser code. Requires its existing `market_candles`
table and `minute` interval rows from existing historical sync/live ingestion.

```http
POST /api/v1/quant/candle-intelligence
X-Market-Data-Key: <existing-backend-market-data-key>
Content-Type: application/json

{
  "symbol": "RELIANCE",
  "exchange": "NSE",
  "as_of": "2026-11-06T15:30:00+05:30",
  "limit": 2000,
  "timeframes": ["1m", "5m", "15m", "60m"]
}
```

Call existing `POST /api/v1/quant/sync/history?symbol=RELIANCE&interval=minute&days=5`
first if no minute rows are stored. Existing scaffold sync is NSE-only; BSE requires
already correctly exchange-tagged stored candles. No automatic provider fallback or
credential replacement occurs. Data is queried before `as_of` **before** LIMIT,
preventing later rows from displacing historical warm-up. The limit bounds input
history, so specify enough warm-up for historical comparisons.

Both responses have `schema_version`, `source`, `as_of`, `timeframes` (each an array
of full candle results), and `warnings`. Full real-data candle JSON is in
`docs/candle-intelligence-example.json`. A compact excerpt:

```json
{
  "timeframe": "1m",
  "candle_direction": "neutral",
  "quality_score": {
    "total": 43.998,
    "interpretation": "Heuristic candle evidence quality; not win probability or a trade signal"
  }
}
```

All full candles include timestamp/open time, decision_timestamp/close time, anatomy,
strength_metrics, volume_metrics, detected_patterns, rejection_type,
displacement_type, context, quality_score, evidence, warnings. Missing metrics are
null. No BUY/SELL field. Example JSON is a static documentation observation, never
fed to the application as market data.

## Rules and historical correctness

- Only complete minute buckets are emitted; every expected minute must exist.
  Gap buckets are excluded, never filled. Inputs must be sorted/unique, valid OHLC,
  nonnegative finite volume or null, and timezone-aware minute open timestamps.
- Indian regular-equity sessions are 09:15–15:30 Asia/Kolkata, weekdays. Hour buckets
  are anchored at 09:15; the last 15:15–15:30 bucket is 15 minutes. Holiday calendars,
  special trading sessions and pre-open/auction candles are not inferred.
- Each timeframe has independent calculations; no cross-timeframe interpretation.
- Range/body/relative-volume baselines use exactly the **previous** configured
  lookback (default 20), excluding the current candle. Missing or zero volume
  baselines earn no volume evidence. Range/ATR uses the previous closed Wilder ATR.
- EMA9/20/50 use SMA seeds; ATR14 and RSI14 use Wilder smoothing. Current completed
  candles enter indicators. Warm-up is null. Typical-price VWAP resets daily;
  any missing session volume makes VWAP unavailable for the remainder of that day.
- Prefix-invariance tests compare earlier output after adding later candles.
  Failed breakout is emitted on the failure candle, not retroactively on the breakout.
  Failed breakout currently means next-candle return through the prior breakout level,
  not arbitrary later failure; ambiguous same-candle intrabar sequencing is not inferred.
- Strict inside/outside bars exclude equality. Overlapping pattern labels are allowed.
  Strong body >= .7; rejection wick >= .6 plus close-position test; doji body <= .1;
  spinning top .1–.3 with two wicks >= .2; marubozu each wick <= .05.
  Wide/narrow range >=1.5 / <=.6 of prior mean. High/low volume >=1.5 / <=.7 of
  prior mean. All thresholds and score weights are validated/configurable; exact
  rule text and measurements accompany every detection.
- Pressure, displacement, sweep and exhaustion are price-action proxies only.
  Recent trailing highs/lows are not called confirmed structural pivots.
- Quality = weighted component sum / all configured weights. Missing components
  contribute zero, not a renormalized inflated score. Each component exposes its
  value, weight and reason. Default weights: body 20, wick 15, volume 20,
  ATR range 15, momentum 15, context 15. No statistical calibration implied.

## Run

Use Python 3.11+ and a persistent Python-compatible host; Cloudflare Workers do not
run Python/pandas. From the project root:

```bash
python -m venv .venv
.venv/bin/pip install -r python_service/requirements.txt
PYTHONPATH=python_service .venv/bin/uvicorn main:app --host 127.0.0.1 --port 8001
```

Owner service uses its existing `SUPABASE_URL` and `SUPABASE_PUBLISHABLE_KEY` environment
configuration; never embed private credentials. Do not request a managed service-role
key for this owner endpoint.

To run the standalone quant app instead, retain its existing environment and dependencies:

```bash
.venv/bin/pip install -r python_service/quant_platform/requirements.txt
PYTHONPATH=python_service:python_service/quant_platform .venv/bin/uvicorn \
  main:app --app-dir python_service/quant_platform --host 127.0.0.1 --port 8002
```

It retains its pre-existing external-store credential requirements. The app's daily
encrypted Kite login token is not automatically exported to a Python worker; this
change does not pretend otherwise or replace it. The owned-snapshot path works without
giving Python broker credentials.

Direct use (existing typed one-minute records, no upload):

```python
from candle_intelligence import CandleInput, analyze_minutes, Thresholds

result = analyze_minutes(
    [CandleInput.model_validate(row) for row in existing_ohlcv_records],
    as_of=decision_time,
    thresholds=Thresholds(strong_body=0.75),
    source="existing_kite_ohlcv",
)
json_payload = result.model_dump(mode="json")
```

Tests:

```bash
PYTHONPATH=python_service .venv/bin/pytest -q python_service/tests
PYTHONPATH=python_service:python_service/quant_platform .venv/bin/pytest -q \
  python_service/quant_platform/tests
```

## Verification and limitations

- Core Python suite: 57 passing; standalone stored-candle API suite: 2 passing.
  Existing Kite/Indian-stock/prediction TS regressions:
  25 passing.
- Existing browser Kite flow loaded 297 real RELIANCE minute candles. Reusing those
  exact observations produced 297/59/19/4 completed 1m/5m/15m/60m results, without
  fabricated gap bars. The saved full JSON example comes from that real-data run.
- Protected endpoint payload/auth/ownership checks use controlled stores in local
  tests; they do not prove hosted owner authentication or deployed table access.
- No deployed Python service URL is available here. These endpoints are implemented
  and locally verified, **not deployed to the published website**. Existing app UI
  and its Python response bridge remain unchanged; no UI integration was requested.
- Logging reports only counts and validation/storage availability, not credentials
  or candle payloads. Auth fails closed; malformed snapshots return 422, missing
  owned rows 404, absent data 409/404, storage unavailability 503, snapshots exceeding
  10,000 minute rows 413. Existing gateway timeouts still apply at the caller.
- No new tables, model influence, outcome mutation or automatic broker execution.